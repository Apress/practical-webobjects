connect to PracticalWebObjects on localhost user PWUser password secret;

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE, LOCKING PESSIMISTIC;

-------------------------------------------------------------------------------
--
-- For PracticalUtilties Framework
--
-------------------------------------------------------------------------------

DROP TABLE "COOP_EC_TEST_OBJECT" CASCADE;
DROP TABLE "NAMED_OBJECT" CASCADE;
DROP TABLE "OWNED_OBJECT" CASCADE;
DROP TABLE "ROOT_OBJECT" CASCADE;
DROP TABLE "ROOT_UNOWNED_JOIN" CASCADE;
DROP TABLE "Test_Model1_Entity" CASCADE;
DROP TABLE "UNOWNED_OBJECT" CASCADE;
DROP TABLE "ATTR_VALID_TEST_ENTITY" CASCADE;
DROP TABLE "ENTITY_WITH_CONSTRAINTS" CASCADE;
DROP TABLE "ENTITY_WITH_DECIMAL_PK" CASCADE;
DROP TABLE "DECIMAL_PK_SUBCLASS" CASCADE;
DROP TABLE "TO_ONE_ENTITY" CASCADE;
DROP TABLE "VALIDATION_BARE_ENTITY" CASCADE;
DROP TABLE "REL_TO_BARE" CASCADE;
DROP TABLE "REL_TO_DECIMAL" CASCADE;
DROP TABLE "REL_VALID_TEST_ENTITY" CASCADE;
COMMIT;



-------------------------------------------------------------------------------
--
-- For Chap1App Application
--
-------------------------------------------------------------------------------

-- Not used

-------------------------------------------------------------------------------
--
-- For Chap2App Application
--
-------------------------------------------------------------------------------

DROP TABLE "ATTRIB_TEST" CASCADE;
COMMIT;


-------------------------------------------------------------------------------
--
-- For Chap3App Application
--
-------------------------------------------------------------------------------

-- Not used

-------------------------------------------------------------------------------
--
-- For Chap4App Application
--
-------------------------------------------------------------------------------

DROP TABLE "ABSTRACT_USER" CASCADE;
DROP TABLE "DIGEST_PASSWORD_USER" CASCADE;
DROP TABLE "SIMPLE_USER" CASCADE;
DROP TABLE "ENCRYPTED_PASSWORD_USER" CASCADE;
DROP TABLE "LDAP_USER" CASCADE;
DROP TABLE "KERBEROS_USER" CASCADE;

COMMIT;

-------------------------------------------------------------------------------
--
-- For Chap5App Application
--
-------------------------------------------------------------------------------

DROP TABLE "MISSING_VALIDATIONS" CASCADE;
DROP TABLE "PRACTICAL_ENTITY" CASCADE;
DROP TABLE "VALIDATING_EO" CASCADE;

COMMIT;

-------------------------------------------------------------------------------
--
-- For Chap11App Application
--
-------------------------------------------------------------------------------

DROP TABLE "PRODUCT" CASCADE;

COMMIT;
