
// _Product.java
// 
// Created by eogenerator
// DO NOT EDIT.  Make changes to Product.java instead.

package com.apress.practicalwo.chap11;


import com.webobjects.eocontrol.EOGenericRecord;

public abstract class _Product extends EOGenericRecord {

    public _Product() {
        super();
    }

/*
    // If you add instance variables to store property values you
    // should add empty implementions of the Serialization methods
    // to avoid unnecessary overhead (the properties will be
    // serialized for you in the superclass).
    private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
    }

    private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, java.lang.ClassNotFoundException {
    }
*/

    public String name() {
        return (String)storedValueForKey("name");
    }

    public void setName(String aValue) {
        takeStoredValueForKey(aValue, "name");
    }

    public Number price() {
        return (Number)storedValueForKey("price");
    }

    public void setPrice(Number aValue) {
        takeStoredValueForKey(aValue, "price");
    }

    public String sku() {
        return (String)storedValueForKey("sku");
    }

    public void setSku(String aValue) {
        takeStoredValueForKey(aValue, "sku");
    }

    public String spec() {
        return (String)storedValueForKey("spec");
    }

    public void setSpec(String aValue) {
        takeStoredValueForKey(aValue, "spec");
    }

    public Number weight() {
        return (Number)storedValueForKey("weight");
    }

    public void setWeight(Number aValue) {
        takeStoredValueForKey(aValue, "weight");
    }
}
