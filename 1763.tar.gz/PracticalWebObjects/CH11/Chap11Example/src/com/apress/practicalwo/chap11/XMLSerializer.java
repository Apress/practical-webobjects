package com.apress.practicalwo.chap11;

import java.io.*;

import javax.xml.transform.*;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.*;

import org.apache.fop.apps.Driver;

import com.webobjects.appserver.*;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.xml.*;

public class XMLSerializer {

	public static String serializeArray(NSArray list) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
			// Create a stream to the output file.

			BufferedOutputStream byte_output_stream = new BufferedOutputStream(out);
			NSXMLOutputStream stream = new NSXMLOutputStream(byte_output_stream);

			// Set the format of the output document (XML).
			NSXMLOutputFormat format = new NSXMLOutputFormat(true);

			// Serialize data to object output stream.
			stream.writeObject(list);

			format.setEncoding("UTF-8");
			//			turn indentation on               
			stream.setOutputFormat(format); // app

			stream.flush();
			stream.close();
			byte_output_stream.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return out.toString();
	}

	public static String transformXML(String xml, String xslfile) {
		String result = null;
		try {
			Result output = new StreamResult(new ByteArrayOutputStream());
			// get the XSL stylesheet
			WOApplication application = WOApplication.application();
			WOResourceManager resource_manager = application.resourceManager();
			String xsl = new String(resource_manager.bytesForResourceNamed(xslfile, null, null));
			
			// create the XSL Transformer
			TransformerFactory tFactory = TransformerFactory.newInstance();
			Transformer transformer = tFactory.newTransformer(new StreamSource(new StringReader(xsl)));

			// Perform the XSL transformation
			transformer.transform(new StreamSource(new StringReader(xml)), output);

			result = ((StreamResult) output).getOutputStream().toString();
		} catch (TransformerConfigurationException e1) {
			e1.printStackTrace();
		} catch (TransformerFactoryConfigurationError e1) {
			e1.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}

		return result;
	}

	public static byte[] generatePDF(String xml, String xslfile) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();

		try {
			Driver driver = new Driver();
			//		  Setup logging here: driver.setLogger(...
			driver.setRenderer(Driver.RENDER_PDF);

			//		  Setup the OutputStream for FOP
			driver.setOutputStream(out);

			//		  Make sure the XSL transformation's result is piped through to FOP
			Result res = new SAXResult(driver.getContentHandler());

			//		  Setup XML input
			Source src = new StreamSource(new StringReader(xml));

			//		  Setup Transformer
			WOApplication application = WOApplication.application();
			WOResourceManager resource_manager = application.resourceManager();
			String xsl = new String(resource_manager.bytesForResourceNamed(xslfile, null, null));
			System.out.println("xsl=" + xsl);
			Source xsltSrc = new StreamSource(new StringReader(xsl));
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer(xsltSrc);

			//		  Start the transformation and rendering process
			transformer.transform(src, res);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		return out.toByteArray();
	}
	
	public static NSArray deserializeArray(String rawxml) {
			NSArray results = null;
			try {
				// Create a stream from the input file.
				ByteArrayInputStream input_stream = new ByteArrayInputStream(rawxml.getBytes());

				// Create an XML-input stream.
				NSXMLInputStream xml_stream = new NSXMLInputStream(input_stream);

				// Read the data.
				results = (NSArray)xml_stream.readObject();

				// Close the streams.
				xml_stream.close();
				input_stream.close();
			}

			catch (IOException e) {
				e.printStackTrace();
			}

			catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			return results;
		}
}