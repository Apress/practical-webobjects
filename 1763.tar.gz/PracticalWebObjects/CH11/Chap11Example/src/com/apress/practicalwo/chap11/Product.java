

// Product.java
// 

package com.apress.practicalwo.chap11;


import java.io.*;

import com.webobjects.foundation.xml.NSXMLOutputStream;

public class Product extends _Product
{
    public Product() {
        super();
    }

/*
    // If you add instance variables to store property values you
    // should add empty implementions of the Serialization methods
    // to avoid unnecessary overhead (the properties will be
    // serialized for you in the superclass).
     * 
     */
   
private void writeObject(ObjectOutputStream stream) throws IOException {
    // Serialize the object's instance members.
    // (This is where you put special encoding logic;
    // this example doesn't perform any special encoding.)

    // Cast stream to NSXMLOutputStream to gain access to
    // <code>writeObject(Object, String)</code>.
    NSXMLOutputStream xml_stream = (NSXMLOutputStream)stream;

    xml_stream.writeObject(name(), "name");
    xml_stream.writeObject(spec(), "spec");
    xml_stream.writeObject(price(), "price");
	xml_stream.writeObject(weight(), "weight");
	xml_stream.writeObject(sku(), "sku");
}

/*
    private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, java.lang.ClassNotFoundException {
		this.setName(in.read)
    }
*/

}
