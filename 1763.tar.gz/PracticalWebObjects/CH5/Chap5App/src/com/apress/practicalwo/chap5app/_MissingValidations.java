package com.apress.practicalwo.chap5app;


import com.webobjects.eocontrol.EOGenericRecord;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to MissingValidations.java instead.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2004
 */  
public abstract class _MissingValidations extends EOGenericRecord 
{


    public static final String OPTIMISTICATTRIBUTE = "optimisticAttribute";
    public static final String UNIQUEATTRIBUTE = "uniqueAttribute";


    public String uniqueAttribute() 
    {
        return (String)storedValueForKey("uniqueAttribute");
    }



    public void setUniqueAttribute(String aValue) 
    {
        takeStoredValueForKey(aValue, "uniqueAttribute");
    }




    public String optimisticAttribute() 
    {
        return (String)storedValueForKey("optimisticAttribute");
    }



    public void setOptimisticAttribute(String aValue) 
    {
        takeStoredValueForKey(aValue, "optimisticAttribute");
    }



}
