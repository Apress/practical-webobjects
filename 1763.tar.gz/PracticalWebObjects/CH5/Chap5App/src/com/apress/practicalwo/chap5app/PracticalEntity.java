package com.apress.practicalwo.chap5app;

import java.util.TimeZone;

import com.apress.practicalwo.practicalutilities.EOFValidationException;

import com.webobjects.foundation.*;


/**
 * Demonstrate how to use the validation classes in PracticalUtilities.
 *
 * @author Charles Hill and Sacha Mallais
 */ 
public class PracticalEntity extends _PracticalEntity
{


    public Number validateChildren(Number value) throws NSValidation.ValidationException
    {
        if (value.intValue() < 0)
        {
            EOFValidationException exception = new EOFValidationException("PracticalEntity.children.belowMinimum", this, "children");
            exception.setFailedValue(value);
            throw exception;
        }

        if (value.intValue() > 50)
        {
            EOFValidationException exception = new EOFValidationException("PracticalEntity.children.aboveMaximum", this, "children");
            exception.setFailedValue(value);
            throw exception;
        }
        return value;
    }



    public NSTimestamp validateBirthdate(NSTimestamp value) throws NSValidation.ValidationException
    {
        NSTimestamp maxDate = new NSTimestamp(1999, 1, 1, 0, 0, 0, TimeZone.getDefault());
        if (value.after(maxDate))
        {
            EOFValidationException exception = new EOFValidationException("PracticalEntity.birthdate.aboveMaximum", this, "birthdate");
            exception.setFailedValue(value);
            throw exception;
        }
        return value;
    }



}
