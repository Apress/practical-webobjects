package com.apress.practicalwo.chap5app;


import com.webobjects.eocontrol.EOGenericRecord;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to ValidatingEO.java instead.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2004
 */  
public abstract class _ValidatingEO extends EOGenericRecord 
{


    public static final String NULLABLEINTEGER = "nullableInteger";
    public static final String NULLABLESTRING = "nullableString";
    public static final String NONNULLSTRING = "nonNullString";


    public String nonNullString() 
    {
        return (String)storedValueForKey("nonNullString");
    }



    public void setNonNullString(String aValue) 
    {
        takeStoredValueForKey(aValue, "nonNullString");
    }




    public String nullableString() 
    {
        return (String)storedValueForKey("nullableString");
    }



    public void setNullableString(String aValue) 
    {
        takeStoredValueForKey(aValue, "nullableString");
    }




    public Number nullableInteger() 
    {
        return (Number)storedValueForKey("nullableInteger");
    }



    public void setNullableInteger(Number aValue) 
    {
        takeStoredValueForKey(aValue, "nullableInteger");
    }



}
