package com.apress.practicalwo.chap5app;


import com.webobjects.eocontrol.EOGenericRecord;
import com.webobjects.foundation.NSTimestamp;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to PracticalEntity.java instead.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2004
 */  
public abstract class _PracticalEntity extends EOGenericRecord 
{


    public static final String BIRTHDATE = "birthdate";
    public static final String CHILDREN = "children";
    public static final String NAME = "name";


    public String name() 
    {
        return (String)storedValueForKey("name");
    }



    public void setName(String aValue) 
    {
        takeStoredValueForKey(aValue, "name");
    }




    public Number children() 
    {
        return (Number)storedValueForKey("children");
    }



    public void setChildren(Number aValue) 
    {
        takeStoredValueForKey(aValue, "children");
    }




    public NSTimestamp birthdate() 
    {
        return (NSTimestamp)storedValueForKey("birthdate");
    }



    public void setBirthdate(NSTimestamp aValue) 
    {
        takeStoredValueForKey(aValue, "birthdate");
    }



}
