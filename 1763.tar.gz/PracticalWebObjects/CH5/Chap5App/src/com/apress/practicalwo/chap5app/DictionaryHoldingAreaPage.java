package com.apress.practicalwo.chap5app;

import java.text.ParsePosition;

import com.webobjects.appserver.*;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.foundation.*;


/**
 * This page demonstrates displaying invalid values that the user types, even when the values
 * are not of the correct type.
 *
 * @author Chuck Hill and Sacha Mallais
 */
public class DictionaryHoldingAreaPage extends WOComponent
{
    public NSMutableDictionary holdingArea = new NSMutableDictionary();
    public NSMutableArray errors = new NSMutableArray();

    public ValidatingEO validatingEO;
    protected EOEditingContext editingContext;


    public DictionaryHoldingAreaPage(WOContext context)
    {
        super(context);
        editingContext = new EOEditingContext();
        validatingEO = new ValidatingEO();
        editingContext.insertObject(validatingEO);
    }



    public void takeValuesFromRequest(WORequest aRequest, WOContext aContext)
    {
        errors.removeAllObjects();
        super.takeValuesFromRequest(aRequest, aContext);
    }



    public WOComponent submit() 
    {
        // We have to validate manually now!  Yuck!  Note that we could have used
        // a holding area only for some of the inputs and bound others directly to
        // the eo

        // ALSO NOTE: since attribute level validation of an eo occurs on saveChanges,
        // we could have left validation to EOF, but that defeats the purpose of having
        // a holding area in the first place...

        Object aValue = null;

        try
        {
            aValue = holdingArea.objectForKey("nonNullString");
            validateTakeValueForKeyPath(aValue, "validatingEO.nonNullString");
        }
        catch (ValidationException e)
        {
            validationFailedWithException(e, aValue, "validatingEO.nonNullString");
        }

        try
        {
            aValue = holdingArea.objectForKey("nullableInteger");

            if (aValue != null)
            {
                // We have to manually coerce this value...
                NSNumberFormatter formatter = new NSNumberFormatter();
                Number coercedValue = (Number)
                    formatter.parseObject((String)aValue, new ParsePosition(0));
                if (coercedValue == null)
                {
                   throw new ValidationException("Invalid number format");
                }
            }

            validateTakeValueForKeyPath(aValue, "validatingEO.nullableInteger");
        }
        catch (ValidationException e)
        {
            validationFailedWithException(e, aValue, "validatingEO.nullableInteger");
        }

        try
        {
            aValue = holdingArea.objectForKey("nullableString");
            validateTakeValueForKeyPath(aValue, "validatingEO.nullableString");
        }
        catch (ValidationException e)
        {
            validationFailedWithException(e, aValue, "validatingEO.nullableString");
        }


        if (errors.count() == 0)
        {
            try
            {
                editingContext.saveChanges();
            }
            catch (ValidationException e)
            {
                errors.addObject(e.getLocalizedMessage());
            }
        }

        return this;
    }



    public void validationFailedWithException(java.lang.Throwable exception, java.lang.Object value, java.lang.String keyPath)
    {
        errors.addObject(exception.getLocalizedMessage());
    }



}
