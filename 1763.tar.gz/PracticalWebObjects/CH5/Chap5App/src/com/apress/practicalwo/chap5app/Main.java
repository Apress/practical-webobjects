package com.apress.practicalwo.chap5app;

import com.webobjects.appserver.*;


public class Main extends WOComponent
{

    public Main(WOContext context)
    {
        super(context);
    }



}
