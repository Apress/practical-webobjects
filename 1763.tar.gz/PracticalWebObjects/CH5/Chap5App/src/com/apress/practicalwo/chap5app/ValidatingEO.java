package com.apress.practicalwo.chap5app;

import com.webobjects.foundation.*;


/**
 * Show how EOF validates eo's: that is, baiscally the same as non-eo's, but with
 * some default validation and object-level validations (validateForSave, etc)
 *
 * @author Charles Hill and Sacha Mallais
 */ 
public class ValidatingEO extends _ValidatingEO
{


    public String validateNonNullString(String value)
            throws NSValidation.ValidationException
    {
        // Since the model says this attribute can NOT be null, we don't need
        // to check that it is null.  We also know that it will be under the maximum length
        // as defined in the model
        if (value.length() < 10)
        {
            throw new ValidationException("Non Null String must be at least 10 characters long");
        }
        return value;
    }



    // Since we take and return Number, we need to use a formatter!
    public Number validateNullableInteger(Number value)
            throws NSValidation.ValidationException
    {
        // Since the model says this attribute can be null, we need to check
        // before trying to do operations on it
        if ((value != null) && (value.intValue() < 0))
        {
            throw new ValidationException("Nullable Integer must be greater than 0");
        }
        return value;
    }



    public String validateNullableString(String value)
            throws NSValidation.ValidationException
    {
        // Since the model says this attribute can be null, we need to check
        // before trying to do operations on it
        if ((value != null) && (value.indexOf('@') == -1))
        {
            throw new ValidationException("Nullable String must include an '@'");
        }
        return value;
    }



    public void validateForInsert() throws NSValidation.ValidationException
    {
        NSMutableArray exceptions = new NSMutableArray();

        // Super's implementation calls validateForSave()
        try
        {
            super.validateForInsert();
        }
        catch (NSValidation.ValidationException e)
        {
            exceptions.addObject(e);
            exceptions.addObjectsFromArray(e.additionalExceptions());
        }

        // Put custom validation for inserting objects here... we don't have any
        // We're overriding this method just for show!

        if (exceptions.count() > 0)
        {
            throw NSValidation.ValidationException.aggregateExceptionWithExceptions(exceptions);
        }
    }



    public void validateForSave() throws NSValidation.ValidationException
    {
        NSMutableArray exceptions = new NSMutableArray();

        // Call super's implementation first
        try
        {
            super.validateForSave();
        }
        catch (NSValidation.ValidationException e)
        {
            exceptions.addObject(e);
            exceptions.addObjectsFromArray(e.additionalExceptions());
        }

        // Custom object-level validation here
        if ((nullableInteger() == null) && ( ! nonNullString().equals("PracticalWO")))
        {
            exceptions.addObject(new NSValidation.ValidationException("If Nullable Integer is null, then Non Null String must equal 'PracticalWO'"));
        }

        if (exceptions.count() > 0)
        {
            throw NSValidation.ValidationException.aggregateExceptionWithExceptions(exceptions);
        }
    }



}
