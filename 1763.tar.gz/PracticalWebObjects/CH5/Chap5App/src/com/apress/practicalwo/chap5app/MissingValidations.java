package com.apress.practicalwo.chap5app;

/**
 *
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2004
 */ 
public class MissingValidations extends _MissingValidations
{


}

