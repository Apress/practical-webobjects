package com.apress.practicalwo.chap6app;

import org.apache.log4j.Logger;

import com.webobjects.appserver.*;


public class Session extends WOSession 
{
    protected static final Logger sessionLogger = Logger.getLogger("com.webobjects.rrloop.session");
    protected static final Logger rrLogger = Logger.getLogger("com.webobjects.rrloop.rrLoopSession");
    

    public void awake()
    {
        sessionLogger.info(sessionID() + " awake");
        sessionLogger.info(context());
        sessionLogger.info(context().page());
        
        sessionLogger.debug(null, new Throwable());
        super.awake();
    }
    
    
    
    public WOComponent restorePageForContextID(String aContextID)
    {
        sessionLogger.info(sessionID() + " about to restore page for contextID " + aContextID);
        WOComponent page = super.restorePageForContextID(aContextID);
        if (page == null)
            sessionLogger.info(sessionID() + " failed to restore page for contextID " + aContextID);
        else
            sessionLogger.info(sessionID() + " restored page " + page.name() + " for contextID " + aContextID);
        sessionLogger.debug(null, new Throwable());
        return page;
    }
    
    
    
    public void takeValuesFromRequest(WORequest aRequest, WOContext aContext)
    {
        rrLogger.info(sessionID() + " takeValuesFromRequest starting");
        rrLogger.debug(null, new Throwable());
        super.takeValuesFromRequest(aRequest, aContext);
        rrLogger.info(sessionID() + " takeValuesFromRequest finished");
    }



    public WOActionResults invokeAction(WORequest aRequest, WOContext aContext) 
    {
        rrLogger.info(sessionID() + " invokeAction finished");
        rrLogger.debug(null, new Throwable());
        WOActionResults result = super.invokeAction(aRequest, aContext);
        rrLogger.info(sessionID() + " invokeAction finished");
        return result;
    }



    public void appendToResponse(WOResponse aResponse, WOContext aContext)
    {
        rrLogger.info(sessionID() + " starting appendToResponse");
        rrLogger.debug(null, new Throwable());
        super.appendToResponse(aResponse, aContext);
        rrLogger.info(sessionID() + " finished appendToResponse");
    }



    public void savePage(WOComponent aPage)
    {
        sessionLogger.info(sessionID() + " saving page " + aPage.name() + " for contextID " + context().contextID());
        sessionLogger.debug(null, new Throwable());
        super.savePage(aPage);
    }



    public void sleep()
    {
        sessionLogger.info(sessionID() + " sleep");
        sessionLogger.debug(null, new Throwable());
        super.sleep();
    }

}