package com.apress.practicalwo.chap6app;

import com.webobjects.appserver.*;

/**
 * Front page.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class Main extends LoggingComponent 
{

    public Main(WOContext context) 
    {
        super(context);
    }



    public WOComponent reload() 
    {
        return this;
    }

}