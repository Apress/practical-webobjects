package com.apress.practicalwo.chap6app;

import org.apache.log4j.Logger;

import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WOResponse;

/**
 * WOResponse that provides additional logging.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class LoggingResponse extends WOResponse
{
    protected static final Logger responseLogger = Logger.getLogger("com.webobjects.rrloop.response");


    public void _finalizeInContext(WOContext aContext)
    {
        responseLogger.info("finalizing in context " + aContext.contextID());
        responseLogger.debug(null, new Throwable());
        super._finalizeInContext(aContext);
    }
    
}
