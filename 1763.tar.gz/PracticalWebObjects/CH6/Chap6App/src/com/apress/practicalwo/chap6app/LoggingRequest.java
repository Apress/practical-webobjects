package com.apress.practicalwo.chap6app;

import org.apache.log4j.Logger;

import com.webobjects.appserver.WORequest;
import com.webobjects.foundation.NSData;
import com.webobjects.foundation.NSDictionary;

/**
 * WORequest that provides additional logging.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class LoggingRequest extends WORequest
{
    protected static final Logger requestLogger = Logger.getLogger("com.webobjects.rrloop.request");
    
    
    public LoggingRequest(String aMethod,
                          String aURL,
                          String anHTTPVersion,
                          NSDictionary someHeaders,
                          NSData aContent,
                          NSDictionary aDictionary)
    {
        super(aMethod, aURL, anHTTPVersion, someHeaders, aContent, aDictionary);
    }



    public String requestHandlerKey()
    {
        String key = super.requestHandlerKey();
        requestLogger.info("returning key " + key + " from " + uri());
        return key;
    }


    
    public boolean _hasFormValues()
    {
        boolean hasFormValues = super._hasFormValues();
        requestLogger.info("has values: " + hasFormValues);
        if (hasFormValues)
        {
            requestLogger.info("has form values: " + formValues());
        }
        else
        {
            requestLogger.info("has no form values, skipping takeValuesFromRequest");
        }
        return hasFormValues; 
    }
}
