
package com.apress.practicalwo.chap6app;
import com.webobjects.appserver.*;

/*
 * Re-implementation of WOTextField to demonstrate how form inputs interact
 * with the request - response loop.
 *
 * @author Charles Hill and Sacha Mallais
 */public class TextInput extends LoggingComponent 
{

    public TextInput(WOContext context) 
    {
        super(context);
        componentLogger.debug(null, new Throwable());
    }



    public boolean synchronizesVariablesWithBindings()
    {
        return false;
    }
    
    
    
    public void takeValuesFromRequest(WORequest aRequest, WOContext aContext)
    {
        if (aContext._wasFormSubmitted())
        {
            aContext.appendElementIDComponent("1");
            componentLogger.info("element name " + aContext.elementID());
            String formValue = aRequest.stringFormValueForKey(aContext.elementID());
            setValueForBinding(formValue, "value");
            aContext.deleteLastElementIDComponent();
        }
    }

}