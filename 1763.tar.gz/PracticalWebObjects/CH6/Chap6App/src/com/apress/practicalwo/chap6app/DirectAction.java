package com.apress.practicalwo.chap6app;

import com.webobjects.appserver.*;

public class DirectAction extends WODirectAction 
{

    public DirectAction(WORequest aRequest) 
    {
        super(aRequest);
    }

    
    
    public WOActionResults defaultAction() 
    {
        return pageWithName("Main");
    }



    public WOActionResults RRLoopAction() 
    {
        return pageWithName("RRLoop");
    }
}