package com.apress.practicalwo.chap6app;

import org.apache.log4j.Logger;

import com.webobjects.appserver.*;

/**
 * WOComponent sub-class that provides logging of the request - response loop
 * methods.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class LoggingComponent extends WOComponent
{
    protected static final Logger componentLogger = Logger.getLogger("com.webobjects.rrloop.component");
    protected static final Logger rrLogger = Logger.getLogger("com.webobjects.rrloop.rrLoopComponent");


    /**
     * @param arg0
     */
    public LoggingComponent(WOContext arg0)
    {
        super(arg0);
        componentLogger.info("Creating component " + name());
    }



    public void _awakeInContext(WOContext wocontext)
    {
        componentLogger.info(name() + " _awakeInContext");
        super._awakeInContext(wocontext);
    }

    
    
    public void awake()
    {
        componentLogger.info(name() + " awake, context " + context().contextID());
        componentLogger.debug(null, new Throwable());
       
        super.awake();
    }
    
    
    
    public WOElement template()
    {
        componentLogger.info("Returning template for " + name());
        componentLogger.debug(null, new Throwable());
        return super.template();
    }
    
    
    
    public void takeValuesFromRequest(WORequest aRequest, WOContext aContext)
    {
        rrLogger.info(name() + " takeValuesFromRequest starting");
        rrLogger.info(name() + " template() is " + template());
        rrLogger.debug(null, new Throwable());
        super.takeValuesFromRequest(aRequest, aContext);
        rrLogger.info(name() + " takeValuesFromRequest finished");
    }



    public WOActionResults invokeAction(WORequest aRequest, WOContext aContext) 
    {
        rrLogger.info(name() + " invokeAction starting for sender " + aContext.senderID());
        rrLogger.debug(null, new Throwable());
        WOActionResults result = super.invokeAction(aRequest, aContext);
        rrLogger.info(name() + " invokeAction finished for sender " + aContext.senderID());
        return result;
    }



    public void appendToResponse(WOResponse aResponse, WOContext aContext)
    {
        rrLogger.info(name() + " starting appendToResponse");
        rrLogger.debug(null, new Throwable());
        super.appendToResponse(aResponse, aContext);
        rrLogger.info(name() + " finished appendToResponse");
    }



    public void sleep()
    {
        componentLogger.info(name() + " sleep, context " + context().contextID());
        componentLogger.debug(null, new Throwable());
        super.sleep();
    }


}
