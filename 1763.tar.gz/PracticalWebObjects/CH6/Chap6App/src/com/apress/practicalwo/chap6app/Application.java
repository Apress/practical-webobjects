package com.apress.practicalwo.chap6app;

import java.io.InputStream;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.webobjects.appserver.*;
import com.webobjects.foundation.*;

/**
 * Application demonstrating how the Request - Response Loop works and how to use
 * log4J to investigate WebObjects.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class Application extends WOApplication 
{
    protected Logger dispatchLogger;
    protected Logger applicationLogger;
    protected Logger rrLogger;
    protected Logger generationLogger;


    public static void main(String argv[]) 
    {
        WOApplication.main(argv, Application.class);
    }



    public Application() 
    {
        super();
        
        // log4j Configuration
        PropertyConfigurator.configure(resourceManager().pathURLForResourceNamed("log4j.properties", null, null));
        dispatchLogger = Logger.getLogger("com.webobjects.rrloop.dispatch");
        applicationLogger = Logger.getLogger("com.webobjects.rrloop.application");
        rrLogger = Logger.getLogger("com.webobjects.rrloop.application.rrloopApplication");
        generationLogger = Logger.getLogger("com.webobjects.rrloop.generation");
    }



    public WORequest createRequest(String aMethod,
                                   String aURL,
                                   String anHTTPVersion,
                                   NSDictionary someHeaders,
                                   NSData aContent,
                                   NSDictionary someInfo)
    {
        dispatchLogger.info("Creating request for URL: " + aURL);
        dispatchLogger.debug(null, new Throwable());
        return new LoggingRequest(aMethod, aURL, anHTTPVersion, someHeaders, aContent, someInfo);
    }



    public WOResponse dispatchRequest(WORequest aRequest) 
    {
        dispatchLogger.info("Starting to dispatch request: " + aRequest.uri());
        dispatchLogger.debug(null, new Throwable());
        WOResponse result = super.dispatchRequest(aRequest);
        dispatchLogger.info("Finished dispatching request: " + aRequest.uri());
        dispatchLogger.info("-------------------------------------\n");
        return result;
    }



    public WORequestHandler handlerForRequest(WORequest aRequest)
    {
        applicationLogger.info("Finding handler for request: " + aRequest.uri());
        dispatchLogger.debug(null, new Throwable());
        WORequestHandler handler = super.handlerForRequest(aRequest);
        applicationLogger.info("Returning handler: " + handler.toString());
        return handler;
    }



    public WOContext createContextForRequest(WORequest aRequest) 
    {
        applicationLogger.info("Creating context for response to request: " + aRequest.uri());
        dispatchLogger.debug(null, new Throwable());
        WOContext aContext = super.createContextForRequest(aRequest);
        applicationLogger.info("context page: " + aContext.page());
        
        return aContext;
    }
    
    
    
    public void awake()
    {
        applicationLogger.info("awake");
        applicationLogger.debug(null, new Throwable());
        super.awake();
    }



    public WOSession createSessionForRequest(WORequest aRequest)
    {
        WOSession aSession = super.createSessionForRequest(aRequest);
        applicationLogger.info("Creating new Session " + aSession.sessionID() + " for request: " + aRequest.uri());
        applicationLogger.debug(null, new Throwable());
        return aSession;
    }
    


    public WOSession restoreSessionWithID(String aSessionID,
                                          WOContext aContext)
    {
        applicationLogger.info("Restoring session with ID " + aSessionID + " in context " + aContext.contextID());
        applicationLogger.debug(null, new Throwable());
        return super.restoreSessionWithID(aSessionID, aContext);
    }


    
    public WOResponse createResponseInContext(WOContext aContext)
    {
        applicationLogger.info("Creating response in context: " + aContext.contextID());
        applicationLogger.debug(null, new Throwable());
        return new LoggingResponse();
    }



    public void takeValuesFromRequest(WORequest aRequest, WOContext aContext)
    {
        rrLogger.info("takeValuesFromRequest starting");
        rrLogger.debug(null, new Throwable());
        super.takeValuesFromRequest(aRequest, aContext);
        rrLogger.info("takeValuesFromRequest finished");
    }



    public WOActionResults invokeAction(WORequest aRequest, WOContext aContext) 
    {
        rrLogger.info("invokeAction started");
        rrLogger.debug(null, new Throwable());
        WOActionResults result = super.invokeAction(aRequest, aContext);
        rrLogger.info("invokeAction finished");
        return result;
    }



    public WOResponse responseForComponentWithName(String name,
                                                   NSDictionary bindings,
                                                   NSDictionary headers,
                                                   NSDictionary userInfo,
                                                   String uriPrefix,
                                                   String appName)
    {
        generationLogger.info("Creating responseForComponentWithName " + name);
        generationLogger.debug(null, new Throwable());
        return super.responseForComponentWithName(name,
                                                  bindings,
                                                  headers,
                                                  userInfo,
                                                  uriPrefix,
                                                  appName);
    }
    


    public WOResponse responseForDirectActionWithNameAndClass(String actionName,
                                                              String className,
                                                              NSDictionary formValueDict,
                                                              InputStream contentStream,
                                                              NSDictionary headers,
                                                              NSDictionary userInfo,
                                                              String uriPrefix,
                                                              String appName)
    {
        generationLogger.info("Creating responseForDirectActionWithNameAndClass " + actionName + " in " + className);
        generationLogger.debug(null, new Throwable());
        return super.responseForDirectActionWithNameAndClass(actionName,
                                                             className,
                                                             formValueDict,
                                                             contentStream,
                                                             headers,
                                                             userInfo,
                                                             uriPrefix,
                                                             appName);
    }
  


    public WOComponent pageWithName(String aName, WOContext aContext) 
    {
        generationLogger.info("pageWithName " + aName);
        generationLogger.debug(null, new Throwable());
        WOComponent page = super.pageWithName(aName, aContext);
        generationLogger.info("pageWithName created page named " + page.name());
        return page; 
    }



    public WOElement dynamicElementWithName(String name, NSDictionary associations, WOElement children, NSArray languages) 
    {
        generationLogger.info("creating dynamicElementWith name " + name);
        generationLogger.info("creating dynamicElementWith associations " + associations);
        generationLogger.info("creating dynamicElementWith children " + children);
        generationLogger.info("creating dynamicElementWith languages " + languages);
        generationLogger.debug(null, new Throwable());
        
        return super.dynamicElementWithName(name, associations, children, languages); 
    }



    public void appendToResponse(WOResponse aResponse, WOContext aContext)
    {
        rrLogger.info("appendToResponse started");
        rrLogger.debug(null, new Throwable());
        super.appendToResponse(aResponse, aContext);
        rrLogger.info("appendToResponse finished");
    }
    


    public void saveSessionForContext(WOContext aContext)
    {
        applicationLogger.info("Saving session with ID " + aContext.session().sessionID() + 
        " in context " + aContext.contextID());
        applicationLogger.debug(null, new Throwable());
        super.saveSessionForContext(aContext);
    }



    public void sleep()
    {
        applicationLogger.info("sleeping");
        applicationLogger.debug(null, new Throwable());
       super.sleep();
    }

}