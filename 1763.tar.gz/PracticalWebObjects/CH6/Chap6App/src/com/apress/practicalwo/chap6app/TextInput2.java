package com.apress.practicalwo.chap6app;

import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WORequest;
import com.webobjects.appserver.WOResponse;

/**
 * Re-implementation of WOTextField to demonstrate how form inputs interact
 * with the request - response loop.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class TextInput2 extends LoggingComponent
{
    public TextInput2(WOContext context)
    {
        super(context);
    }



    public boolean synchronizesVariablesWithBindings()
    {
        return false;
    }
    
    
    
    public void takeValuesFromRequest(WORequest aRequest, WOContext aContext)
    {
        componentLogger.debug("element name " + aContext.elementID());
        if (aContext._wasFormSubmitted())
        {
            String formValue = aRequest.stringFormValueForKey(aContext.elementID());
            setValueForBinding(formValue, "value");
        }
    }


    
    public void appendToResponse(WOResponse aResponse, WOContext aContext)
    {
        rrLogger.debug(name() + " starting appendToResponse");
        aResponse.appendContentString("<input type=\"text\" name=\"");
        aResponse.appendContentString(aContext.elementID());
        aResponse.appendContentString("\" value=\"");
        
        String aValue = (String)valueForBinding("value");
        if (aValue != null)
        {
            aResponse.appendContentString(aValue);
        }
        
        aResponse.appendContentString("\">");
        rrLogger.debug(name() + " finished appendToResponse");
    }


}
