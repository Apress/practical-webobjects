package com.apress.practicalwo.appserver;


import com.apress.practicalwo.practicalutilities.EOModelConnector;
import com.apress.practicalwo.practicalutilities.EOPrototypeSwitcher;
import com.webobjects.appserver.WOApplication;
import com.webobjects.eoaccess.EOModelGroup;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSBundle;
import com.webobjects.foundation.NSDictionary;
import com.webobjects.foundation.NSPropertyListSerialization;


/**
 * Sub-class of WOApplication that hold support code used by all example applications.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class PWOApplication extends WOApplication
{

    public PWOApplication() 
    {
        super();
        
        // Configuring and activating the model connector and protottype switcher
        // needs to happen BEFORE setting the delegates etc. as they will cause the
        // models to load and the notifications to be sent!

        // Make sure all the models are using the correct set of prototypes 
        EOPrototypeSwitcher prototypeSwitcher = new EOPrototypeSwitcher(databaseType());
        prototypeSwitcher.listenForAddedModels();
        
        // Make sure all the models are using the correct connection dictionaries 
        EOModelConnector modelConnector = new EOModelConnector(connectionDictionary(), 
                                                               NSArray.EmptyArray);
        modelConnector.listenForAddedModels();
        
        //      This line causes the EOModels to be loaded from the bundles referenced on the classpath.
        //      This ensures that the model configuration is done before the temporary
        //      objects above are garbage collected.
        EOModelGroup.defaultGroup().models();
    }
    
    
    
        /**
         * Overridden to prevent direct access to pages with URLs like
         * http://localhost/cgi-bin/WebObjects/Chap4App.woa/-1697/wo/SecretPage.wo
         */
        /* Uncomment to enable this.
        public WOComponent pageWithName(String pageName, WOContext context) 
        {
            if ((context.senderID() == null) && 
                (componentRequestHandlerKey().equals(
                     context.request().requestHandlerKey()))) {
                pageName = null;
            }


           return super.pageWithName(pageName, context);
        }
         */


    
        /**
         * Returns the configuration dictionary for this application.
         *
         * @return the configuration dictionary for this application
         */
        public NSDictionary configurationDictionary()
        {
            NSBundle bundle = NSBundle.mainBundle();
            byte[] tableBytes = bundle.bytesForResourcePath("ApplicationConfiguration.plist");
            String tableString = new String(tableBytes);
            return (NSDictionary)NSPropertyListSerialization.propertyListFromString(tableString);
        
            /** ensure [valid_result] Result != null;  **/

        }

    

        /**
         * Returns the connection dictionary configured for this application.
         *
         * @return the connection dictionary configured for this application
         */
        public NSDictionary connectionDictionary()
        {
            NSDictionary connectionDictionaries =
                (NSDictionary) configurationDictionary().objectForKey("connectionDictionaries"); 

            if (connectionDictionaries == null)
            {
                throw new IllegalArgumentException("connectionDictionaries" + 
                    " key missing from configuration dictionary");
            }
        
            if (connectionDictionaries.objectForKey(databaseType()) == null)
            {
                throw new IllegalArgumentException(databaseType() + 
                    " key missing from connectionDictionaries.");
            }
        
            return (NSDictionary) connectionDictionaries.objectForKey(databaseType());

            /** ensure
            [valid_result] Result != null;
            [url_key_is_present] Result.objectForKey("URL") != null; **/
        }



        /**
         * Returns the database type dictionary configured for this application.
         *
         * @return dictionary configured for this application
         */
         public String databaseType()
        {
            if (configurationDictionary().objectForKey("databaseType") == null)
            {
                throw new IllegalArgumentException("databaseType" + 
                    " key missing from configuration dictionary");
            }
        
            return (String) configurationDictionary().objectForKey("databaseType");
        
            /** ensure [valid_result] Result != null;  **/
        }
    
    
    
}
