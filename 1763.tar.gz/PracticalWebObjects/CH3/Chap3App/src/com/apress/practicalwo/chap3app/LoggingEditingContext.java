package com.apress.practicalwo.chap3app;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.eocontrol.EOObjectStore;
import com.webobjects.foundation.NSLog;


/**
 *  EOEditingContext sub-class that logs when significant methods are called.
 */
public class LoggingEditingContext extends EOEditingContext
{

    public LoggingEditingContext(EOObjectStore parent)
    {
        super(parent);
    }

    public LoggingEditingContext()
    {
        super();
    }


    public void lock()
    {
        NSLog.out.appendln("Locking LoggingEditingContext" + this);
        super.lock();
    }



    public void unlock()
    {
        NSLog.out.appendln("Unlocking LoggingEditingContext" + this);
        super.unlock();
    }



    public void dispose()
    {
        NSLog.out.appendln("Disposing LoggingEditingContext" + this);
        super.dispose();
    }



    public void finalize() throws Throwable
    {
        NSLog.out.appendln("Finalizing LoggingEditingContext" + this);
        super.finalize();
    }

    
}
