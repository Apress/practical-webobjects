package com.apress.practicalwo.chap3app;

import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.foundation.NSLog;


/**
 *  Component showing how locking and nested editing contexts really work.
 */
public class NestedLockTest extends WOComponent 
{

    public NestedLockTest(WOContext context) 
    {
        super(context);
    }



    /**
     * Action method showing that allowing a locked child to be garbage collected
     * result in a lock being left on the parent and subsequent deadlock.
     * 
     * @return this page
     */
    public WOComponent testGCOfLockedChild() 
    {
        EOEditingContext nestedEC = 
            new LoggingEditingContext(session().defaultEditingContext());
        nestedEC.lock();
        nestedEC = null;
        System.gc();
        
        // Wait 5 seconds so we can make a request on a different worker thread.
        try 
        {
            Thread.sleep(5000);
        }
        catch (InterruptedException e)
        {
        }
        
        return this;
    }



    /**
     * Action method showing that locking a child EC also locks the parent.
     * 
     * @return this page
     */
    public WOComponent testChildLocksParent() 
    {
        NSLog.allowDebugLoggingForGroups(NSLog.DebugGroupMultithreading);

        EOEditingContext parentEC = new LoggingEditingContext();
        EOEditingContext childEC = new LoggingEditingContext(parentEC);

        NSLog.out.appendln("\nParent EC is: " + parentEC);
        NSLog.out.appendln("Child EC is: " + childEC);

        NSLog.out.appendln("\nLock child:");
        childEC.lock();

        NSLog.out.appendln("\nUnlock child:");
        childEC.unlock();

        NSLog.out.appendln("\nLock parent:");
        parentEC.lock();

        NSLog.out.appendln("\nUnlock parent:");
        parentEC.unlock();
        
        return this;
    }



    /**
     * Method to reload page to test for deadlock.
     *
     *
     * @return this page
     */
    public WOComponent reloadPage() 
    {
        return this;
    }

}