package com.apress.practicalwo.chap3app;

import com.apress.practicalwo.practicalutilities.LockErrorScreamerEditingContext;
import com.apress.practicalwo.practicalutilities.tests.CooperatingEditingContextTestObject;
import com.apress.practicalwo.practicalutilities.tests.NamedObject;
import com.webobjects.appserver.*;
import com.webobjects.eoaccess.*;
import com.webobjects.eocontrol.*;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSDictionary;
import com.webobjects.foundation.NSKeyValueCoding;



/**
 * Examples and tests of refreshing objects.  Also shows some low level EOAccess
 * calls to change database behind EOF's back.
 */
public class RefreshingObjects extends WOComponent 
{
    // For tests
    CooperatingEditingContextTestObject testObject;
    String newValue;

    // For EOAccess calls
    EOGlobalID testObjectID;
    EOQualifier testObjectQualifier;
    EOEntity testObjectEntity;
    
    // To show snapshot changes in another eC
    EOEditingContext secondEC;
    EOEnterpriseObject alternateTestObject;
        
        
    public RefreshingObjects(WOContext context) 
    {
        super(context);
        
        // Create main test object
        testObject = new CooperatingEditingContextTestObject();
        editingContext().insertObject(testObject);
        testObject.setStringValue("original value");
        editingContext().saveChanges();
        
        // Create object for to-one relationship
        CooperatingEditingContextTestObject relatedObject = new CooperatingEditingContextTestObject();
        editingContext().insertObject(relatedObject);
        relatedObject.setStringValue("related object");
        testObject.addObjectToBothSidesOfRelationshipWithKey(relatedObject, "relatedObject");
        editingContext().saveChanges();

        // Create objects for to-many relationship
        NamedObject dummy1 = new NamedObject();
        NamedObject dummy2 = new NamedObject();
        editingContext().insertObject(dummy1);
        editingContext().insertObject(dummy2);
        dummy1.setName("fred");
        dummy2.setName("mary");
        testObject.addObjectToBothSidesOfRelationshipWithKey(dummy1, "namedObjects");
        testObject.addObjectToBothSidesOfRelationshipWithKey(dummy2, "namedObjects");
        editingContext().saveChanges();
        
        // Cache objects needed for EOAccess calls.
        testObjectID = editingContext().globalIDForObject(testObject);
        testObjectQualifier = 
            EOUtilities.qualifierForEnterpriseObject(editingContext(),
                                                     testObject);
        testObjectEntity = EOUtilities.entityForObject(editingContext(), testObject);

        // Get copy of test object in a different editing context
        secondEC = new LockErrorScreamerEditingContext();
        secondEC.lock();
        try
        {
            alternateTestObject = EOUtilities.localInstanceOfObject(secondEC, testObject);
        }
        finally
        {
            secondEC.unlock();
        }
    }



    /**
     * Write the updated value to the database before starting on the RR Loop.
     * This is done here instead of awake as this should not happen the first
     * time through.
     */
    public WOActionResults invokeAction(WORequest aRequest, WOContext aContext)
    {
        updateValue();
        return super.invokeAction(aRequest, aContext);
    }



    /**
     * Calculates the next "new value" to display. 
     */
    public void appendToResponse(WOResponse aResponse, WOContext aContext)
    {
        String timeInMillis = new Long(System.currentTimeMillis()).toString(); 
        newValue = timeInMillis.substring(timeInMillis.length() - 5);
        
        super.appendToResponse(aResponse, aContext);
    }



    /**
     * Just redisplays page.
     */
    public WOComponent redisplayOnly() 
    {
        return this;
    }


    
    /**
     * Calls ec.refreshObject() on test object.
     */
    public WOComponent testRefreshObject() 
    {
        editingContext().refreshObject(testObject);
        return this;
    }
    
    


    /**
     * Sets the editing context fetch timestamp to now and calls ec.refreshObject() 
     * on test object.
     */    
    public WOComponent testRefreshObjectAfterFetchTimestamp() 
    {
        editingContext().setFetchTimestamp(System.currentTimeMillis());
        editingContext().refreshObject(testObject);
        return this;
    }




    /**
     * Sets the editing context fetch timestamp to now and refreshes all objects in
     * this editing context by calling ec.refreshAllObjects()
     */    
    public WOComponent testRefreshAllObjectsAfterFetchTimestamp() 
    {
        editingContext().setFetchTimestamp(System.currentTimeMillis());
        editingContext().refreshAllObjects();
        return this;
    }



    /**
     * Uses a plain fetch spec to fetch all instances of the Entity of testObject.
     */
    public WOComponent testPlainFetchSpec() 
    {
        EOFetchSpecification fetchSpec = new EOFetchSpecification();
        fetchSpec.setEntityName("CooperatingEditingContextTestObject");
        editingContext().objectsWithFetchSpecification(fetchSpec);        
                         
        return this;
    }
    
    
    /**
     * Uses a refreshing fetch spec to fetch all instances of the Entity of testObject.
     */
    public WOComponent testRefreshingFetchSpec() 
    {
        EOFetchSpecification fetchSpec = new EOFetchSpecification();
        fetchSpec.setEntityName("CooperatingEditingContextTestObject");
        fetchSpec.setRefreshesRefetchedObjects(true);
        editingContext().objectsWithFetchSpecification(fetchSpec);        
                         
        return this;
    }
    


    /**
     * Sets the editing context fetch timestamp to now and refetches all instances 
     * of the Entity of testObject to show this is the same as a refreshing fetch spec
     */     
    public WOComponent testFretchAfterFetchTimestamp() 
    {
        editingContext().setFetchTimestamp(System.currentTimeMillis());
        EOFetchSpecification fetchSpec = new EOFetchSpecification();
        fetchSpec.setEntityName("CooperatingEditingContextTestObject");
        editingContext().objectsWithFetchSpecification(fetchSpec);   

        return this;
    }


    
    /**
     * Calls ec.invalidateObjectsWithGlobalIDs() on test object.
     */
    public WOComponent testInvalidateObject() 
    {
        editingContext().invalidateObjectsWithGlobalIDs(new NSArray(testObjectID));
        return this;
    }



    /**
     * Invalidates all objects in this editing context by calling 
     * ec.invalidateAllObjects().
     */
    public WOComponent testInvalidateAllObjects() 
    {
        editingContext().invalidateAllObjects();
        return this;
    }    
    
    
    
    /**
     * Nulls the snapshot for the to-many relationship namedObjects out of 
     * testObject to show that this results in that relationship getting refreshed.
     * This does not work for to-one relationships.
     */
    public WOComponent testRefreshToMany() 
    {
        refreshToManyRelationship(testObject, "namedObjects");
        return this;
    }

  
  
    /**
     * Nulls the snapshot for named the to-many relationship out of sourceObject
     * so that this will be refreshed.
     *
     * @param sourceObject the object with the out of date relationship
     * @param the name of the relationship to refresh.
     */
    public void refreshToManyRelationship(EOEnterpriseObject sourceObject,
                                          String relationshipName) 
    {
        /** require [valid_object] sourceObject != null;
                    [object_in_ec] sourceObject.editingContext() != null;
                    [valid_relationship] 
                        sourceObject.toManyRelationshipKeys().containsObject(relationshipName);
         **/
        
        // Get the global lock
        EOObjectStoreCoordinator.defaultCoordinator().lock();
        try
        {
            EOEditingContext sourceEditingContext = sourceObject.editingContext();
            EOEntity sourceObjectEntity = EOUtilities
                .entityForObject(sourceEditingContext, sourceObject);
            EOModel sourceObjectModel = sourceObjectEntity.model();
            EOGlobalID sourceGlobalID = sourceEditingContext.globalIDForObject(sourceObject);
            EODatabaseContext dbContext = EODatabaseContext
                .registeredDatabaseContextForModel(sourceObjectModel, 
                                                   sourceEditingContext);
            EODatabase database = dbContext.database();
            database.recordSnapshotForSourceGlobalID(null, sourceGlobalID, relationshipName);
        }
        finally
        {
            EOObjectStoreCoordinator.defaultCoordinator().unlock();
        }
        
        /** ensure [to_many_snapshot_null] 
             /# too lazy to make methods to check this #/ true; **/
    }
    
    


    /**
     * Uses EOAccess classes to delete the relatedObject of testObject from the
     * database without EOF being aware of it.  This can be used to test refreshing
     * relationships.  It leaves TestObject with a FK pointing to the deleted row.
     */
    public WOComponent deleteToOne()
    {
        // Get the global lock
        EOObjectStoreCoordinator.defaultCoordinator().lock();
        try
        {
            EODatabaseContext dbContext = 
            EOUtilities.databaseContextForModelNamed(editingContext(), 
            "PracticalUtilitiesTestEOModel");
            EOAdaptorChannel adChannel = dbContext.availableChannel().adaptorChannel();
        
            adChannel.deleteRowDescribedByQualifier(
                EOUtilities.qualifierForEnterpriseObject(editingContext(),
                                                         testObject.relatedObject()),
                testObjectEntity);
        }
        finally
        {
            EOObjectStoreCoordinator.defaultCoordinator().unlock();
        }
        
        return this;
    }
    


    /**
     * Uses EOAccess classes to delete the relatedObject of testObject from the
     * database without EOF being aware of it.  This can be used to test refreshing
     * relationships.  It nulls out the TestObject's FK pointing to the deleted row.
     */
    public WOComponent deleteToOneAndNullify() 
    {
        deleteToOne();
         
        // Get the global lock and null the FK 
        EOObjectStoreCoordinator.defaultCoordinator().lock();
        try
        {
            EODatabaseContext dbContext = 
            EOUtilities.databaseContextForModelNamed(editingContext(), 
            "PracticalUtilitiesTestEOModel");
            EOAdaptorChannel adChannel = dbContext.availableChannel().adaptorChannel();
        
            adChannel.updateValuesInRowDescribedByQualifier(
                new NSDictionary(NSKeyValueCoding.NullValue, "relatedID"),
                testObjectQualifier,
                testObjectEntity);
        }
        finally
        {
            EOObjectStoreCoordinator.defaultCoordinator().unlock();
        }
        
        return null;
    }



    /**
     * Uses EOAccess classes to delete the namedObjects of testObject from the
     * database without EOF being aware of it.  This can be used to test refreshing
     * relationships. 
     */
    public WOComponent deleteToMany()
    {
        // Get the global lock
        EOObjectStoreCoordinator.defaultCoordinator().lock();
        try
        {
            EODatabaseContext dbContext = 
            EOUtilities.databaseContextForModelNamed(editingContext(), 
            "PracticalUtilitiesTestEOModel");
            EOAdaptorChannel adChannel = dbContext.availableChannel().adaptorChannel();
        
            for (int i = 0; i < testObject.namedObjects().count(); i++)
            {
                NamedObject objectToDelete = (NamedObject)testObject.namedObjects().objectAtIndex(i);
                EOQualifier objectQualfiier = 
                    EOUtilities.qualifierForEnterpriseObject(editingContext(), objectToDelete);
                EOEntity objectEntity = EOUtilities.entityForObject(editingContext(), objectToDelete);
                adChannel.deleteRowDescribedByQualifier(objectQualfiier, objectEntity);
            }
        }
        finally
        {
            EOObjectStoreCoordinator.defaultCoordinator().unlock();
        }
        
        return this;
    }


  
    /**
     * Uses EOAccess classes to update the stringValue attribute of testObject 
     * in the database without EOF being aware of it.  This can be used to test 
     * refreshing attributes. 
     */
    public void updateValue()
    {
        // Get the global lock
        EOObjectStoreCoordinator.defaultCoordinator().lock();
        try
        {
            EODatabaseContext dbContext = 
            EOUtilities.databaseContextForModelNamed(editingContext(), 
            "PracticalUtilitiesTestEOModel");
            EOAdaptorChannel adChannel = dbContext.availableChannel().adaptorChannel();
        
            adChannel.updateValuesInRowDescribedByQualifier(
                new NSDictionary(newValue, "stringValue"),
                testObjectQualifier,
                testObjectEntity);
        }
        finally
        {
            EOObjectStoreCoordinator.defaultCoordinator().unlock();
        }
    }
    


    /**
     * Convenience method returing the main editing context to use.  We use the
     * session's default to avoid having to lock. 
     */
    public EOEditingContext editingContext()
    {
        return session().defaultEditingContext();
    }



    /**
     * Returns the committed snapshot for testObject.  This is taken from another
     * editing context to avoid any possibility of refreshing contaminating the
     * snapshots in editingContext()
     *  
     * @return the committed snapshot for testObject
     */
    public NSDictionary committedSnapshot()
    {
        secondEC.lock();
        NSDictionary committedSnapshot = secondEC.committedSnapshotForObject(alternateTestObject);
        secondEC.unlock();
        
       return committedSnapshot;
    }


}