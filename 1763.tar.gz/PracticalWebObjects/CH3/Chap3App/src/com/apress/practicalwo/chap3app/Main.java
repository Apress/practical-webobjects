package com.apress.practicalwo.chap3app;

import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;


/**
 * The main page, a bunch of links and nothing else.
 */
public class Main extends WOComponent 
{

    public Main(WOContext context) 
    {
        super(context);
    }

}