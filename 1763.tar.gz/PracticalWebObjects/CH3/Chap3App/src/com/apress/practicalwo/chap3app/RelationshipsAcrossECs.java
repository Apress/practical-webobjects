package com.apress.practicalwo.chap3app;

import com.apress.practicalwo.practicalutilities.tests.CooperatingEditingContextTestObject;
import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.foundation.NSLog;


/**
 * Component to demonstrate the exception from relationships between objects in 
 * different editing contexts, the warning messages resulting from accessing
 * an editing context when it is not locked, and the progress of the Request -
 * Reponse loop. 
 */
public class RelationshipsAcrossECs extends WOComponent 
{


    public RelationshipsAcrossECs(WOContext context) 
    {
        super(context);
    }



    public WOComponent saveChanges() 
    {

        CooperatingEditingContextTestObject inDefaultEC;
        CooperatingEditingContextTestObject inPeerEC;
        
        inDefaultEC = new CooperatingEditingContextTestObject();
        session().defaultEditingContext().insertObject(inDefaultEC);
        inDefaultEC.setStringValue("default");
        
        // This editing context is not locked on purpose to demonstrate the
        // access without lock debugging messages.
        EOEditingContext peerEditingContext = new EOEditingContext();
        inPeerEC = new CooperatingEditingContextTestObject();
        peerEditingContext.insertObject(inPeerEC);
        inPeerEC.setStringValue("peer");
        
        // Here is where we go wrong!
        inPeerEC.setRelatedObject(inDefaultEC);
        
        peerEditingContext.saveChanges();
        
        return this;
    }
    
    
    
    public void awake()
    {
        NSLog.out.appendln(Thread.currentThread().getName() + " " + name() + " awake");
        super.awake();
        
    }
    
    
    
    public void sleep()
    {
        NSLog.out.appendln(Thread.currentThread().getName() + " " + name() + " sleep");
        super.sleep();
        
    }

}