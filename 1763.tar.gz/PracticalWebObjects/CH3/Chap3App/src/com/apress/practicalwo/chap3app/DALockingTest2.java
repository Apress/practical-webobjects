package com.apress.practicalwo.chap3app;

import com.webobjects.appserver.*;
import com.webobjects.foundation.NSLog;


/**
 * Component created by direct action to demonstrate the Request - Response loop 
 * and potential locking issues.
 */
public class DALockingTest2 extends WOComponent 
{


    public DALockingTest2(WOContext context) 
    {
        super(context);
        NSLog.out.appendln(Thread.currentThread().getName() + " creating new " + name());
  }


    public void awake()
    {
        NSLog.out.appendln(Thread.currentThread().getName() + " " + name() + " awake");
        super.awake();
        
    }

                                     
    
    public void takeValuesFromRequest(WORequest aRequest,
                                      WOContext aContext)
    {
        NSLog.out.appendln(Thread.currentThread().getName() + " " + name() + " takeValuesFromRequest");
        super.takeValuesFromRequest(aRequest, aContext);
        
    }
    
    
    
    public WOActionResults invokeAction(WORequest aRequest,
                                        WOContext aContext)
    {
        NSLog.out.appendln(Thread.currentThread().getName() + " " + name() + " invokeAction");
        return super.invokeAction(aRequest, aContext);
        
    }


    public void appendToResponse(WOResponse aResponse,
                                 WOContext aContext)
    {
        NSLog.out.appendln(Thread.currentThread().getName() + " " + name() + " appendToResponse");
        session().sessionID();  // Dummy reference to force session to awake
        super.appendToResponse(aResponse, aContext);
        
    }
    
    public void sleep()
    {
        NSLog.out.appendln(Thread.currentThread().getName() + " " + name() + " sleep");
        super.sleep();
        
    }
}