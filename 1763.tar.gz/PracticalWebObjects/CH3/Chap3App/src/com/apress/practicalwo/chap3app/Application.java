package com.apress.practicalwo.chap3app;

import com.apress.practicalwo.appserver.PWOApplication;
import com.apress.practicalwo.practicalutilities.EOFDebugAdditions;
import com.webobjects.appserver.WOApplication;
import com.webobjects.appserver.WORequest;
import com.webobjects.appserver.WOResponse;
import com.webobjects.eoaccess.EODatabaseChannel;
import com.webobjects.eoaccess.EODatabaseContext;
import com.webobjects.eoaccess.EOUtilities;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.eocontrol.EOObjectStoreCoordinator;
import com.webobjects.foundation.NSLog;



/**
 * WOApplication sub-class to activate debug logging and to log out progress of
 * Request - Respose loop.
 */
public class Application extends PWOApplication 
{

    
    public static void main(String argv[]) 
    {
        WOApplication.main(argv, Application.class);
    }

    
    
    /** 
     * Constructor to setup debugging and logging.
     */
    public Application() 
    {
        super();
        
        // Set this to false to test application without concurrent request
        // handling.
        setAllowsConcurrentRequestHandling(true);
        NSLog.out.appendln("Application is handling requests concurrently " +
            isConcurrentRequestHandlingEnabled());
        
        // Activate logging of SQL sent to DB by EOF.
        EOFDebugAdditions.logSQL(true);

        // Activate EOF's missing lock logging
        NSLog.allowDebugLoggingForGroups(NSLog.DebugGroupMultithreading);
        
        // Uncomment this to debug JDBC Connection problems.
        //new com.apress.practicalwo.practicalutilities.EOFJDBCConnectionAnalyzer(connectionDictionary());
        
        EOEditingContext ec = new EOEditingContext();
        ec.lock();
        EOObjectStoreCoordinator.defaultCoordinator().lock();
        try
        {
            // Activate detection of referential integrity problems.
            EODatabaseContext.setDefaultDelegate(new EOFDebugAdditions());

            // Activate logging of fetched rows
            EODatabaseContext dbContext = 
                EOUtilities.databaseContextForModelNamed(ec, "PracticalUtilitiesTestEOModel");
            EODatabaseChannel dbChannel = dbContext.availableChannel();
            if ( dbChannel != null ) {
                dbChannel.adaptorChannel().setDelegate(new EOFDebugAdditions());
            }
        }
        finally
        {
            EOObjectStoreCoordinator.defaultCoordinator().unlock();
            ec.unlock();
        }
       
    }
    
    
    public void awake()
    {
        NSLog.out.appendln(Thread.currentThread().getName() + " Application awake");
        super.awake();
        
    }
    
    
    
    public void sleep()
    {
        NSLog.out.appendln(Thread.currentThread().getName() + " Application sleep");
        super.sleep();
    }


    public WOResponse dispatchRequest(WORequest aRequest)
    {
        NSLog.out.appendln("\n" + Thread.currentThread().getName() + " Dispatch request " + aRequest.uri());
        return super.dispatchRequest(aRequest);
    }
    
    
}