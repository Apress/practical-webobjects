package com.apress.practicalwo.chap3app;
import com.apress.practicalwo.practicalutilities.LockErrorScreamerEditingContext;
import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.eocontrol.EOEditingContext;


/**
 * Component to demonstrate the LockErrorScreamerEditingContext.
 */
public class LockErrorScreamerEditingContextTester extends WOComponent 
{

    EOEditingContext editingContext;
    
    
    public LockErrorScreamerEditingContextTester(WOContext context) 
    {
        super(context);
        editingContext = new LockErrorScreamerEditingContext();
    }



    public WOComponent lock() 
    {
        editingContext().lock();
        return null;
    }



    public WOComponent unlock() 
    {
        editingContext().unlock();
        return this;
    }



    public WOComponent refresh() 
    {
        return this;
    }



    public WOComponent waitAndRefresh() 
    {
        try 
        {
            Thread.sleep(5000);
        }
        catch (InterruptedException e)
        {
        }
        
        return this;
    }


    public EOEditingContext editingContext()
    {
        return editingContext;
    }
}