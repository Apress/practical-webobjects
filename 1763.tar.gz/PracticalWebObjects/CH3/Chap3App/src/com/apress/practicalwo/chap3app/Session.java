package com.apress.practicalwo.chap3app;

import com.apress.practicalwo.practicalutilities.LockErrorScreamerEditingContext;
import com.webobjects.appserver.WOSession;
import com.webobjects.foundation.NSLog;


/**
 * Session that uses LockErrorScreamerEditingContext as defaultEditingContext()
 * and logs messages during the Request - Response loop.
 */
public class Session extends WOSession 
{
    
    public Session() 
    {
        super();
        setDefaultEditingContext(new LockErrorScreamerEditingContext());
    }



    public Session(String sessionID) 
    {
        super(sessionID);
        setDefaultEditingContext(new LockErrorScreamerEditingContext());
    }



    public void awake()
    {
        NSLog.out.appendln(Thread.currentThread().getName() + " Session " + sessionID() + " awake");
        super.awake();
        
    }
    
    
    
    public void sleep()
    {
        NSLog.out.appendln(Thread.currentThread().getName() + " Session " + sessionID() + " sleep");
        super.sleep();
        
    }
}