package com.apress.practicalwo.chap3app;

import com.webobjects.appserver.WOActionResults;
import com.webobjects.appserver.WODirectAction;
import com.webobjects.appserver.WORequest;
import com.webobjects.foundation.NSLog;



/**
 * Direct Actions to examine the Request - Response loop.
 */
public class DirectAction extends WODirectAction 
{


    public DirectAction(WORequest aRequest) 
    {
        super(aRequest);
    }




    public WOActionResults performActionNamed(String anActionName) 
    {
        NSLog.out.appendln(Thread.currentThread().getName() + " Starting direct action " + anActionName);
        
         // Uncomment this line to have any existing session awoken before 
         // performing the action. 
        //existingSession();

        WOActionResults result = super.performActionNamed(anActionName);

        NSLog.out.appendln(Thread.currentThread().getName() + " Ending direct action " + anActionName);
        
        return result;
    }



    public WOActionResults defaultAction() 
    {
        return pageWithName("Main");
    }



    public WOActionResults page1Action() 
    {
		WOActionResults result = pageWithName("DALockingTest1");
		try 
        {
			Thread.sleep(5000);
        }
		catch (InterruptedException e)
        {
        }

        return result;
    }
    
    

    public WOActionResults page2Action() 
    {
		WOActionResults result = pageWithName("DALockingTest2");
        try 
        {
			Thread.sleep(5000);
        }
		catch (InterruptedException e)
        {
        }

        return result;
    }
}