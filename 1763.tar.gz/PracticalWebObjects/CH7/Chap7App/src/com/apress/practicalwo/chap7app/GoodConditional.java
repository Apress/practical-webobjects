package com.apress.practicalwo.chap7app;


import com.webobjects.appserver.*;

/**
 * Example component that shows how to properly handle changing values that
 * conditionals are bound to.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class GoodConditional extends BadConditional 
{
    public boolean hideButtonForConditional = false;
    
    
    public GoodConditional(WOContext context) 
    {
        super(context);
    }

    
    public void appendToResponse(WOResponse response, WOContext context)
    {
        // It is safe to update the variable that the conditional is bound to now
        hideButtonForConditional = hideButton;
        super.appendToResponse(response, context);
    }


}