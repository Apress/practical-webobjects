package com.apress.practicalwo.chap7app;

import com.webobjects.appserver.*;


/**
 * This page simply demonstrates the Hyperlink example of a WODynamicElement.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class DynamicElements extends WOComponent 
{

    public DynamicElements(WOContext context) 
    {
        super(context);
    }


    public WOComponent returnToMain()
    {
        return pageWithName("Main");
    }
    
    
}