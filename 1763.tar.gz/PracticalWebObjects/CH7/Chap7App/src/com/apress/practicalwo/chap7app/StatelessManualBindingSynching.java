package com.apress.practicalwo.chap7app;


import java.util.Calendar;
import java.util.GregorianCalendar;

import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSDictionary;
import com.webobjects.foundation.NSTimestamp;


/**
 * Page used to demonstrate the PWOMappedPopup stateless component.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class StatelessManualBindingSynching 
    extends LogBindingSynchronizationComponent 
{
    // Boolean popup from dictionary
    public NSDictionary booleanChoices = new NSDictionary(
        new Boolean[] {Boolean.TRUE, Boolean.FALSE},
        new String[]  {"Yes",        "No"});;
    public Boolean selectedBoolean;
    
    // Date Popup from array
    public NSArray completionDescriptions = new NSArray(new String[] {
        "Yesterday", "Today", "Tomorrow"}); 
    public NSArray completionDates;
    public GregorianCalendar selectedCompletion;


    public StatelessManualBindingSynching(WOContext context) 
    {
        super(context);
        
        // Need to set these up manually.
        GregorianCalendar today = new GregorianCalendar();
        GregorianCalendar yesterday = new GregorianCalendar();
        yesterday.add(Calendar.DAY_OF_MONTH, -1);
        GregorianCalendar tomorrow = new GregorianCalendar();
        tomorrow.add(Calendar.DAY_OF_MONTH, +1);

        completionDates = new NSArray( new GregorianCalendar[] {
            yesterday, today, tomorrow});
    }



    /**
     * Action method bound to submit button.
     * 
     * @return this page
     */
    public WOComponent recordResponse() 
    {
        // Could do saving or whatever here.
        return context().page();
    }



    /**
     * Converts selectedCompletion GregorianCalendar into NSTimestamp for
     * easier formatting.
     * 
     * @return selectedCompletion GregorianCalendar converted to NSTimestamp
     */
    public NSTimestamp selectedCompletionTimestamp()
    {
        return (selectedCompletion ==  null) ? 
            null : new NSTimestamp(selectedCompletion.getTime());
    }

    
}