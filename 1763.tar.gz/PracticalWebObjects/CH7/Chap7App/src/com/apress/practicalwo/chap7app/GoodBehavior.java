package com.apress.practicalwo.chap7app;


import com.webobjects.appserver.*;

/**
 * Page holding components GoodChangedCollection and GoodConditional to 
 * demonstrate how to avoid problems caused by modifying things during the 
 * request - response loop. 
 * 
 * @author Charles Hill and Sacha Mallais
 */public class GoodBehavior extends WOComponent 
{

    public GoodBehavior(WOContext context) 
    {
        super(context);
    }


}