package com.apress.practicalwo.chap7app;

import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WOEvent;
import com.webobjects.eocontrol.EOEventCenter;


/**
 * Custom sub-class of EOEvent/WOEvent used to demonstrate how to create and
 * use custom event classes.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class RRLoopPhaseEvent extends WOEvent
{
    // Constants matching the types in RRLoopPhaseEventEvent.description
    public static final String TAKE_VALUES = "takeValuesFromRequest";
    public static final String INVOKE = "invokeAction";
    public static final String APPEND = "appendToResponse";

    protected static volatile boolean _IsEventLoggingEnabled = false;
  
  
   /**
    * Convenience method to create, configure, and start an event if event 
    * logging is enabled for this class.
    * 
    * @param type the type of RRLoopPhaseEvent that is being created
    * @param aContext the WOContext this event is being created in
    * 
    * @return the created event or null if event logging is not enabled for this
    * class
    */
    public static RRLoopPhaseEvent startEvent(String type, WOContext aContext)
    {
        /** require [valid_type] type != null;  
                    [valid_context] aContext != null;  **/
        
        RRLoopPhaseEvent newEvent = null;
        if (RRLoopPhaseEvent.isLoggingEnabled()) 
        {
            newEvent = RRLoopPhaseEvent.newEvent(type, aContext);
        }
        
        return newEvent;
    }
    


    /**
     * Convenience method to create, configure, and start an event.
     * 
     * @param type the type of RRLoopPhaseEvent that is being created
     * @param aContext the WOContext this event is being created in
     * 
     * @return the newly created event
     */
    public static RRLoopPhaseEvent newEvent(String type, WOContext aContext)
    {
        /** require [valid_type] type != null;  
                    [valid_context] aContext != null;  **/
        
        RRLoopPhaseEvent e = (RRLoopPhaseEvent)EOEventCenter.newEventOfClass(RRLoopPhaseEvent.class, type);
        e.setComponentName(aContext.component().name());
        e.setPageName(aContext.page().name());
        EOEventCenter.markStartOfEvent(e, type);
        return e;
        
        /** ensure [event_returned] Result != null;  **/
    }




    /**
     * Returns <code>true</code> if logging is enabled for this class of events
     * 
     * @return <code>true</code> if logging is enabled for this class of events
     */
    public static boolean isLoggingEnabled()
    {
        return _IsEventLoggingEnabled;
    }



    /**
     * Returns the name of the component that created this event.
     * 
     * @return the name of the component that created this event  
     */
    public String title() 
    { 
            return _componentName; 
    }
      
   


    /**
     * Implementation of EOEventCenter.EventRecordingHandler to enable or 
     * disable logging of events of this class. 
     */
    public static class RRLoopPhaseEventLoggingEnabler extends Object 
        implements EOEventCenter.EventRecordingHandler 
    {
        public void setLoggingEnabled(boolean isLogging, Class aClass) 
        {
            if (aClass.equals(RRLoopPhaseEvent.class))
            {
                RRLoopPhaseEvent._IsEventLoggingEnabled = isLogging;
            }
        }
    }

}
