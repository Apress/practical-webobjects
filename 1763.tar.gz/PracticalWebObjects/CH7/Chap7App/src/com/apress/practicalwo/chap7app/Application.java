package com.apress.practicalwo.chap7app;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.apress.practicalwo.chap7app.RRLoopPhaseEvent.RRLoopPhaseEventLoggingEnabler;
import com.webobjects.appserver.WOApplication;
import com.webobjects.appserver.WOElement;
import com.webobjects.appserver.WORequest;
import com.webobjects.appserver.WOResponse;
import com.webobjects.eocontrol.EOEventCenter;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSDictionary;


/**
 * Application class for demonstration application for Practical WebObjects 
 * chapter 7.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class Application extends WOApplication 
{
    protected Properties elementMap;
    protected Logger elementMapLogger;
    
    
    public static void main(String argv[]) 
    {
        WOApplication.main(argv, Application.class);
    }



    public Application() 
    {
        super();
        
        // Setup EOEventCenter so that event logging can be enabled
        EOEventCenter.registerEventClass(RRLoopPhaseEvent.class, 
                                         new RRLoopPhaseEventLoggingEnabler());
        EOEventCenter.setPassword("secret"); 
        
        // log4j Configuration
        PropertyConfigurator.configure(resourceManager().pathURLForResourceNamed("log4j.properties", null, null));
        elementMapLogger = Logger.getLogger("com.apress.practicalwo.chap7app.elementMapping");

        // Load ElementMap.properties for use in dynamicElementWithName 
        elementMap = new Properties();
        try
        {
            InputStream mappedElements = resourceManager().
                inputStreamForResourceNamed("ElementMap.properties", null, null);
            elementMap.load(mappedElements);
            elementMapLogger.info("Loaded element map:\n" + elementMap);
        }
        catch (IOException e)
        {
            Logger.getRootLogger().fatal("ElementMap load failed: " + e.getMessage());
            System.exit(1);
        }
    }
    
    
    
    /**
     * Overridden to log request dispatches.
     */
    public WOResponse dispatchRequest(WORequest aRequest) 
    {
        elementMapLogger.info("\n\nStarting to dispatch request: " + aRequest.uri());
        return super.dispatchRequest(aRequest);
    }

 
    
    /**
     * Overridden to allow on the fly replacement of dynamic elements as defined
     * in ElementMap.properties
     */
    public WOElement dynamicElementWithName(String name, 
                                            NSDictionary associations, 
                                            WOElement children, 
                                            NSArray languages) 
    {
        String alternateElement = elementMap.getProperty(name);
        if (alternateElement != null)
        {
            elementMapLogger.info("Mapping dynamic elelment " + name + " to " +
                alternateElement);
            name = alternateElement;
        }
        
        return super.dynamicElementWithName(name, associations, children, languages); 
    }
}