package com.apress.practicalwo.chap7app;
 
import com.webobjects.appserver.*;

/**
 * Example component that shows the effect of changed conditionals hiding a form
 * submit during the request response loop.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class BadConditional extends WOComponent 
{
    public String buttonName = null;
    public boolean hideButton = false;
    
    
    public BadConditional(WOContext context) 
    {
        super(context);
    }

    
    
    /**
     * Action method to set buttonName to "One". Bound to ButtonOne action.
     *  
     * @return this page
    */
    public WOComponent buttonOneClicked() 
    {
        buttonName = "One";
        return context().page();
    }
    


    /**
     * Action method to set buttonName to "Two". Bound to ButtonTwo action.
     *  
     * @return this page
     */
    public WOComponent buttonTwoClicked() 
    {
        buttonName = "Two";
        return context().page();
    }
    


    /**
     * Action method to clear buttonName. Bound to form action.
     *  
     * @return this page
     */
    public WOComponent defaultFormSubmit() 
    {
        buttonName = null;
        return context().page();
    }
    
}