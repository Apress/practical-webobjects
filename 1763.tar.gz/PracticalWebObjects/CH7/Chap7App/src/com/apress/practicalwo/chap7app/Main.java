package com.apress.practicalwo.chap7app;

import com.webobjects.appserver.*;

/**
 * Main page of example application for Practical WebObjects chapter 7. 
 *
 * @author Charles Hill and Sacha Mallais
 */public class Main extends WOComponent 
{

    public Main(WOContext context) 
    {
        super(context);
    }



    public WOComponent goToDynamicElements()
    {
        return pageWithName("DynamicElements");
    }
}