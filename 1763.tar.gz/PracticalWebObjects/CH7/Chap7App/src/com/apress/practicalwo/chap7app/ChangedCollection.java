package com.apress.practicalwo.chap7app;

import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WORedirect;
import com.webobjects.foundation.*;
import com.webobjects.foundation.NSComparator.ComparisonException;


/**
 * Sub-component showing the wrong way to alter a collection used by components
 * or elements. 
 *
 * @author Charles Hill and Sacha Mallais
 */
public class ChangedCollection extends WOComponent 
{

    public String websiteName;
    public NSMutableDictionary websites;
    public NSMutableArray websiteNames;


    public ChangedCollection(WOContext context) 
    {
        super(context);
        websites = new NSMutableDictionary(new String[] {
            "http://www.apple.com", 
            "http://www.webobjects.com", 
            "http://www.Google.com", 
            "http://www.cnn.com", 
            "http://www.dilbert.com"},
        new String[] {
            "Apple", 
            "WebObjects", 
            "Google", 
            "CNN", 
            "Dilbert"});  
        try
        {
            websiteNames = new NSMutableArray(
                websites.allKeys().sortedArrayUsingComparator(
                    NSComparator.AscendingStringComparator));
        }
        catch (ComparisonException e)
        {
            throw new NSForwardException(e);
        }
    }
    
    
    
    /**
     * Action method to redirect to the selected website.
     * 
     * @return a redirect to the selected website
     */
    public WOComponent visitSite() 
    {
        WORedirect redirect = (WORedirect) pageWithName("WORedirect");
        redirect.setUrl((String)websites.objectForKey(websiteName));
        return redirect;
    }
    
    
    
    /**
     * Action method to save changes (website deletions).
     * 
     * @return this page
     */
    public WOComponent saveChanges() 
    {
        // Save any changes here, we are not changing eo objects so nothing
        // to so in our example but you would usually call ec.saveChanges() here
        return context().page();
    }



    /**
     * Method bound to checkbox.  Returns false as nothing is deleted if it is 
     * displayed.
     * 
     * @return false as nothing is deleted if we display it
     */
    public boolean isSiteDeleted() 
    {
        return false;
    }



    /**
     * Method bound to checkbox.  Deletes the website if the checkbox is 
     * checked.
     * 
     * @param isSiteDeleted true if the website should be deleted.
     */
    public void setIsSiteDeleted(boolean isSiteDeleted) 
    {
        if (isSiteDeleted)
        {
            websites.removeObjectForKey(websiteName);
            websiteNames.removeObject(websiteName);;  
        }
    }
   
}