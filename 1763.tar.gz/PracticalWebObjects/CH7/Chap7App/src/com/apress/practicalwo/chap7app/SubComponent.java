package com.apress.practicalwo.chap7app;

import com.webobjects.appserver.WOActionResults;
import com.webobjects.appserver.WOContext;
import com.webobjects.foundation.NSTimestamp;


/**
 * Example sub-component that implements a phone number input and has a 
 * sub-component of a simple date picker / save button. This is used in the 
 * Binding Synchronization example. There is no validation of user input.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class SubComponent extends LogBindingSynchronizationComponent 
{
    /** 
     * For binding synchronization. Name of action method on parent to invoke
     * on behalf of our sub-component. */
    public String saveActionName;

    /** 
     * For binding synchronization. Passes birthdate through from parent to our 
     * sub-component. */
    public NSTimestamp birthdate;

    /** For binding synchronization */
        public String phoneNumber;


    public SubComponent(WOContext context) 
    {
        super(context);
    }


    /**
     * Method overridden to show result of valueForBinding in awake.
     */
    public void awake()
    {
        // Warning, using valueForBinding() in awake() while logging events 
        // produces a NullPointerException in WO 5.2.2 and WO 5.2.3
        bindingLogger.info(indentString() + shortName() + " in awake phoneNumber is " + valueForBinding("phoneNumber"));
        super.awake();
    }



    /**
     * Action method to return result of calling method bound to saveActionName.
     *  
     * @return result of performing action on parent
     */
    public WOActionResults saveChanges()
    {
        bindingLogger.info(indentString() + shortName() + " performing parent " +
            "action named " + saveActionName + " on " + parentShortName());
        return performParentAction(saveActionName);
    }
}