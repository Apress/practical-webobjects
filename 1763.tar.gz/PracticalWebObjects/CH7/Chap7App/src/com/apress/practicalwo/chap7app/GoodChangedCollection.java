package com.apress.practicalwo.chap7app;

import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.foundation.NSMutableSet;


/**
 * Sub-component showing the right way to alter a collection used by components
 * or elements. 
 *
 * @author Charles Hill and Sacha Mallais
 */
public class GoodChangedCollection extends ChangedCollection 
{

    protected NSMutableSet deletedSites = new NSMutableSet();


    public GoodChangedCollection(WOContext context) 
    {
        super(context);
    }
    
    

    /**
     * Action method to save changes (website deletions).
     * 
     * @return this page
     */
    public WOComponent saveChanges() 
    {
        // Handle multiple selections
        while (deletedSites.count() > 0)
        {
            websiteName = (String) deletedSites.anyObject();
            deletedSites.removeObject(websiteName); 
            websites.removeObjectForKey(websiteName);
            websiteNames.removeObject(websiteName);;  
        }
        
        // Save any changes here, we are not changing eo objects so nothing
        // to so in our example but you would usually call ec.saveChanges() here 
        return context().page();
    }



    /**
     * Method bound to checkbox. Returns true is this website is selected for 
     * deletion but not yet deleted.
     * 
     * @return true is this website is selected for deletion but not yet deleted
     */
    public boolean isSiteDeleted() 
    {
        return deletedSites.containsObject(websiteName);
    }



    /**
     * Method bound to checkbox.  Records the website as needeing to be deleted. 
     * 
     * @param isSiteDeleted true if the website should be deleted.
     */
    public void setIsSiteDeleted(boolean isSiteDeleted) 
    {
        if (isSiteDeleted)
        {
            deletedSites.addObject(websiteName);
        }
    }
 
    
}