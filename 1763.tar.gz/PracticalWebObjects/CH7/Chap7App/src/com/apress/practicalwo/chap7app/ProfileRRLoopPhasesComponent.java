package com.apress.practicalwo.chap7app;

import com.webobjects.appserver.*;
import com.webobjects.eocontrol.EOEventCenter;


/**
 * WOComponent sub-class that instruments the three main methods of the request
 * - response loop with RRLoopPhaseEvents.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class ProfileRRLoopPhasesComponent extends WOComponent
{

    public ProfileRRLoopPhasesComponent(WOContext aContext)
    {
        super(aContext);
    }
    
    
    public void takeValuesFromRequest(WORequest aRequest, WOContext aContext)
    {
        RRLoopPhaseEvent event = RRLoopPhaseEvent.startEvent(RRLoopPhaseEvent.TAKE_VALUES, aContext);

        super.takeValuesFromRequest(aRequest, aContext);
        
        // null events are handled by EOEventCenter
        EOEventCenter.markEndOfEvent(event);
    }



    public WOActionResults invokeAction(WORequest aRequest, WOContext aContext) 
    {
        RRLoopPhaseEvent event = RRLoopPhaseEvent.startEvent(RRLoopPhaseEvent.INVOKE, aContext);

        WOActionResults result = super.invokeAction(aRequest, aContext);

        // null events are handled by EOEventCenter
        EOEventCenter.markEndOfEvent(event);

        return result;
    }



    public void appendToResponse(WOResponse aResponse, WOContext aContext)
    {
        RRLoopPhaseEvent event = RRLoopPhaseEvent.startEvent(RRLoopPhaseEvent.APPEND, aContext);

        super.appendToResponse(aResponse, aContext);
        
        // null events are handled by EOEventCenter
        EOEventCenter.markEndOfEvent(event);
    }
}
