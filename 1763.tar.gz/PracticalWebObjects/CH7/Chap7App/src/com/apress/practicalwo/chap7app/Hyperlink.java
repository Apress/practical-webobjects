package com.apress.practicalwo.chap7app;

import java.util.Enumeration;

import com.webobjects.appserver.*;
import com.webobjects.appserver._private.WODynamicElementCreationException;
import com.webobjects.foundation.NSDictionary;
import com.webobjects.foundation.NSMutableDictionary;

/**
 * WOHyperlink partial re-implmentation as a WODynamicElement. Only the action 
 * and pageName bindings are directly supported.  Any additional bindings are 
 * copied.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class Hyperlink extends WODynamicElement
{
    public static final String ACTION_BINDING_KEY = "action";
    public static final String PAGE_NAME_BINDING_KEY = "pageName";

    protected WOAssociation action;
    protected WOAssociation pageName;
    protected NSDictionary extraBindings = null;
    protected WOElement children;


    /**
     * Constructor.
     * 
     * @param name not used
     * @param associations bindings from WOD file
     * @param children HTML inside link
     */
    public Hyperlink(String name, NSDictionary associations, WOElement children)
    {
        super(name, associations, children);

        /** require [associations_valid] associations != null;  **/

        action = (WOAssociation)associations.objectForKey(ACTION_BINDING_KEY);
        pageName = (WOAssociation)associations.objectForKey(PAGE_NAME_BINDING_KEY);

        // Binding validation, one is required.
        if (action() == null && pageName() == null)  
        {
            throw new WODynamicElementCreationException("<" + 
                getClass().getName() + "> Missing required attribute: 'action' or 'pageName'");
        }

        // Binding validation, both are not allowed.
        if (action() != null && pageName() != null)  
        {
            throw new WODynamicElementCreationException("<" + 
                getClass().getName() + "> Must specify only one of: 'action' or 'pageName'");
        }

        // Usage validation, <a href="..."></a> is not allowed
        if (children == null) 
        {
            throw new WODynamicElementCreationException("<" + 
            getClass().getName() + "> Missing contents.  Hyperlink must be " +                "wrapped around something");
        }

        // Handle extra bindings such as style, class, etc.
        if (associations.count() > 1)
        {
            NSMutableDictionary tempBindings = new NSMutableDictionary(associations);
            tempBindings.removeObjectForKey(ACTION_BINDING_KEY);
            tempBindings.removeObjectForKey(PAGE_NAME_BINDING_KEY);
            extraBindings = tempBindings.immutableClone();
        }
        this.children = children;
    }



    /**
     * Add hyperlink to response's content as:<br />
     * <code>
     * &lt;a href="<i>actionUrl</i>&gt; <i>[optional bindings]&gt;<i>children</i>&lt;/a&gt;
     * <code>
     */
    public void appendToResponse(WOResponse aResponse, WOContext aContext) 
    {
        // Output <a href="url"
        aResponse.appendContentString("<!-- Our Hyperlink -->");
        aResponse.appendContentString("<a href=\"");
        aResponse.appendContentString(aContext.componentActionURL());
        aResponse.appendContentString("\"");

        // Output optional bindings
        if (extraBindings() != null)
        {
            Enumeration bindings = extraBindings().keyEnumerator();
            String bindingName;
            WOAssociation binding;
            while (bindings.hasMoreElements())
            {
                bindingName = (String) bindings.nextElement();
                binding = (WOAssociation) extraBindings.objectForKey(bindingName);
                aResponse.appendContentString(" ");
                aResponse.appendContentString(bindingName);
                aResponse.appendContentString("=\"");
                aResponse.appendContentString((String)binding.valueInComponent(aContext.component()));
                aResponse.appendContentString("\"");
            }
        }

        // Close opening tag
        aResponse.appendContentString(">");

        // Output text, image, etc. that will be clicked on
        children().appendToResponse(aResponse, aContext);

        // Output closing tag
        aResponse.appendContentString("</a>");
        aResponse.appendContentString("<!-- Our Hyperlink End -->");
    }



    /**
     * If this action is directed at us, either invoke the bound action or create
     * a new instance of the named page and return the result.
     */
    public WOActionResults invokeAction(WORequest aRequest, WOContext aContext) 
    {
        WOActionResults result = null;
        
        if (aContext.senderID().equals(aContext.elementID())) 
        {
            if (action() != null)
            {
                // Invoke the bound action.  Binding to a method that returns 
                // null is acceptable.
                result = (WOActionResults)action().valueInComponent(aContext.component()); 
                
                // Substitute aContext().page() for null so that processing stops 
                if (result == null)
                {
                    result = aContext.page();
                }
            }
            else
            {
                // Get and validate the page name.  Binding to a null page name
                // is not acceptable.
                String nameInComponent = (String)pageName().valueInComponent(aContext.component());
                if (nameInComponent == null)
                {
                    throw new IllegalStateException("<" + getClass().getName() + 
                        "> : Missing page name.");
                }

                result = WOApplication.application().pageWithName(nameInComponent, aContext);            
            }
        }
        
        return result;
        /** ensure [result_if_action_invoked] Result != null ||
                       ! aContext.senderID().equals(aContext.elementID());  
        **/
    }



    /**
     * Returns the WOAssociation for the action this component is bound to, or 
     * null if pageName is being used.
     * 
     * @return the WOAssociation for the action this component is bound to, or 
     * null if pageName is being used
     */
    public WOAssociation action()
    {
        return action;
    }



    /**
     * Returns the name of the page this component should return or null if
     * action is being used.
     * 
     * @return the name of the page this component should return or null if
     * action is being used
     */
    public WOAssociation pageName()
    {
        return pageName;
    }



    /**
     * Returns the WOElement representing the HTML between &lt;a&gt; and &lt;/a&gt;
     * 
     * @return the WOElement representing the HTML between &lt;a&gt; and &lt;/a&gt;
     */
    public WOElement children()
    {
        return children;
    }



    /**
     * Returns a dictionary of any optional bindings with the key being the 
     * binging name and the value being the association. These are rendered as 
     * HTML tags on the &lt;a&gt; element.
     *  
     * @return a dictionary of any optional bindings
     */
    public NSDictionary extraBindings()
    {
        return extraBindings;
    }


    /** invariant [has_action_or_pageName] action() != null || pageName() != null; **/
}
