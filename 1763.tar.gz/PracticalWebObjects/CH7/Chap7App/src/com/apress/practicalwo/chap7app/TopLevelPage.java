package com.apress.practicalwo.chap7app;


import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.foundation.NSTimestamp;


/**
 * Page demonstrating binding synchronization between top level page and two
 * levels of sub-components.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class TopLevelPage extends LogBindingSynchronizationComponent 
{
    public String firstName;
    public String lastName;
    public NSTimestamp dateOfBirth;
    public String telephoneNumber;
    
    
    public TopLevelPage(WOContext context) 
    {
        super(context);
    }


    /**
     * Action method in top level page called from button in SubSubComponent.
     * 
     * @return this page
     */
    public WOComponent saveForm() 
    {
        bindingLogger.info(indentString() + shortName() + " invoked saveForm action");
        return this;
    }

    
}