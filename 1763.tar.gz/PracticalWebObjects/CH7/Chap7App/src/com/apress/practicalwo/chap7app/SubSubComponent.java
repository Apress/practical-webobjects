package com.apress.practicalwo.chap7app;


import java.util.GregorianCalendar;

import com.webobjects.appserver.WOActionResults;
import com.webobjects.appserver.WOContext;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSTimestamp;


/**
 * Example sub-component that implements a simple date picker and save button.
 * This is used in the Binding Synchronization example. There is no validation
 * of user input.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class SubSubComponent extends LogBindingSynchronizationComponent 
{
    /** For binding synchronization */
    public String submitActionName;

    /** For UI support, list of days. @TypeInfo java.lang.String */
    public final NSArray days = new NSArray(new String[] 
        {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", 
         "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", 
         "26", "27", "28", "29", "30", "31"});

    /** For UI support, list of months. @TypeInfo java.lang.String */
    public final NSArray months = new NSArray(new String[] 
        {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"});
        
    /** For UI support, selected day */
    public String day;
        
    /** For UI support, selected month */
    public String month;
        
    /** For UI support, entered year */
    public String year;


    public SubSubComponent(WOContext context) 
    {
        super(context);
    }



    /**
     * Action method that returns the result of performing action named  
     * saveActionName on the parent.
     * @return result of performing action named saveActionName on the parent
     */
    public WOActionResults save() 
    {
        bindingLogger.info(indentString() + shortName() + " performing parent " +            "action named " + submitActionName + " on " + parentShortName());
        return performParentAction(submitActionName);
    }



    /**
     * Binding method.  Gathers the user input string and converts them into a
     * NSTimestamp to return as the value for the date binding.
     *  
     * @return date the user entered
     */
    public NSTimestamp date() 
    {
        return new NSTimestamp(
            new GregorianCalendar(Integer.parseInt(year), 
                                  Integer.parseInt(month) - 1, 
                                  Integer.parseInt(day)).getTime()); 
    }
    
    
    
    /**
     * Binding method. Takes the value for the date bindings and breaks it into
     * string for display in the UI.
     * 
     * @param newDate the value bound to date in our parent component.
     */
    public void setDate(NSTimestamp newDate) 
    {
        // Provide default date
        GregorianCalendar calendarDate = new GregorianCalendar();
        
        // Use supplied date if present.
        if (newDate != null)
        {
            calendarDate.setTime(newDate);
        }
        
        year = String.valueOf(calendarDate.get(GregorianCalendar.YEAR));
        month = String.valueOf(calendarDate.get(GregorianCalendar.MONTH) + 1);
        day = String.valueOf(calendarDate.get(GregorianCalendar.DAY_OF_MONTH));
    }

}