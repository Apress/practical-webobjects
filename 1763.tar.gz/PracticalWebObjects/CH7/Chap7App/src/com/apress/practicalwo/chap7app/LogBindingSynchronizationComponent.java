package com.apress.practicalwo.chap7app;

import org.apache.log4j.Logger;

import com.webobjects.appserver.*;
import com.webobjects.foundation.NSPathUtilities;

/**
 * Super-class for pages and components used to demonstrate binding 
 * syncronization.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class LogBindingSynchronizationComponent extends ProfileRRLoopPhasesComponent
{
    protected static final Logger bindingLogger = Logger.getLogger(
        "com.apress.practicalwo.chap7app.bindings");
    protected String shortName;
    protected static final String spaces = "                                  ";    
    
    public LogBindingSynchronizationComponent(WOContext aContext)
    {
        super(aContext);
        // Takes everything after the last dot.  Probably does not work if 
        // classes are not in packages.
        shortName = NSPathUtilities.pathExtension(name());
    }
    

    
    // This method is here to show that it is not called for automatic
    // synchronization    
    public void setValueForBinding(Object aValue, String aBindingName)
    {
        bindingLogger.info(indentString() + shortName() + " setting Value " + 
            aValue + " for binding " + aBindingName);
        super.setValueForBinding(aValue, aBindingName);
    }



    // This method is here to show that it is not called for automatic
    // synchronization    
    public Object valueForBinding(String aBindingName)
    {
        Object value = super.valueForBinding(aBindingName);
        bindingLogger.info(indentString() + shortName() + " getting Value " + 
            value + " for binding " +  aBindingName);
        return value;
    }



    public void pullValuesFromParent()
    {
        bindingLogger.info(indentString() + shortName() + " pulling values for " 
            + bindingKeys() + " from parent " + parentShortName());
        super.pullValuesFromParent();
        
    }



    public void pushValuesToParent()
    {
        bindingLogger.info(indentString() + shortName() + " pushing values for " 
            + bindingKeys() + " to parent " + parentShortName());
        super.pushValuesToParent();
        
    }



    public void _awakeInContext(WOContext wocontext)
    {
        bindingLogger.info(indentString() + shortName() + " _awakeInContext");
        super._awakeInContext(wocontext);
    }

    
    
    public void awake()
    {
       bindingLogger.info(indentString() + shortName() + " awake, context ");
      
        super.awake();
    }
    
    
    
    public void takeValuesFromRequest(WORequest aRequest, WOContext aContext)
    {
        bindingLogger.info(indentString() + shortName() + 
            " takeValuesFromRequest starting");
        super.takeValuesFromRequest(aRequest, aContext);
        bindingLogger.info(indentString() + shortName() + 
            " takeValuesFromRequest finished");
    }



    public WOActionResults invokeAction(WORequest aRequest, WOContext aContext) 
    {
        bindingLogger.info(indentString()+shortName()+" invokeAction starting");
        WOActionResults result = super.invokeAction(aRequest, aContext);
        bindingLogger.info(indentString()+shortName()+" invokeAction finished");
        return result;
    }



    public void appendToResponse(WOResponse aResponse, WOContext aContext)
    {
        bindingLogger.info(indentString() + shortName() + 
            " starting appendToResponse");
        super.appendToResponse(aResponse, aContext);
        bindingLogger.info(indentString() + shortName() + 
            " finished appendToResponse");
    }



    public void sleep()
    {
        bindingLogger.info(indentString() + shortName() + " sleep, context ");
        super.sleep();
    }



    /**
     * Returns the name of this component without any of the package names.
     * 
     * @return the name of this component without any of the package names
     */
    public String shortName()
    {
        return shortName;
    }



    /**
     * Returns the name of our parent component without any of the package names.
     * 
     * @return the name of our parent component without any of the package names
     */
    public String parentShortName()
    {
        return ((LogBindingSynchronizationComponent)parent()).shortName();
    }



    /** 
     * Returns the number of levels of component nesting between this component
     * and the page being generated.  This is used by indentString.
     * 
     * @return number of levels of component nesting between this component and 
     * the page being generated
     */
    protected int depth()
    {
        int depth = -1;
        WOComponent nextLevel = this;
        do 
        {
            depth++;
            nextLevel = nextLevel.parent();
        }
        while (nextLevel != null);
        
        return depth;
    }
    
    
    
    /**
     * Returns a string of spaces equal in length to twice the depth.  This is
     * used to indent log messages to make them easier to read.
     *  
     * @return a string of spaces equal in length to twice the depth
     */
    protected String indentString()
    {
        return spaces.substring(0, depth() * 2);
    }

}
