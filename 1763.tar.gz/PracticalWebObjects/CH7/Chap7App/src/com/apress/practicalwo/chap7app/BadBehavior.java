package com.apress.practicalwo.chap7app;


import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;


/**
 * Page holding components BadCollection and BadConditional to demonstrate 
 * problems modifying things during the request - response loop. 
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class BadBehavior extends WOComponent 
{

    
    public BadBehavior(WOContext context) 
    {
        super(context);
    }

}