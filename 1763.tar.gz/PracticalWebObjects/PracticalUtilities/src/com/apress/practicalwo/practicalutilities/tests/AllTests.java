package com.apress.practicalwo.practicalutilities.tests;

import java.util.Properties;

import junit.framework.*;

import org.apache.log4j.PropertyConfigurator;

import com.apress.practicalwo.practicalutilities.*;


/**
 *
 * @author Chuck Hill and Sacha Mallais
 */
public class AllTests extends EOTestSuite
{

    /**
     * Auto-generated constructor stub
     * 
     * @param suiteName
     */
    public AllTests(String suiteName)
    {
        super(suiteName);
    }



    public static Test suite()
    {
        // Needs to be done early, if not first!
        EOFValidation.installValidation();

        // log4j Configuration, can't figure out how to read from file...
        Properties log4jConfig = new Properties();
        log4jConfig.put("log4j.appender.com.apress.practicalwo.practicalutilities" ,
            "org.apache.log4j.ConsoleAppender");
        log4jConfig.put("log4j.appender.com.apress.practicalwo.practicalutilities.layout", 
        "org.apache.log4j.PatternLayout");
        log4jConfig.put("log4j.appender.com.apress.practicalwo.practicalutilities.layout.ConversionPattern", 
        "%c{1} - %m%n");
        log4jConfig.put("log4j.rootLogger", 
        "INFO, com.apress.practicalwo.practicalutilities");
        log4jConfig.put("com.apress.practicalwo.practicalutilities.EOCopyable", 
        "INFO");
        PropertyConfigurator.configure(log4jConfig);
 
        // This is just an informational note from Fronbase when the UPDATE for ec2.saveChanges() fails to update a row.
        System.out.println("Ingore the 'Failed to fetch class com.apress.practicalwo.practicalutilities.tests.CooperatingEditingContextTestObject with globalID _EOIntegralKeyGlobalID[CooperatingEditingContextTestObject' error and any errors like 'Completion condition 250. No data.'");

        TestSuite suite =
            new EOTestSuite("Test for com.apress.practicalwo.practicalutilities.tests");
        //$JUnit-BEGIN$
        suite.addTest(new TestSuite(CooperatingEditingContextTest.class));
        suite.addTest(new TestSuite(EOFDebugAdditionsTest.class));
        suite.addTest(new TestSuite(EOModelConnectorTest.class));
        suite.addTest(new TestSuite(EOPrototypeSwitcherTest.class));
        suite.addTest(new TestSuite(EOCopyableTest.class));

        suite.addTest(new TestSuite(EOFValidationTest.class));
        suite.addTest(new TestSuite(EOEntityAdditionsTest.class));
        suite.addTest(new TestSuite(LocalizationEngineTest.class));
        suite.addTest(new TestSuite(EOFValidationExceptionTest.class));
        suite.addTest(new TestSuite(EOAttributeValidatorTest.class));
        suite.addTest(new TestSuite(EORelationshipValidatorTest.class));
        suite.addTest(new TestSuite(NSExceptionAdditionsTest.class));
        suite.addTest(new TestSuite(EOEditingContextTest.class));
        //$JUnit-END$

        return suite;
    }



}
