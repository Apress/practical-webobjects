package com.apress.practicalwo.practicalutilities.tests;

import com.apress.practicalwo.practicalutilities.*;

import com.webobjects.eoaccess.*;
import com.webobjects.eocontrol.EOObjectStoreCoordinator;


/**
 * Tests for NSExceptionAdditions
 *
 * @author Copyright (c) 2001-2  Global Village Consulting, Inc.  All rights reserved.
 * @version $Revision: 2$
 */
public class NSExceptionAdditionsTest extends EOTestCase
{
    ToOneEntity testObject1;
    ToOneEntity testObject2;
    com.webobjects.eocontrol.EOEditingContext ec1;
    com.webobjects.eocontrol.EOEditingContext ec2;
    EOObjectStoreCoordinator osc; 
    EOGeneralAdaptorException exception;
    RuntimeException /* JC_WARNING - Change exception name (or catch clause) to the real exception you want to raise (or catch). */ wrongExceptionType;


    /**
     * Designated constuctor.
     */
    public NSExceptionAdditionsTest(String name)
    {
        super(name);
    }



    /**
     * Common test code.
     */
    public void setUp() throws java.lang.Exception
    {
        super.setUp();

        // The whole point of this setup to to create an exception of the appropriate type.
        
        // Editing context with default object store co-ordinator.
        ec1 = new ValidatingEditingContext();
        testObject1 = new ToOneEntity();
        ec1.insertObject(testObject1);
        testObject1.setName(globallyUniqueString());
        ec1.saveChanges();							

        // In order to simulate adapator level errors during a saveChanges, we need to create an editing context with its own EOF stack so that it has its own snapshots.  Also make it be an instance of the standard editing context so that it doesn't raise an EOFValidationException.
         osc = new EOObjectStoreCoordinator(); 
         ec2 = new com.webobjects.eocontrol.EOEditingContext(osc);

         testObject2 = (ToOneEntity)EOUtilities.localInstanceOfObject(ec2, testObject1);
         testObject2.setName(globallyUniqueString());

         testObject1.setName(globallyUniqueString());

         try
         {
             ec1.saveChanges();
             ec2.saveChanges();
         }
         catch (EOGeneralAdaptorException e)
         {
             exception = e;
         }

         // An NSException without the special adaptor failure exception dictionary.
         wrongExceptionType = new RuntimeException /* JC_WARNING - Change exception name (or catch clause) to the real exception you want to raise (or catch). */("NSGenericException");
    }



    /**
     * Test isAdaptorFailureException
     */
    public void testIsAdaptorFailureException()
    {
        // Check DBC
        try { EOFValidation.isAdaptorFailureException(null);
            fail("Accepted null exception");}
        catch (RuntimeException t) {}

        assertTrue(EOFValidation.isAdaptorFailureException(exception));
    }



    /**
     * Test isOptimisticLockingFailure
     */
    public void testIsOptimisticLockingFailure()
    {
        // Check DBC
        try { EOFValidation.isOptimisticLockingFailure(null);
            fail("Accepted null exception");}
        catch (RuntimeException t) {}

        assertTrue(EOFValidation.isOptimisticLockingFailure(exception));
    }



    /**
     * Test objectSaveFailedOn
     */
    public void testObjectSaveFailedOn()
    {
        // Check DBC
        try { EOFValidation.objectSaveFailedOn((EOGeneralAdaptorException)null);
            fail("Accepted null exception");}
        catch (RuntimeException t) {}

        assertEquals(EOFValidation.objectSaveFailedOn(exception), testObject2);
    }



    /**
     * Test entitySaveFailedOn
     */
    public void testEntitySaveFailedOn()
    {
        // Check DBC
        try { EOFValidation.entitySaveFailedOn(null);
            fail("Accepted null exception");}
        catch (RuntimeException t) {}

        assertEquals(EOFValidation.entitySaveFailedOn(exception), EOObject.entityForSelf(testObject2));
    }



    /**
     * Test failedAdaptorOperator
     */
    public void testFailedAdaptorOperator()
    {
        // Check DBC
        try { EOFValidation.failedAdaptorOperator(null);
            fail("Accepted null exception");}
        catch (RuntimeException t) {}

        assertTrue(EOFValidation.failedAdaptorOperator(exception) == EODatabaseOperation.AdaptorUpdateOperator);
    }



    /**
     * Test databaseExceptionReason
     */
    public void testDatabaseExceptionReason()
    {
        // Check DBC
        try { EOFValidation.databaseExceptionReason(null);
            fail("Accepted null exception");}
        catch (RuntimeException t) {}

        // Kind of a lame test, but at least we can see that it is getting the right string.
        assertTrue(EOFValidation.databaseExceptionReason(exception).startsWith("com.webobjects.eoaccess.EOGeneralAdaptorException: updateValuesInRowDescribedByQualifier"));
    }



    /**
     * Common test code.
     */
    public void tearDown() throws java.lang.Exception
    {
        ec1.revert();
        ec2.revert();

        // Try to cleanup.
        try
        {
            ec1.deleteObject(testObject1);
            ec1.saveChanges();
        }
        catch (Throwable t){}

        super.tearDown();
    }



}
