package com.apress.practicalwo.practicalutilities;

import com.webobjects.eoaccess.EOModel;
import com.webobjects.eoaccess.EOModelGroup;
import com.webobjects.foundation.*;

/**
 * <p>EOModelConnector handles configuring the connection dictionary and adaptor name 
 * in EOModels at runtime.  It can ignore some models if they are not needed or if
 * they need different connection information.</p>
 * 
 * <p>If an EOModel already has a set adaptor type (e.g. JDBC, JDNI) and that type
 * is not the same as our <code>adaptorType()</code> then the model will also be 
 * ignored.  This prevents one connector (e.g. JDBC) from trashing models
 * (e.g. JDNI) models.</p>
 * 
 * <p>EOModelConnector can be installed as a notification handler catching 
 * the EOModelGroup.ModelAddedNotification.  It can also be used when enumerating 
 * over EOModelGroup.defaultGroup().models() or other similar situations.</p>
 * 
 * @author Chuck Hill and Sacha Mallais
 */
public class EOModelConnector
{
    protected NSDictionary connectionDictionary;
    protected NSArray modelsToIgnore;
    protected String adaptorName;



    /**
     * Designated constructor, creates an EOModelConnector to use the indicated
     * connection dictionary and adaptor name when updating all models not named
     * in <code>ingoredModels</code>.
     * 
     * @param aConnectionDictionary the connection information to use
     * @param theAdaptorName the name of the EOAdaptor that aConnectionDictionary is for
     * @param ignoredModels list of names of models that should no be processed
     */
    public EOModelConnector(NSDictionary aConnectionDictionary, 
                                          String theAdaptorName,
                                          NSArray ignoredModels)
    {
        super();
        
        /** require [valid_connectionDictionary] aConnectionDictionary != null;
                    [valid_adaptorName] theAdaptorName != null;
                    [valid_ignoredModels] ignoredModels != null;  **/

        connectionDictionary = aConnectionDictionary;
        adaptorName = theAdaptorName;
        modelsToIgnore = ignoredModels;
    }



    /**
     * Conveneince constructor for JDBC connections, creates an EOModelConnector 
     * to use the indicated connection dictionary and "JDBC" for the adaptor name 
     * when updating all models not named in <code>ingoredModels</code>.
     * 
     * @param aConnectionDictionary the connection information to use
     * @param ignoredModels list of names of models that should no be processed
     */
    public EOModelConnector(NSDictionary aConnectionDictionary, 
                                          NSArray ignoredModels)
    {
        this(aConnectionDictionary, "JDBC", ignoredModels);
        
        /** require [valid_connectionDictionary] aConnectionDictionary != null;
                    [valid_ignoredModels] ignoredModels != null;  **/
    }
   
    
    
    /**
     * Installs this object as a listener for <code>EOModelGroup.ModelAddedNotification</code>
     * <code>handleModelAddedNotification()</code> will be called when this 
     * notification is received.
     */
    public void listenForAddedModels()
    {
        NSSelector modelAddedSelector = 
            new NSSelector("handleModelAddedNotification", new Class[] { NSNotification.class } );
        NSNotificationCenter.defaultCenter().
            addObserver(this, modelAddedSelector, EOModelGroup.ModelAddedNotification, null);
    }
    
    
    
    /**
     * The object in the notification is the model being added.  The model is 
     * extracted from this notification and passed to 
     * <code>connectModel()</code>.
     *
     * @param aNotification notification of which EOModel is being added.
     */
    public void handleModelAddedNotification(NSNotification aNotification)
    {
        /** require [valid_param] aNotification != null; 
                    [is_model_added_notification] 
                        aNotification.name().equals(EOModelGroup.ModelAddedNotification);  **/


        EOModel theModel = (EOModel) aNotification.object();
        connectModel(theModel);
    }


    
    /**
     * Updates the connection dictionary in <code>aModel</code> if it is not in the
     * list of <code>modelsToIgnore();</code>.  The adaptor name is also updated to
     * adaptorName().
     * 
     * @param aModel the EOModel in which to possibly chnage the connection dictionary 
     */
    public void connectModel(EOModel aModel)
    {
        /** require [aModel_valid] aModel != null; **/
        
        if ( ! isIgnoringModel(aModel))
        {
            if (NSLog.debugLoggingAllowedForLevel(NSLog.DebugLevelDetailed))
            {
                NSLog.debug.appendln("EOModelConnector: Connecting model: " + aModel.name() +
                                     " with dictionary " + connectionDictionary());
            }

            aModel.setConnectionDictionary(connectionDictionary());
            aModel.setAdaptorName(adaptorName());
        }

        /** ensure [not_ignored_means_connection_dictionary_set] 
                       isIgnoringModel(aModel) || 
                       aModel.connectionDictionary().equals(connectionDictionary()); 
                   [not_ignored_means_adaptor_name_set] isIgnoringModel(aModel) 
                       || aModel.adaptorName().equals(adaptorName()); 
         **/
    }
    
    
        
    /**
     * Returns <code>true</code> if <code>aModel</code> will be ignored by this
     * EOModelConnector instance.  The model will be ignored if it is in the list
     * of models to ignore, or if it has an adaptor type which is not compatible
     * (not null and not our adaptor type).
     * 
     * @param aModel the EOModel to check
     * @return <code>true</code> if <code>aModel</code> will be ignored by this
     * EOModelConnector instance
     */
    public boolean isIgnoringModel(EOModel aModel)
    {
        /** require [aModel_valid] aModel != null; **/
        
        return (modelsToIgnore().containsObject(aModel.name()) ) ||
               ( (aModel.adaptorName() != null) && 
                 (! aModel.adaptorName().equals(adaptorName())) ) ;
    }



    /**
     * Returns the connection dictionary to connect models with. 
     * 
     * @return the connection dictionary to connect models with 
     */
    public NSDictionary connectionDictionary()
    {
        return connectionDictionary;
    }



    /**
    * Returns the adaptor type matching <code>connectionDictionary()</code>. 
    * 
    * @return the adaptor type matching <code>connectionDictionary()</code> 
    */
       public String adaptorName()
    {
        return adaptorName;
    }



    /**
     * Returns list of models to <b>not</b> connect with 
     * <code>connectionDictionary()</code>. 
     * 
     * @return list of models to <b>not</b> connect with 
     * <code>connectionDictionary()</code>
     */
    public NSArray modelsToIgnore()
    {
        return modelsToIgnore;
    }

    
    /** invariant [has_connectionDictionary] connectionDictionary != null;  
                  [has_adaptorName] adaptorName != null; 
                  [has_modelsToIgnore] modelsToIgnore != null; **/
 
}
