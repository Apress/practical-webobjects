package com.apress.practicalwo.practicalutilities.tests;

import java.math.BigDecimal;
import java.util.Enumeration;

import com.apress.practicalwo.practicalutilities.*;

import com.webobjects.eoaccess.*;
import com.webobjects.eocontrol.*;
import com.webobjects.foundation.NSArray;


/**
 * Test EOEditingContext.
 *
 * @author Copyright (c) 2001-2  Global Village Consulting, Inc.  All rights reserved.
 * @version $Revision: 2$
 */
public class EOEditingContextTest extends EOTestCase
{
    ToOneEntity testObject1;
    ToOneEntity testObject2;
    com.webobjects.eocontrol.EOEditingContext ec1;
    com.webobjects.eocontrol.EOEditingContext ec2;
    EOObjectStoreCoordinator osc; 


    /**
     * Designated constuctor.
     */
    public EOEditingContextTest(String name)
    {
        super(name);
    }



    /**
     * Common test code.
     */
    public void setUp() throws java.lang.Exception
    {
        super.setUp();

        // Editing context with default object store co-ordinator.
        ec1 = new com.apress.practicalwo.practicalutilities.ValidatingEditingContext();
        testObject1 = new ToOneEntity();
        ec1.insertObject(testObject1);
        testObject1.setName(globallyUniqueString());  
        ec1.saveChanges();							  
                           
        // In order to simulate adapator level errors during a saveChanges, we need to create an editing context with its own EOF stack so that it has its own snapshots.
         osc = new EOObjectStoreCoordinator(); 
         ec2 = new com.apress.practicalwo.practicalutilities.ValidatingEditingContext(osc);
    }



    /**
     * Test Optimistic Locking Failures betweem the two editing contexts
     */
    public void testOptimisticLockingFailureOnUpdate()
    {
        testObject2 = (ToOneEntity)EOUtilities.localInstanceOfObject(ec2, testObject1);
        testObject2.setName(globallyUniqueString());

        testObject1.setName(globallyUniqueString());

        try
        {
            ec1.saveChanges();
            ec2.saveChanges();
            fail("Did not raise exception for testOptimisticLockingFailureOnUpdate");
        }
        catch (EOFValidationException e)
        {
            assertTrue(e.isExceptionForFailure(null, EOFValidation.OptimisticLockingFailure));
        }
    }



    /**
     * Test Insertion Failures
     *
     *  This test requires a contstraint to be place on databse:
     *  Oracle:
     *      <code>ALTER TABLE entity_with_contraints ADD CONSTRAINT quantity_below_10 CHECK (quantity < 10);</code>
     *  FrontBase:
     *      <code>ALTER TABLE entity_with_constraints ADD CONSTRAINT quantity_below_10 CHECK (quantity < 10);</code>
     */
    public void testInsertionFailure()
    {
        EOEditingContext ec = new ValidatingEditingContext();
        EntityWithConstraints constrainedObject = new EntityWithConstraints();
        ec.insertObject(constrainedObject);
        constrainedObject.setQuantity(new BigDecimal("9.0"));
        constrainedObject = new EntityWithConstraints();
        ec.insertObject(constrainedObject);
        constrainedObject.setQuantity(new BigDecimal("7.0"));
        constrainedObject = new EntityWithConstraints();
        ec.insertObject(constrainedObject);
        constrainedObject.setQuantity(new BigDecimal("5.0"));
        ec.saveChanges();
        
        constrainedObject = new EntityWithConstraints();

        ec = new ValidatingEditingContext();
        NSArray allObjects = EOUtilities.objectsForEntityNamed(ec, "EntityWithConstraints");
        ec.insertObject(constrainedObject);
        constrainedObject.setQuantity(new BigDecimal("19.0"));

        // Code to see what FB does with multiple updates.
        ((EntityWithConstraints)allObjects.objectAtIndex(0)).setQuantity(new BigDecimal("3.7"));

        try
        {
            ec.saveChanges();
            fail("Test constraint of 'quantity < 10.0' missing from database");
        }
        catch (EOFValidationException e)
        {
            assertEquals(e.getLocalizedMessage(), "Failed while trying to add this Entity With Constraints.");
        }
    }



    /**
     * Common test code.
     */
    public void tearDown() throws java.lang.Exception
    {
        ec1.revert();
        ec2.revert();

        // Try to cleanup.
        try
        {
            ec1.deleteObject(testObject1);
            ec1.saveChanges();
        }
        catch (Throwable t){}


        Enumeration databaseContextEnumerator = osc.cooperatingObjectStores().objectEnumerator();

        while (databaseContextEnumerator.hasMoreElements())
        {
            EODatabaseContext currentDatabaseContext = (EODatabaseContext) databaseContextEnumerator.nextElement();

            if( ! currentDatabaseContext.hasBusyChannels())
            {
                Enumeration registeredChannelEnumerator =
                currentDatabaseContext.registeredChannels().objectEnumerator();

                while (registeredChannelEnumerator.hasMoreElements())
                {
                    ((EODatabaseChannel)registeredChannelEnumerator.nextElement()).adaptorChannel().closeChannel();
                }

                osc.removeCooperatingObjectStore(currentDatabaseContext);
            }
            else
            {
                // Should probably handle this in a more robust way...
                System.out.println("Busy channel preventing diconnection!");
            }
        }

        super.tearDown();
    }



}
