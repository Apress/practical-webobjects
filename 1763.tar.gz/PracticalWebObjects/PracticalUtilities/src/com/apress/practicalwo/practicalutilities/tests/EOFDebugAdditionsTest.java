package com.apress.practicalwo.practicalutilities.tests;

import com.apress.practicalwo.practicalutilities.EOFDebugAdditions;
import com.apress.practicalwo.practicalutilities.EOTestCase;
import com.webobjects.eoaccess.EODatabaseContext;
import com.webobjects.eoaccess.EOUtilities;
import com.webobjects.jdbcadaptor.JDBCAdaptorException;



public class EOFDebugAdditionsTest extends EOTestCase
{
    CooperatingEditingContextTestObject source;
    CooperatingEditingContextTestObject destination;
    

    public EOFDebugAdditionsTest(String arg0)
    {
        super(arg0);
    }



    protected void setUp() throws Exception
    {
        super.setUp();
        
        source = new CooperatingEditingContextTestObject();
        editingContext().insertObject(source);
        source.setStringValue("source object");

        destination = new CooperatingEditingContextTestObject();
        editingContext().insertObject(destination);
        destination.setStringValue("destination object");

        source.setRelatedObject(destination);
       
        editingContext().saveChanges();

        try
        {
            // This only works to create a referential integrity problem as I have
            // not modeled the backpointing relationship from destination to
            // source.  If this is modeled then EOAdaptorChannel methods will need
            // to be used to delete this.
            editingContext().deleteObject(destination);
            editingContext().saveChanges();
        }
        catch (JDBCAdaptorException e)
        {
            throw new RuntimeException("EOFDebugAdditionsTest requires that the " + 
            "database be generated without foreign key constraints");
        }
        
        // Force a refetch to provoke the problem
        editingContext().invalidateAllObjects();
    }




    public void testDatabaseContextFailedToFetchObject()
    {
        EODatabaseContext databaseContext =
            EOUtilities.databaseContextForModelNamed(editingContext(),
            "PracticalUtilitiesTestEOModel");
         
        try
        {
            databaseContext.setDelegate(new EOFDebugAdditions());
        
            try
            {
                System.out.println(source.relatedObject().stringValue());
                fail("failure to fetch not detected");
            }
            catch (Exception e)
            {
                if ( ! e.getMessage().startsWith("Failed to fetch"))
                {
                    fail("Wrong exception raised: " + e);
                }
            }
        }
        finally
        {
            // This needs to be reset as it interferes with testIsDummyFaultEO
            databaseContext.setDelegate(null);
        }
    }



    public void testIsDummyFaultEO()
    {
        assertTrue(EOFDebugAdditions.isDummyFaultEO(source.relatedObject()));
    }



    protected void tearDown() throws Exception
    {
        // Set relatedObject to null to avoid snaptshot related exceptions for
        // the dummy fault
        source.setRelatedObject(null);
        
        editingContext().deleteObject(source);
        editingContext().saveChanges();
        super.tearDown();
    }

}
