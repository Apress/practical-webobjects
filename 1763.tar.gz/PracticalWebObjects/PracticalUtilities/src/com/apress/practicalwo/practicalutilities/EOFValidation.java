package com.apress.practicalwo.practicalutilities;

import com.webobjects.eoaccess.*;
import com.webobjects.eocontrol.EOEnterpriseObject;
import com.webobjects.foundation.*;


/**
 * The main controlling class for EOFValidation.
 * <p>
 * <b>Introduction</b><br>
 * The purpose of the EOFValidation framework is to enhance standard EOF validation to provide:
 * <ul>
 * <li>more extensive validations
 * <li>code-free, customizable, localizable validation messages
 * <li>client code access to customizable, localizable validation messages
 * <li>more accessible information about failures
 * <li>better handling for adaptor level errors (exceptions that the db engine raises).
 * </ul>
 * <p>
 * <b>Using the EOFValidation Framework</b><br>
 * The validation framework must be explicitly activated by the client application.  This must be done before the first call to any of the EOF classes.  This is best done in the WOApplication constructor.
 * <p> <pre>
 *     import net.global_village.eofvalidation.*;
 *
 *     public Application()
 *     {
 *         super();
 *         EOFValidation.installValidation();
 *         ...
 * </pre> <p>
 * Once this is done, there is no more to do, unless there is a need to trap specific exceptions and handle them.  For most cases, simply showing the exception reason should be sufficient.
 * <p><pre>
 * try {
 *     ec.saveChanges();
 * }
 * catch (EOFValidationException e) {
 *     addMessages(e.getLocalizedMessageForUnaggregatedExceptions());
 * }
 * </pre><p>
 * <p>
 * <p>
 * <b>Location of Validation Error Messages</b><br>
 * The validation error messages are taken from localized strings files which can be located in several places.  The choice of location depends on the organizational goals of the project, there are no functional differences.  See <a href="#LocalizationEngine#localizedStringFromBundle">LocalizationEngine.localizedStringFromBundle</a> for details.<br>
 * <p>
 * <p>
 * <p>
 * <b>Customzing Message Content</b><br>
 * All of the messages can be customized by adding special substitution tags.  The substitution tags available are documented in <a href="LocalizedValidationException#validationFailureDictionary">LocalizedValidationException.validationFailureDictionary</a>.
 * <p>Futhermore, the names displayed for entities, attributes and relationships can be customized and localized by defining an entity display name as:
 * <p>&lt;entityName&gt;.&lt;EOFValidation.DisplayName&gt;                        e.g. WorkOrder.displayName="Work Requisition";
 * <p>&lt;entityName&gt;.&lt;propertyName&gt;.&lt;EOFValidation.DisplayName&gt;     e.g. WorkOrder.orderDate.displayName="order submission date";
 * <p>
 * <p>
 * <p>
 * <b>Default Validation Messages</b><br>
 * These defaults are supplied in the EOFValidation Framework.  They will be used if you do not provide a corresponding customized message.
 * <ul>
 * <li>Entity.nullNotAllowed = "You must enter a &lt;&lt;propertyName&gt;&gt; for this &lt;&lt;entityName&gt;&gt;";
 * <li>Entity.tooLong = "The value you entered, &lt;&lt;failedValue&gt;&gt;, is longer than the &lt;&lt;attribute.width&gt;&gt; characters allowed for &lt;&lt;propertyName&gt;&gt; on &lt;&lt;entityName&gt;&gt;.";
 * <li>Entity.invalidValue = "&lt;&lt;failedValue&gt;&gt; is not an acceptable &lt;&lt;propertyName&gt;&gt; for &lt;&lt;entityName&gt;&gt;.";
 * <li>Entity.belowMinimum = "&lt;&lt;failedValue&gt;&gt; is below the acceptable limit for &lt;&lt;propertyName&gt;&gt; for &lt;&lt;entityName&gt;&gt;.";
 * <li>Entity.aboveMaximum = "&lt;&lt;failedValue&gt;&gt; is above the acceptable limit for &lt;&lt;propertyName&gt;&gt; for &lt;&lt;entityName&gt;&gt;.";
 * <li>Entity.notUnique = "&lt;&lt;failedValue&gt;&gt; has already been used as a &lt;&lt;propertyName&gt;&gt; for &lt;&lt;entityName&gt;&gt;.";
 * </ul>
 *
 * @author Chuck Hill and Sacha Mallais
 */
public class EOFValidation extends Object
{
 

    /**
     * Substitution key for value which failed validation.  This can be used in customized validation template messages.  An example: <br>
     * "The value you entered, &lt;&lt;failedValue&gt;&gt;, is longer than the &lt;&lt;attribute.width&gt;&gt; characters allowed for &lt;&lt;propertyName&gt;&gt; on &lt;&lt;entityName&gt;&gt;";
     */
    public static final String  FailedValue = "failedValue";


    /**
     * Substitution key for the localized (DisplayName) name of the attribute which failed validation.  This can be used in customized validation template messages.  An example: <br>
     * "The value you entered, &lt;&lt;failedValue&gt;&gt;, is longer than the &lt;&lt;attribute.width&gt;&gt; characters allowed for &lt;&lt;propertyName&gt;&gt; on &lt;&lt;entityName&gt;&gt;";
     */
    public static final String  PropertyName = "propertyName";


    /**
     * Substitution key for the localized (DisplayName) name of the entity containing the attribute which failed validation.  This can be used in customized validation template messages.  An example: <br>
     * "The value you entered, &lt;&lt;failedValue&gt;&gt;, is longer than the &lt;&lt;attribute.width&gt;&gt; characters allowed for &lt;&lt;propertyName&gt;&gt; on &lt;&lt;entityName&gt;&gt;";
     */
    public static final String  EntityName = "entityName";


    /**
     * Substitution key for the actual entity of the object which failed to validate or save (for exceptions raised during saveChanges()).  This can be used in customized validation template messages, though it is mostly for locating the template to be customized.  An example: <br>
     * "&lt;&lt;entity.userInfo.couldNotSave&gt;&gt;";
     * <br>This example takes the entire validation failure message from the key couldNotSave in the userInfo dictionary of the entity.
     */
    public static final String  EntityFailedOn = "entity";


    /**
     * Substitution key for the actual attribute of the object which failed to validate or save.  This can be used in customized validation template messages.  An example: <br>
     * "The value you entered is longer than &lt;&lt;attribute.width&gt;&gt;";
     */
    public static final String  AttributeFailedOn = "attribute";


    /**
     * Substitution key for the actual object which failed to save (for exceptions raised during saveChanges() only).  This can be used in customized validation template messages.  An example: <br>
     * "Your changes to the &lt;&lt;entityName&gt;&gt; \"&lt;&lt;object.toString&gt;&gt;\" could not be saved as another user has modified it.";
     */
    public static final String  ObjectFailedOn = "object";



    /**
     * Message key for nullity validation failure.  Thes is to be used in localization keys in strings files.  An example: <br>
     * Employee.firstName.nullNotAllowed = "You must enter a &lt;&lt;propertyName&gt;&gt; for this &lt;&lt;entityName&gt;&gt;.";
     */
    public static final String  NullNotAllowed = "nullNotAllowed";


    /**
     * Message key for excessive length validation failure.  Thes is to be used in localization keys in strings files.  An example: <br>
     * Employee.firstName.tooLong = "The value you entered, &lt;&lt;failedValue&gt;&gt;, is longer than the &lt;&lt;attribute.width&gt;&gt; characters allowed for &lt;&lt;propertyName&gt;&gt; on &lt;&lt;entityName&gt;&gt;";
     */
    public static final String  TooLong = "tooLong";


    /**
     * Message key for an invalid value (type mismatch, formatter failure, but not null) validation failure.  Thes is to be used in localization keys in strings files.  An example: <br>
     * Employee.age.invalidValue = "&lt;&lt;failedValue&gt;&gt; is not an acceptable &lt;&lt;propertyName&gt;&gt; for this &lt;&lt;entityName&gt;&gt;.";
     */
    public static final String  InvalidValue = "invalidValue";


    /**
     * Future use message keys for a value below a minimum value validation failure.  This is to be used in localization keys in strings files.  It should also be used in any custom code checking for these validation failures.  An example: <br>
     * Employee.age.belowMinimum = "&lt;&lt;entityName&gt;&gt; must be above 16 years of age.";
     */
    public static final String  BelowMinimum = "belowMinimum";


    /**
     * Future use message keys for a value above a maximum value validation failure.  This is to be used in localization keys in strings files.  It should also be used in any custom code checking for these validation failures.  An example: <br>
     * Employee.age.aboveMaximum = "&lt;&lt;entityName&gt;&gt; must be younger than 99 years of age.";
     */
    public static final String  AboveMaximum = "aboveMaximum";


    /**
     * Future use message keys for a value which is not unique validation failure.  This is to be used in localization keys in strings files.  It should also be used in any custom code checking for these validation failures.  An example: <br>
     * Employee.idNumber.notUnique = "The &lt;&lt;entityName&gt;&gt;'s ID number has already been used.";
     */
    public static final String  NotUnique = "notUnique";


    /**
     * Message keys for optimistic locking save failure.  This is to be used in localization keys in strings files.  An example: <br>
     * Employee.optimisticLockingFailure = "Another user has changed this &lt;&lt;entityName&gt;&gt;, check your changes and re-submit.";
     */
    public static final String  OptimisticLockingFailure = "optimisticLockingFailure";


    /**
     * Message keys for delete failure.  This is to be used in localization keys in strings files.  An example: <br>
     * Employee.failedToDelete = "This &lt;&lt;entityName&gt;&gt; is still employed and can not be deleted.";
     */
    public static final String  FailedToDelete = "failedToDelete";


    /**
     * Message keys for insertion failure.  This is to be used in localization keys in strings files.  An example: <br>
     * Employee.failedToInsert = "Database has been disconnected.";
     */
    public static final String  FailedToInsert = "failedToInsert";


    /**
     * Message keys for optimistic locking save failure.  This is to be used in localization keys in strings files.  An example: <br>
     * Employee.failedToUpdate = "Database has been disconnected.";
     */
    public static final String  FailedToUpdate = "failedToUpdate";


    /**
     * Message keys for failed to lock.  This is to be used in localization keys in strings files.  An example: <br>
     * Employee.failedToLock = "Another user is changing this &lt;&lt;entityName&gt;&gt;, please try again in a few minutes.";
     */
    public static final String  FailedToLock = "failedToLock";


    /**
     * Message keys for a stored procedure failure.  This is to be used in localization keys in strings files.  An example: <br>
     * Employee.failedOnStoredProcedure = "Call the DBA!  :-).";
     */
    public static final String  FailedOnStoredProcedure = "failedOnStoredProcedure";


    /**
     * Message key for localized display name for entities and properties.  This are to be used in localization keys in strings files. An example: <br>
     * Employee.firstName.displayName = "given name";<br>
     * Employee.displayName = "client";
     */
    public static final String  DisplayName = "displayName";


    /**
     * String used when forming generic (i.e. without the actual entity name) key paths for localization.  An example: <br>
     * Entity.nullNotAllowed = "You must enter a &lt;&lt;propertyName&gt;&gt; for this &lt;&lt;entityName&gt;&gt;.";
     */
    public static final String EntityGenericName = "Entity";


    /**
     * A set of all failure keys.
     */
    public static final NSSet setOfAllFailureKeys = new NSSet(new Object[] {NullNotAllowed, TooLong, InvalidValue, BelowMinimum, AboveMaximum, NotUnique, OptimisticLockingFailure, FailedToDelete, FailedToInsert, FailedToUpdate, FailedToLock, FailedOnStoredProcedure});


    static protected boolean shouldTreatEmptyStringsAsNull = true;
    static protected boolean hasInstalled = false;



    /**
     * Main validation method.  Call this once to install validation.
     */
    public static void installValidation()
    {
        if ( ! hasInstalled)
        {
            if (NSLog.debugLoggingAllowedForLevel(NSLog.DebugLevelInformational))
                NSLog.debug.appendln("*** EOFValidation installed");
            EOModelNotificationProxy.listenForAddedModels();
            hasInstalled = true;
        }
    }


    /**
     * Returns <code>true</code> if empty / all white space strings are to be considered null for the purposes of validation.
     *
     * @return <code>true</code> if empty strings are to be considered null for the purposes of validation 
     */
    public static boolean shouldTreatEmptyStringsAsNull()
    {
        return shouldTreatEmptyStringsAsNull;
    }



    /**
     * Use to indicate whether empty / all white space strings are to be considered null for the purposes of validation.
     *
     * @param treatAsNull <code>true</code> if empty strings are to be considered null when validating.
     */
    public static void setShouldTreatEmptyStringsAsNull(boolean treatAsNull)
    {
        shouldTreatEmptyStringsAsNull = treatAsNull;
    }



    /**
     * Private constructor.  
     */
    private EOFValidation()
    {
        super();
    }



    ///////////////////////////////////////////////////////////////////////////////////
    // Below here are static methods used in interpreting validation failure exceptions
    ///////////////////////////////////////////////////////////////////////////////////


    /**
     * String returned as the exception reason when a NSDateFormatter fails.
     */
    public static final String InvalidDateStringReason   = "Invalid date string";


    /**
     * String returned as the exception reason when a NSNumber fails.
     */
    public static final String InvalidNumberStringReason = "Invalid number";


    /**
     * Keypath to make accessing the contents of adaptor failure exceptions easier.
     */
    public static final String GVCValidationAdaptorExceptionKeypath = "EOFailedDatabaseOperationKey._adaptorOps._exception";



    /**
     * Returns <code>true</code> if this exception is from an EOAdaptor failure.  This is detected by checking for the presence of EOFailedAdaptorOperationKey.  If this key is present, then this exception has the expected keys and can be analysed as an adaptor failure exception.
     *
     * @param exception the exception to check.
     * @return true if this exception is from an EOAdaptor failure
     */
    static public boolean isAdaptorFailureException(EOGeneralAdaptorException exception)
    {
        /** require [valid_param] exception != null; **/

        boolean isAdaptorFailureException = false;
        if (exception.userInfo() != null)
        {
            isAdaptorFailureException = exception.userInfo().objectForKey(EOAdaptorChannel.FailedAdaptorOperationKey) != null;
        }

        return isAdaptorFailureException;
    }



    /**
     * Returns <code>true</code> if this exception is from an EOAdaptor failure.  This is detected by checking for the presence of EOFailedAdaptorOperationKey.  If this key is present, then this exception has the expected keys and can be analysed as an adaptor failure exception.
     *
     * @param exception the exception to check.
     * @return <code>true</code> if this exception is an optimistic locking failure
     */
    static public boolean isOptimisticLockingFailure(EOGeneralAdaptorException exception)
    {
        /** require [valid_param] exception != null; **/

        boolean isOptimisticLockingFailure = false;

        if (exception.userInfo() != null)
        {
            String adaptorFailureKey = (String)exception.userInfo().objectForKey(EOAdaptorChannel.AdaptorFailureKey);
            if (adaptorFailureKey != null)
            {
                isOptimisticLockingFailure = adaptorFailureKey.equals(EOAdaptorChannel.AdaptorOptimisticLockingFailure);
            }
        }

        return isOptimisticLockingFailure;
    }



    /**
     * Returns the object that the adaptor failure exception was raised for.
     *
     * @param exception the exception to check.
     * @return the object that the adaptor failure exception was raised for.
     */
    static public EODatabaseOperation databaseOperation(EOGeneralAdaptorException exception)
    {
        /** require
        [valid_param] exception != null;
        [is_adaptor_failure_exception] isAdaptorFailureException(exception); **/

        return (EODatabaseOperation)exception.userInfo().valueForKeyPath(EODatabaseContext.FailedDatabaseOperationKey);

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Returns the EO object that the adaptor failure exception was raised for.
     *
     * @param exception the exception to check.
     * @return the EO object that the adaptor failure exception was raised for.
     */
    static public EOEnterpriseObject objectSaveFailedOn(EOGeneralAdaptorException exception)
    {
        /** require
        [valid_param] exception != null;
        [is_adaptor_failure_exception] isAdaptorFailureException(exception); **/

        EODatabaseOperation operation = databaseOperation(exception);
        return (EOEnterpriseObject)operation.object();

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Returns the entity for the object that the adaptor failure exception was raised for.
     *
     * @param exception the exception to check.
     * @return the entity for the object that the adaptor failure exception was raised for.
     */
    static public EOEntity entitySaveFailedOn(EOGeneralAdaptorException exception)
    {
        /** require
        [valid_param] exception != null;
        [is_adaptor_failure_exception] isAdaptorFailureException(exception); **/

        EODatabaseOperation operation = databaseOperation(exception);
        return operation.entity();

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Returns the adaptor operation that was being performed when the adaptor failure exception occurred.
     *
     * @param exception the exception to check.
     * @return the adaptor operation that was being performed when the adaptor failure exception occurred.
     */
    static public int failedAdaptorOperator(EOGeneralAdaptorException exception)
    {
        /** require
        [valid_param] exception != null;
        [is_adaptor_failure_exception] isAdaptorFailureException(exception); **/

        // Although the name of the key EOFailedDatabaseOperationKey would suggest that a singular result is returned, the result is in fact an array.  The array has a single element which is a number (Adaptor Operators are defined as ints).
        NSArray adaptorOperators = databaseOperation(exception).adaptorOperations();
        return ((EOAdaptorOperation)adaptorOperators.objectAtIndex(0)).adaptorOperator();
    }



    /**
     * Returns the exception message from the database which caused the save to fail.
     *
     * @param exception the exception to check.
     * @return the exception message from the database which caused the save to fail.
     */
    static public String databaseExceptionReason(EOGeneralAdaptorException exception)
    {
        /** require
        [valid_param] exception != null;
        [is_adaptor_failure_exception] isAdaptorFailureException(exception); **/

        // Although the name of the key EOFailedDatabaseOperationKey would suggest that a singular result is returned, the result is in fact an array.  The array has a single element which is a String.
        EODatabaseOperation databaseOperation = databaseOperation(exception);
        EOAdaptorOperation adaptorOperation = (EOAdaptorOperation)databaseOperation.adaptorOperations().objectAtIndex(0);
        return adaptorOperation.exception().toString();

        /** ensure [valid_result] Result != null; **/
    }



}
