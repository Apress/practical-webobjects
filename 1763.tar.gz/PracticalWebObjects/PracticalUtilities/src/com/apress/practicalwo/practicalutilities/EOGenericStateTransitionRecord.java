package com.apress.practicalwo.practicalutilities;

import com.webobjects.eocontrol.EOClassDescription;


/**
 * EOGenericNotificationRecord is a default, empty implementation of the 
 * EditingContextNotification interface.
 * 
 * @author Chuck Hill and Sacha Mallais
 */
public class EOGenericStateTransitionRecord
    extends com.webobjects.eocontrol.EOGenericRecord
    implements EOStateTransition
{


    public EOGenericStateTransitionRecord(EOClassDescription classDescription)
    {
        super(classDescription);
    }

    public EOGenericStateTransitionRecord()
    {
        super();
    }

    public void willDelete()
    {
    }

    public void willUpdate()
    {
    }

    public void hasInserted()
    {
    }

    public void hasDeleted()
    {
    }

    public void hasUpdated()
    {
    }
}