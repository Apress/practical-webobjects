package com.apress.practicalwo.practicalutilities;


/**
 * The interface used by the CooperatingEditingContext to determine which EOs 
 * should receive notifications.
 *
 * @author Chuck Hill and Sacha Mallais
 */
public interface EOStateTransition
{

    /**
     * Called before deleteObject is invoked on super (EOEditingContext).  
     * Make copies here of any values that you want to use in hasUpdated.
     */
    public void willDelete();

    /**
     * Called before saveChanges is invoked on super (EOEditingContext).  
     * This would allow things such as setting the dateModified before saving an
     * EO.  
     */
    public void willUpdate();

    /**
     * Called after a newly inserted object has been saved to the persistent 
     * object store (a.k.a. database).  This can be used to save related, 
     * non-EO, resources after the EO has been inserted.  This method should not
     * cause changes in the object graph as this may cause notifications to be 
     * lost.
     */
    public void hasInserted();

    /**
     * Called after a deleted object has been removed from the persistent object
     * store.  This can be used to clean up related, non-EO, resources after the
     * EO is deleted. This method should not cause changes in the object graph as
     * this may cause notifications to be lost 
     */
    public void hasDeleted();

    /**
     * Called after saveChanges is invoked on super (EOEditingContext).  This can 
     * be used to save related, non-EO, resources after the EO has been udpated.
     * This method should not cause changes in the object graph as this may cause 
     * notifications to be lost.
     */
    public void hasUpdated();

}
