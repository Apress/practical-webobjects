package com.apress.practicalwo.practicalutilities;

import java.util.Enumeration;

import org.apache.log4j.Logger;

import com.webobjects.eoaccess.EOEntity;
import com.webobjects.eoaccess.EORelationship;
import com.webobjects.eoaccess.EOUtilities;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.eocontrol.EOEnterpriseObject;
import com.webobjects.eocontrol.EOGlobalID;
import com.webobjects.foundation.*;


/**
 * This class provides an interface for flexible copying of EOEnterpriseObjects 
 * and a default implementation for doing the actual copying.  This default 
 * implementation would be most easily used by creating a sub-class of 
 * EOCustomObject or EOGenericRecord and using that as the super class of your
 * EOEnterpriseObjects.
 *
 * @author Chuck Hill and Sacha Mallais
 */
public interface EOCopyable
{
    public static Logger copyLogger = Logger.getLogger(
        "com.apress.practicalwo.practicalutilities.EOCopyable");

    public static final String COPY_CONTEXT = "copyContext";
    
    /**
     * Returns a copy of this object, copying related objects as well.  The 
     * actual copy mechanism (by reference, shallow, deep, or custom) for each 
     * object is up to the object being copied.  If a copy already exists in 
     * <code>copiedObjects</code>, then that is returned instead of making a new
     * copy.  This allows complex graphs of objects, including those with cycles,
     * to be copied without producing duplicate objects.  The graph of copied 
     * objects will be the same regardless of where copy is started with two 
     * exceptions: if it is started on a reference copied object or if a reference 
     * copied object is the only path between two disconnected parts of the graph.
     * In these cases the reference copied object prevents the copy from following 
     * the graph further.
     *
     * @param copiedObjects the copied objects keyed on the EOGlobalID of the 
     * object the copy was made from.
     * @return a copy of this object
     */
    public EOEnterpriseObject copy(NSMutableDictionary copiedObjects);
    //** require [copiedObjects_not_null] copiedObjects != null;  **/
    //** ensure [copy_made] Result != null;  
    //          [copy_recorded] copiedObjects.objectForKey(this.editingContext().
    //                          globalIDForObject(this)) != null;  **/



    /**
     * Returns a copy of this object.  Each EOEnterpriseObject should implement 
     * this to produce the actual copy by an appropriate mechanism (reference, 
     * shallow, deep, or custom).
     *
     * @param copiedObjects the copied objects keyed on the EOGlobalID of the 
     * object the copy was made from.
     * @return a copy of this object
     */
    public EOEnterpriseObject duplicate(NSMutableDictionary copiedObjects);
    //** require [copiedObjects_not_null] copiedObjects != null;  **/
    //** ensure [copy_made] Result != null;   **/
    
    
    
    
    /**
     * This class provides a default implementation of EOCopyable that handles 
     * the most common situations encountered copying EO objects.  This default 
     * implementation would be most easily used by creating a sub-class of 
     * EOCustomObject or EOGenericRecord and using that as the super class of 
     * your EOEnterpriseObjects.  For example:<br>
     * <pre>
     * public class CopyableGenericRecord extends EOGenericRecord
     * {
     *     public CopyableGenericRecord()
     *     {
     *         super();
     *     }
     *
     *     public EOEnterpriseObject copy(NSMutableDictionary copiedObjects)
     *     { 
     *         return EOCopyable.DefaultImplementation.copy(copiedObjects, this);
     *     }
     *
     *     // Sub-classes can override this to copy via a different mechanism.  
     *     // This can be anything from EOCopyable.Utility.referenceCopy(this) 
     *     // to a fully customized copy.
     *     public EOEnterpriseObject duplicate(NSMutableDictionary copiedObjects)
     *     {
     *         return EOCopyable.DefaultImplementation.duplicate(copiedObjects, 
     *                                                           this);
     *     }
     * }
     * </pre>
     * <b>Notes</b><br>
     * Debugging information can be turned on with the DEBUG level of the log4j 
     * logger
     * <code>com.apress.practicalwo.practicalutilities.EOCopyable</code>.<br><br>
     * If you implement your own deep copy of relationships you should register 
     * the new object before copying its relationships to so that circular       
     * relationships will be copied correctly.  For example:<br>
     * <pre>
     * EOGlobalID globalID = editingContext().globalIDForObject(this);
     * copiedObjects.setObjectForKey(copy, globalID);
     * </pre>
     */
     public static class DefaultImplementation
     {

         /**
           * Returns a copy of this object.  The actual copy mechanism (by 
           * reference, shallow, deep, or custom) is up to the object being 
           * copied.  If a copy already exists in <code>copiedObjects</code>, 
           * then that is returned instead of making a new copy.  This allows 
           * complex graphs of objects, including those with cycles, to be 
           * copied without producing duplicate objects.
           *
           * @param copiedObjects the copied objects keyed on the EOGlobalID 
           * of the object the copy was made from.
           * @param source the EOEnterpriseObject to copy
           * @return a copy of this object
           */
         public static EOEnterpriseObject copy(NSMutableDictionary copiedObjects, 
                                               EOEnterpriseObject source) {
             //** require [copiedObjects_not_null] copiedObjects != null;
             //            [valid_source] source != null;
             //            [source_EOCopyable] source instanceof EOCopyable;  **/

             EOGlobalID globalID = source.editingContext().
                 globalIDForObject(source);

                 copyLogger.debug("Copying object " + globalID);

             EOEnterpriseObject copy = (EOEnterpriseObject)copiedObjects.
                 objectForKey(globalID);
                 
             if (copy == null) {
                 copyLogger.debug("Creating duplicate of object " + globalID);

                 copy = ((EOCopyable)source).duplicate(copiedObjects);
                 copiedObjects.setObjectForKey(copy, globalID);
             }
             
             return copy;
             
             //** ensure [copy_made] copy != null;
             //           [copy_cached] copiedObjects.objectForKey(
             //                             source.editingContext().
             //                             globalIDForObject(source)) != null; **/
         }



         /**
          * Returns a deep copy of this object.  
          *
          * @param copiedObjects the copied objects keyed on the EOGlobalID of 
          * the object the copy was made from.
          * @return a deep copy of this object
          */
         public static EOEnterpriseObject duplicate(
             NSMutableDictionary copiedObjects, EOEnterpriseObject source)
         {
             //** require [copiedObjects_not_null] copiedObjects != null;
             //            [valid_source] source != null;                  **/

             EOEnterpriseObject duplicate = Utility.deepCopy(copiedObjects, 
                                                             source);
             return duplicate;
             
             //** ensure [duplicate_made] duplicate != null;      **/
         }

     }


    /**
     * This class provides utility methods for use implementing EOCopyable.  They 
     * handle the most common situations encountered copying EO objects.  The 
     * DefaultImplementation uses them internally.  The implementations of 
     * referenceCopy, shallowCopy(), and deepCopy() should be suitable for most 
     * eo objects to use for their duplicate(NSMutableDictionary) method.  
     * However there are some situations that can not be handled with this 
     * generic code:<br>
     * <ol>
     * <li>An attribute or relationship must not be copied (e.g. order numbers).</li>
     * <li>An attribute or relationship needs special handling (e.g. dateModified
     * should reflect when the copy was made, not when the original object was 
     * created).</li>
     * <li>An EO object should not be copied the same way in all situations (e.g. 
     * the relationship from one object should be copied deeply, but from 
     * another object should be a reference copy).</li>
     * <li>The relationships must be copied in a certain order (e.g. due to side 
     * effects in the methods setting the relationships).</li>
     * </ol>
     * In this situations you will need to write a custom implementation of the 
     * duplicate(NSMutableDictionary) method.  This can be as simple as invoking 
     * the default implementation and then cleaning up the result to as complex 
     * as doing it all by hand.  Utility also provides lower-level methods that 
     * you can use when creating a custom duplicate(NSMutableDictionary) method.  
     * These are: newInstance(), copyAttributes(), exposedKeyAttributeNames(), 
     * shallowCopyRelatedObjects(), and deepCopyRelatedObjects(), 
     * cleanRelationships(), and deepCopyRelationship.  Debugging information can
     * be turned on with the DEBUG level of the log4j logger
     * <code>com.apress.practicalwo.practicalutilities.EOCopyable</code>.
     */
    public static class Utility
    {
        protected static NSMutableDictionary exposedKeyAttributeDictionary = null;


        /**
         * Returns a copy of this object by reference.  This is equivalent to 
         * <code>return this;</code> on an EOEnterpriseObject.  This method of 
         * copying is suitable for lookup list items and other objects which 
         * should never be duplicated.
         *
         * @param source the EOEnterpriseObject to copy
         * @return a copy of this object
         */
        public static EOEnterpriseObject referenceCopy(EOEnterpriseObject source)
        {
            //** require [valid_source] source != null;
            //            [source_EOCopyable] source instanceof EOCopyable;  **/

            copyLogger.debug("Reference copying " + globalIDForObject(source));
            return source;
            
            //** ensure [copy_made] source != null;  **/
        }



        /**
          * Returns a shallow copy of this object, the attribute values are 
          * copied and the relationships are copied by reference.  This method 
          * of copying is suitable for things like an order item where 
          * duplication of the product is not wanted and where the order will 
          * not be changed (the copied order item will be on the orginal order, 
          * not a copy of it).
          *
          * @param source the EOEnterpriseObject to copy
          * @return a copy of this object
          */
        public static EOEnterpriseObject shallowCopy(EOEnterpriseObject source)
        {
            //** require [valid_source] source != null;
            //            [source_EOCopyable] source instanceof EOCopyable;   **/

            copyLogger.debug("Making shallow copy of " + globalIDForObject(source));

            EOEnterpriseObject copy = newInstance(source);
            copyAttributes(source, copy);
            shallowCopyRelatedObjects(source, copy);

            return copy;

            //** ensure [copy_made] copy != null;   **/
        }



        /**
          * Returns a deep copy of this object, the attribute values are copied 
          * and the relationships are copied by calling copy(NSMutableDictionary) 
          * on them.  Thus each related will be copied by its own reference, 
          * shallow, deep, or custom duplicate(NSMutableDictionary) method.  
          * The copy is registered with copiedObjects as soon as it is created 
          * so that circular relationships can be accomodated.  This method of 
          * copying is suitable for duplicating complex graphs of objects.
          *
          * @param copiedObjects the copied objects keyed on the EOGlobalID of 
          * the object the copy was made from.
          * @param source the EOEnterpriseObject to copy
          * @return a copy of this object
          */
        public static EOEnterpriseObject deepCopy(
            NSMutableDictionary copiedObjects, EOEnterpriseObject source)
        {
            //** require 
            //    [copiedObjects_not_null] copiedObjects != null;
            //    [valid_source] source != null;
            //    [source_EOCopyable] source instanceof EOCopyable;
            //    [not_already_copied] copiedObjects.objectForKey(
            //        globalIDForObject(source)) == null;    **/
          
            copyLogger.debug("Making deep copy of " + globalIDForObject(source));

            EOEnterpriseObject copy = newInstance(source);

            // Rregister this object right away to handle circular relationships
            copiedObjects.setObjectForKey(copy, globalIDForObject(source));

            copyAttributes(source, copy);
            deepCopyRelatedObjects(copiedObjects, source, copy);

            return copy;

            //** ensure [copy_made] copy != null;
            //           [copy_recorded] copiedObjects.objectForKey(
            //                globalIDForObject(source)) != null;       **/
        }



        /**
          * This creates and returns a new instance of the same Entity as source.
          * When an EO object is created it can already have some relationships 
          * and attributes set.  These can come from to one relationships that 
          * are marked as 'owns destination' and also from the effects of 
          * awakeFromInsertion().  Preset attributes should be overwritten when 
          * all attributes are copied, but the relationships need some special 
          * handling.  See the method cleanRelationships(NSMutableDictionary,
          * EOEnterpriseObject, EOEnterpriseObject) for details on what is done.
          * This method can be used when creating custom implementations of the 
          * duplicate() method in EOCopyable.  
          *
          * @param source the EOEnterpriseObject to copy
          * @return a new instance of the same Entity as source
          */
        public static EOEnterpriseObject newInstance(EOEnterpriseObject source)
        {
            //** require [valid_source] source != null;  **/

             copyLogger.debug("Making new instance of " + globalIDForObject(source));

            EOEnterpriseObject newInstance = EOUtilities.
                createAndInsertInstance(source.editingContext(), 
                                        source.entityName());
            cleanRelationships(source, newInstance);

            return newInstance;
            
            //** ensure [newInstance_made] newInstance != null;  
            //           [same_entity] source.entityName().equals(
            //                             Result.entityName());     **/
        }



        /**
         * When an EO object is created it can already have some relationships 
         * set.  This can come from to one relationships that are marked as 'owns
         * destination' and also from the effects of awakeFromInsertion() and 
         * need some special handling prior to making a copy.
         * <ol>
         * <li>All objects are disconnected from the relationship.</li>
         * <li>If a disconnected object has a temporary EOGlobalID it is deleted.</li>
         * </ol>
         *
         * @param source the EOEnterpriseObject that copy was created from
         * @param copy the newly instantiated copy of source that needs to have 
         * its relationships cleaned
         */
        public static void cleanRelationships(EOEnterpriseObject source, 
                                              EOEnterpriseObject copy)
        {
            //** require [valid_copy] copy != null;
            //            [valid_source] source != null;    **/

            copyLogger.debug("Cleaning related objects in copy of " +
                globalIDForObject(source));

            EOEditingContext ec = source.editingContext();
            EOEntity entity = EOUtilities.entityForObject(ec, source);

            // To-Many relationships
            Enumeration relationshipEnumerator = copy.toManyRelationshipKeys().
                objectEnumerator();
            while (relationshipEnumerator.hasMoreElements())
            {
                String relationshipName = (String)relationshipEnumerator.nextElement();
                NSArray relatedObjects = (NSArray) copy.valueForKey(relationshipName);

                if (relatedObjects.count() > 0)
                {
                    EORelationship relationship = entity.relationshipNamed(relationshipName);

                    copyLogger.debug("Removing objects in to-many relationship " 
                        + relationshipName);

                    Enumeration relatedObjectEnumerator = new NSArray(relatedObjects).
                        objectEnumerator();
                    while (relatedObjectEnumerator.hasMoreElements())
                    {
                        EOEnterpriseObject relatedObject = (EOEnterpriseObject)
                            relatedObjectEnumerator.nextElement();

                        copy.removeObjectFromBothSidesOfRelationshipWithKey(
                            relatedObject, relationshipName);

                        if (globalIDForObject(relatedObject).isTemporary())
                        {
                            ec.deleteObject(relatedObject);
                        }
                    }
                }
            }

            // To-one relationships
            relationshipEnumerator =  copy.toOneRelationshipKeys().objectEnumerator();
            while (relationshipEnumerator.hasMoreElements())
            {
                String relationshipName = (String)relationshipEnumerator.nextElement();
                EOEnterpriseObject relatedObject = (EOEnterpriseObject) copy.
                    valueForKey(relationshipName);
                if (relatedObject != null)
                {
                    copyLogger.debug("Removing object in to-one relationship " + 
                        relationshipName);

                    copy.removeObjectFromBothSidesOfRelationshipWithKey(
                        relatedObject, relationshipName);
                    if (globalIDForObject(relatedObject).isTemporary())
                    {
                        source.editingContext().deleteObject(relatedObject);
                    }
                }
            }
        }



        /**
          * This copies the attributes from the source EOEnterpriseObject to the 
          * destination.  Only attributes which are class properties are copied.
          * However if an attribute is a class property and also used in a 
          * relationship it is assumed to be an exposed primary or forign key and
          * not copied.  Such attributes are set to null.  See 
          * exposedKeyAttributeNames for details on how this is determined.  It 
          * can be used when creating custom implementations of the duplicate() 
          * method in EOCopyable.  
          *
          * @param source the EOEnterpriseObject to copy attribute values from
          * @param destination the EOEnterpriseObject to copy attribute values to
          */
        public static void copyAttributes(EOEnterpriseObject source, 
                                          EOEnterpriseObject destination)
        {
            //** require [valid_source] source != null;
            //            [valid_destination] destination != null;     **/

            copyLogger.debug("Copying attributes for  " + globalIDForObject(source));

           NSArray exposedKeyAttributeNames = exposedKeyAttributeNames(source);
            Enumeration attributeNameEnumerator = source.attributeKeys().
                objectEnumerator();
            while (attributeNameEnumerator.hasMoreElements())
            {
                String attributeName = (String)attributeNameEnumerator.nextElement();

                if (exposedKeyAttributeNames.containsObject(attributeName))
                {
                    copyLogger.debug("Nulling exposed key " + attributeName);
                    destination.takeStoredValueForKey(null, attributeName);
                }
                else
                {
                    copyLogger.debug("Copying attribute " + attributeName + ", value "
                        + source.valueForKey(attributeName));
                    destination.takeStoredValueForKey(
                        source.storedValueForKey(attributeName), attributeName);
                }
            }
        }



        /**
          * Returns an array of attribute names from the EOEntity of source that 
          * are used in the primary key, or in forming relationships.  These can
          * be presumed to be exposed primary or foreign keys and handled 
          * accordingly when copying an object.
          *
          * @param source the EOEnterpriseObject to copy attribute values from
          * @return an array of attribute names from the EOEntity of source that
          * are used in forming relationships.
          *
          **/
        public static NSArray exposedKeyAttributeNames(EOEnterpriseObject source)
        {
            //** require [valid_source] source != null;      **/

            // These are cached on EOEntity name as an optimization.
            if (exposedKeyAttributeDictionary == null)
            {
                exposedKeyAttributeDictionary = new NSMutableDictionary();
            }

            EOEntity entity = EOUtilities.entityForObject(source.editingContext(), 
                                                          source);
            NSArray exposedKeyAttributeNames = (NSArray)
                exposedKeyAttributeDictionary.objectForKey(entity.name());

            if (exposedKeyAttributeNames == null)
            {
                copyLogger.debug("Checking " + entity.name() + " for exposed keys");
                NSMutableSet keyNames = new NSMutableSet();
                keyNames.addObjectsFromArray(entity.primaryKeyAttributeNames());
                
                Enumeration relationshipEnumerator = entity.relationships().
                    objectEnumerator();
                while (relationshipEnumerator.hasMoreElements())
                {
                    EORelationship relationship = (EORelationship)
                        relationshipEnumerator.nextElement();
                    keyNames.addObjectsFromArray((NSArray)relationship.
                        sourceAttributes().valueForKey("name"));
                }

                NSSet publicAttributeNames = new NSSet(source.attributeKeys());
                exposedKeyAttributeNames = publicAttributeNames.
                    setByIntersectingSet(keyNames).allObjects();
                copyLogger.debug("--> Attributes " + exposedKeyAttributeNames + 
                                                " are exposed, including...");
                exposedKeyAttributeDictionary.setObjectForKey(exposedKeyAttributeNames, 
                                                              entity.name());
            }

            return exposedKeyAttributeNames;
            
            //** ensure [valid_result] Result != null;  **/
        }



        /**
         * This copies related objects from the source EOEnterpriseObject to the 
         * destination by reference.  Only relationships which are class properties 
         * are copied.  It can be used when creating custom implementations of the 
         * duplicate() method in EOCopyable.  
         *
         * @param source the EOEnterpriseObject to copy attribute values from
         * @param destination the EOEnterpriseObject to copy attribute values to
         */
        public static void shallowCopyRelatedObjects(EOEnterpriseObject source, 
                                                     EOEnterpriseObject destination)
        {
            //** require [valid_source] source != null;
            //            [source_EOCopyable] source instanceof EOCopyable;
            //            [valid_destination] destination != null;
            //            [destination_EOCopyable] destination instanceof EOCopyable;
            // **/

            copyLogger.debug("Shallow copying relationships for  " +
                globalIDForObject(source));

            Enumeration relationshipEnumerator =  source.toManyRelationshipKeys().
                objectEnumerator();
            while (relationshipEnumerator.hasMoreElements())
            {
                String relationshipName = (String)relationshipEnumerator.nextElement();
                NSArray originalObjects = (NSArray)source.valueForKey(relationshipName);

                copyLogger.debug("Copying " + originalObjects.count() + 
                    " for relationship " + relationshipName);

                for (int i = 0, count = originalObjects.count(); i < count; i++)
                {
                    EOEnterpriseObject originalRelated =  (EOEnterpriseObject)
                        originalObjects.objectAtIndex(i);
                    destination.addObjectToBothSidesOfRelationshipWithKey(
                        referenceCopy(originalRelated), relationshipName);
                }
            }

            relationshipEnumerator = source.toOneRelationshipKeys().objectEnumerator();
            while (relationshipEnumerator.hasMoreElements())
            {
                String relationshipName = (String)relationshipEnumerator.nextElement();
                EOEnterpriseObject originalRelated = (EOEnterpriseObject)source.
                    valueForKey(relationshipName);
                if (originalRelated != null)
                {
                    copyLogger.debug("Copying object for relationship " + 
                        relationshipName);
                    destination.addObjectToBothSidesOfRelationshipWithKey(
                        referenceCopy(originalRelated), relationshipName);
                }
            }
        }



        /**
         * This copies related objects from the source EOEnterpriseObject to the
         * destination by calling deepCopyRelationship on them. It can be used 
         * when creating custom implementations of the duplicate() method in 
         * EOCopyable. Only relationships which are class properties are copied.    
         *
         * @param copiedObjects the copied objects keyed on the EOGlobalID of the 
         * object the copy was made from
         * @param source the EOEnterpriseObject to copy attribute values from
         * @param destination the EOEnterpriseObject to copy attribute values to
         */
        public static void deepCopyRelatedObjects(NSMutableDictionary copiedObjects,
                                                  EOEnterpriseObject source,
                                                  EOEnterpriseObject destination)
        {
            //** require [valid_source] source != null;
            //            [source_EOCopyable] source instanceof EOCopyable;
            //            [valid_destination] destination != null;
            //            [destination_EOCopyable] destination instanceof EOCopyable;
            //            [valid_copiedObjects] copiedObjects != null;    **/

            copyLogger.debug("Shallow copying relationships for  " +
                                     globalIDForObject(source));
            EOEntity entity = EOUtilities.entityForObject(source.editingContext(), 
                                                          source);

            Enumeration relationshipEnumerator = entity.relationships().
                objectEnumerator();
            while (relationshipEnumerator.hasMoreElements())
            {
                EORelationship relationship = (EORelationship) 
                    relationshipEnumerator.nextElement();
                if (entity.classProperties().containsObject(relationship))
                {
                    deepCopyRelationship(copiedObjects, source, destination, 
                                         relationship);
                }
            }
        }



        /**
         * This copies the object(s) for the named relationship from the source
         * EOEnterpriseObject to the destination by calling 
         * copy(NSMutableDictionary) on them.  Thus each related object will be 
         * copied by its own reference, shallow, deep, or custom 
         * duplicate(NSMutableDictionary) method.  It can be used when creating 
         * custom implementations of the duplicate() method in EOCopyable.  
         *
         * @param copiedObjects the copied objects keyed on the EOGlobalID of the
         * object the copy was made from
         * @param source the EOEnterpriseObject to copy attribute values from
         * @param destination the EOEnterpriseObject to copy attribute values to
         * @param relationship the EORelationship to copy
         */
        public static void deepCopyRelationship(NSMutableDictionary copiedObjects,
                                                EOEnterpriseObject source,
                                                EOEnterpriseObject destination,
                                                EORelationship relationship)
        {
            //** require 
            //    [valid_copiedObjects] copiedObjects != null;
            //    [valid_source] source != null;
            //    [source_EOCopyable] source instanceof EOCopyable;
            //    [valid_destination] destination != null;  
            //    [destination_EOCopyable] destination instanceof EOCopyable;
            //    [valid_relationship] relationship != null;  **/

            String relationshipName = relationship.name();
            if (relationship.isToMany())
            {
                 copyLogger.debug("Copying 2-M relationship " + relationshipName);
                 copyLogger.debug("        from " + globalIDForObject(source));

                NSArray originalObjects = (NSArray)source.valueForKey(relationshipName);
                NSArray destinationObjects = (NSArray)destination.valueForKey(
                    relationshipName);

                copyLogger.debug("Copying " + originalObjects.count() + 
                    " for relationship " + relationshipName);

                for (int i = 0, count = originalObjects.count(); i < count; i++)
                {
                    EOEnterpriseObject original =  
                        (EOEnterpriseObject)originalObjects.objectAtIndex(i);

                    EOEnterpriseObject originalCopy = ((EOCopyable)original).
                        copy(copiedObjects);

                    // This is a tricky part.  Making the copy in the previous 
                    //copiedObjects line can set the relationship that we are 
                    // about to set.  We need to check for this so that we do not 
                    // create duplicated relationships.
                    if ( ! destinationObjects.containsObject(originalCopy))
                    {
                        destination.addObjectToBothSidesOfRelationshipWithKey(
                            originalCopy, relationshipName);
                    }
                }
            }
            else
            {
                EOEnterpriseObject original = (EOEnterpriseObject)source.
                    valueForKey(relationshipName);
                copyLogger.debug("Copying 2-1 relationship " + relationshipName);
                copyLogger.debug("        from " + globalIDForObject(source));

                if (original != null)
                {
                    copyLogger.debug("Copying object for relationship " + 
                        relationshipName);
                    destination.addObjectToBothSidesOfRelationshipWithKey(
                        ((EOCopyable)original).copy(copiedObjects), 
                         relationshipName);
                }
            }
        }
         
            
        /**
         * Convenience method to get EOGlobalID from an EOEnterpriseObject.
         * 
         * @prarm the EOEnterpriseObject to return the EOGlobalID for
         * @return the EOGlobalID of the eo parameter
         */
         public static EOGlobalID globalIDForObject(EOEnterpriseObject eo)
         {
             return eo.editingContext().globalIDForObject(eo);
         }
    }
    
}
