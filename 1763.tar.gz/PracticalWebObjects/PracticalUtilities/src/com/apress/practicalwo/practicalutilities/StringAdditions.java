package com.apress.practicalwo.practicalutilities;

import java.math.BigDecimal;

import com.webobjects.foundation.*;


/**
 * String utilities.
 *
 * @author Chuck Hill and Sacha Mallais
 */
public class StringAdditions
{


    /**
     * Static methods only.  You'll never need to instantiate this class.
     */
    private StringAdditions()
    {
        super();
    }



    /**
     * Attempts to separate the key components of the given key path.  Right now, just uses the lame NSArray.componentsSeparatedByString, but if this ever doesn't cut it, this is the only method that need change.
     *
     * @param aString the key or key path to sepearate into components
     * @return <code>true</code> if <code>aString</code> has two or more components separated by periods
     */
    public static NSArray keyPathComponents(String aString)
    {
        /** require [valid_param] aString != null; **/
        return NSArray.componentsSeparatedByString(aString, ".");
        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Given a string determines if it is a key path (two or more parts seperated by periods).
     *
     * @param aString a string to test
     * @return <code>true</code> if <code>aString</code> has two or more components separated by periods
     */
    public static boolean isValidPropertyKeyPath(String aString)
    {
        /** require [valid_param] aString != null; **/

        return keyPathComponents(aString).count() > 1;
    }



    /**
     * Given a key path like object.object.attribute returns the "attribute" part.
     *
     * @param aString the keypath
     * @return the final component in a keypath
     */
    public static String propertyNameFromKeyPath(String aString)
    {
        /** require [valid_param] aString != null; [valid_keypath] isValidPropertyKeyPath(aString); **/

        return (String)keyPathComponents(aString).lastObject();

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Given a key path like object1.object2.attribute returns the "object1.object2" part.
     *
     * @param aString the keypath
     * @return everything in the keypath except the final component
     */
    public static String objectKeyPathFromKeyPath(String aString)
    {
        /** require [valid_param] aString != null; [valid_keypath] isValidPropertyKeyPath(aString); **/

        NSMutableArray components = new NSMutableArray(keyPathComponents(aString));
        components.removeLastObject();
        return components.componentsJoinedByString(".");

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Given a key path like object1.object2.attribute returns the "object1" part.
     *
     * @param aString the keypath
     * @return the first component of a key path
     */
    public static String rootKeyFromKeyPath(String aString)
     {
        /** require [valid_param] aString != null; [valid_keypath] isValidPropertyKeyPath(aString); **/

        NSMutableArray components = keyPathComponents(aString).mutableClone();
        return (String)components.objectAtIndex(0);

        /** ensure [valid_result] Result != null; **/
     }



    /**
     * Given a key path like object1.object2.attribute returns the "object2.attribute" part.
     *
     * @param aString the keypath
     * @return everything in the keypath except the first component
     */
    public static String removeRootKeyFromKeyPath(String aString)
    {
        /** require [valid_param] aString != null; [valid_keypath] isValidPropertyKeyPath(aString); **/

        NSMutableArray components = keyPathComponents(aString).mutableClone();
        components.removeObjectAtIndex(0);
        return components.componentsJoinedByString(".");

        /** ensure [valid_result] Result != null; **/
    }



    /**
      * Returns <code>true</code> if this string is null or the empty String (trim().length() == 0).
      *
      * @param aString the string to check
      * @return <code>true</code> if this string is null or the empty String (length() == 0)
      */
     public static boolean isEmpty(String aString)
     {
         return (aString == null) || (aString.trim().length() == 0);
     }



    /**
     * Returns <code>true</code> if this string matched the integer pattern: [whitespace][minussign]digits[whitespace] and <code>false</code> otherwise.  Note that, unlike a float, an integer cannot be preceded by a plus sign "+".  For more info on Integer literals, see section 3.10.1 of the Java Language Specification.
     *
     * @param aString the string to check
     * @return <code>true</code> if this string matched the integer pattern, <code>false</code> otherwise
     */
    public static boolean isInteger(String aString)
    {
        /** require [valid_param] aString != null; **/

        boolean isInteger = true;
        try
        {
            Integer.valueOf(aString.trim());
        }
        catch (NumberFormatException e)
        {
            isInteger = false;
        }
        return isInteger;
    }


    /**
     * Returns <code>true</code> if this string matched the float pattern: [whitespace][sign]digits[.digits]["e" digits][floating point suffix][whitespace] and <code>false</code> otherwise.  For more info on Floating point literals, see section 3.10.2 of the Java Language Specification.
     *
     * @param aString the string to check
     * @return <code>true</code> if this string matched the float pattern, <code>false</code> otherwise
     */
    public static boolean isFloat(String aString)
    {
        /** require [valid_param] aString != null; **/

        boolean isFloat = true;
        try
        {
            Float.valueOf(aString.trim());
        }
        catch (NumberFormatException e)
        {
            isFloat = false;
        }
        return isFloat;
    }


    /**
     * Returns <code>true</code> if this string is a number (optionally surrounded by whitespace), <code>false</code> otherwise.  This method is more restrictive than the above method, since this one will only return <code>true</code> if <code>aString</code> is actually a number as most humans would understand the term (in particular, no suffixes or base prefixes are allowed).
     *
     * @param aString the string to check
     * @return <code>true</code> if this string is a number, <code>false</code> otherwise
     */
    public static boolean isNumber(String aString)
    {
        /** require [valid_param] aString != null; **/

        boolean isNumber = true;
        try
        {
            new BigDecimal(aString.trim());
        }
        catch (NumberFormatException e)
        {
            isNumber = false;
        }
        // This is needed for a bug in JDK 1.3.1.x
        catch (StringIndexOutOfBoundsException emptyString)
        {
            isNumber = false;
        }

        return isNumber;
    }



    /**
     * Return <code>true</code> if all the characters in the string are digits or white space, <code>false</code> otherwise.  Unlike <code>isFloat</code> and <code>isInteger</code>, this method returns <code>true</code> on strings like " 12 45 78 " where whitespace exists between the digits.
     *
     * @param aString the string to check
     * @return <code>true</code> if all the characters in the string are digits or white space, <code>false</code> otherwise
     */
    public static boolean isDigits(String aString)
    {
        /** require [valid_param] aString != null; **/

        boolean isDigits = true;

        int i;
        int stringLength = aString.length();

        //traverse the characters of the string and return false once a character is not a digit or whitespace
        for (i = 0; i < stringLength; i++ )
        {
            if ( ! (Character.isDigit(aString.charAt(i)) || Character.isWhitespace(aString.charAt(i))))
            {
                isDigits = false;
                break;
            }
        }

        return isDigits;
    }



    /**
     * Returns <code>true</code> if <code>character</code> is a line break character.
     * 
     * @param character the character to check
     * @return <code>true</code> if <code>character</code> is a line break character
     */
    public static boolean isLineBreak(char character)
    {
        return (character == '\n') || (character == '\r');
    }



    /**
     * Returns <code>true</code> if <code>firstCharacter</code> and 
     * <code>secondCharacter</code> are not equal and are both a line break 
     * character.  This is useful when parsing files which have /n/r or /r/n
     * for a single line break.
     * 
     * @see #isLineBreak(char)
     * @param firstCharacter the first character in the line break sequence
     * @param secondCharacter the last character in the line break sequence
     * @return <code>true</code> if <code>firstCharacter</code> and 
     * <code>secondCharacter</code> form a single line break 
     */
    public static boolean isLineBreakContinuation(char firstCharacter, 
                                                  char secondCharacter)
    {
        return (firstCharacter != secondCharacter) && 
        ((firstCharacter == '\n') || (firstCharacter == '\r')) &&
        ((secondCharacter == '\n') || (secondCharacter == '\r'));
    }
    
    

    /**
     * Returns <code>true</code> if <code>anEmail</code> is of valid email format: "&lt;string&gt;@&lt;string&gt;.&lt;string&gt;" where &lt;string&gt; is not empty, <code>false</code> otherwise.
     *
     * @deprecated Use the method in EmailAddress in GVCMail instead.
     * @param anEmail the string to check
     * @return <code>true</code> if <code>anEmail</code> is of valid email format, <code>false</code> otherwise
     */
    public static boolean isValidEmailAddressFormat(String anEmail)
    {
        /** require [valid_param] anEmail != null; **/

        NSArray listItems = NSArray.componentsSeparatedByString(anEmail, "@");
        boolean hasAtSignInMiddle = (listItems.count() == 2) &&
            (((String)listItems.objectAtIndex(0)).length() > 0) &&
            (((String)listItems.objectAtIndex(1)).length() > 0);

        boolean hasValidDomain = false;
        if (hasAtSignInMiddle)
        {
            NSArray domainItems = NSArray.componentsSeparatedByString((String)listItems.objectAtIndex(1), ".");
            hasValidDomain = (domainItems.count() >= 2) &&
                (((String)domainItems.objectAtIndex(0)).length() > 0) &&
                (((String)domainItems.objectAtIndex(1)).length() > 0);
        }

        return hasAtSignInMiddle && hasValidDomain;
    }



}
