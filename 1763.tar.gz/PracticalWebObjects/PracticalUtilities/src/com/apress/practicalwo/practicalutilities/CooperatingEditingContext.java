package com.apress.practicalwo.practicalutilities;

import java.util.Enumeration;

import com.webobjects.eocontrol.EOEnterpriseObject;
import com.webobjects.eocontrol.EOGlobalID;
import com.webobjects.eocontrol.EOObjectStore;
import com.webobjects.foundation.NSMutableSet;
import com.webobjects.foundation.NSSet;


/**
 * CooperatingEditingContext extends EOEditingContext by notifying the Enterprise Objects that 
 * it manages regarding their insertion, deletion, and updating.  Enterprise Objects need
 * to implement the EOStateTransition interface in order to receive these notifications 
 * (described in that interface).  The EOGenericStateTransitionRecord class provides an empty 
 * implementation of that interface and is suitable for use as a superclass for other Enterprise 
 * Objects.<br>
 * <br>
 * These notifications are only sent when Enterprise Objects implementing the EOStateTransition 
 * interface are managed by instances of this class or sub-classes.  When they are managed by 
 * other editing contexts they will behave as ordinary Enterprise Objects.  Instances of this 
 * class are created as you would a regular editing context.
 *
 * @see com.webobjects.eocontrol.EOEditingContext
 * @see EOStateTransition
 * @see EOGenericStateTransitionRecord
 * @author Chuck Hill and Sacha Mallais
 */
public class CooperatingEditingContext extends SelfCleaningEditingContext
{
    private NSMutableSet objectsToBeInserted = new NSMutableSet();
    private NSMutableSet objectsToBeUpdated = new NSMutableSet();
    private NSMutableSet objectsToBeDeleted = new NSMutableSet();
    private NSMutableSet willBeDeletedObjects = new NSMutableSet();
    private NSMutableSet notifiedWillUpdateSet = new NSMutableSet();
    private EOEnterpriseObject objectBeingNotified;
    

    /**
     * Designated constuctor.  Creates a new EOEditingContext object with anObjectStore as 
     * its parent object store.
     *
     * @param anObjectStore parent object store
     */
    public CooperatingEditingContext(EOObjectStore anObjectStore)
    {
        super(anObjectStore);
        /** require [valid_object_store] anObjectStore != null;  **/
    }



    /**
     * Creates a new EOEditingContext object with the default parent object store as its 
     * parent object store.
     */
    public CooperatingEditingContext()
    {
        super();
    }



    /**
     * Overriden to record this object as inserted so that notifications can be sent.
     * This method, rather than insertObject(), is used so that parent editing
     * contexts will also get notified of objects inserted and saved into one of
     * their nested editing contexts.
     *
     * @param object the EOEnterpriseObject to be inserted into this editing context
     */
    protected void _insertObjectWithGlobalID(EOEnterpriseObject object, EOGlobalID eoglobalid)
    {
        /** require [valid_object] object != null;  **/

        objectsToBeInserted().addObject(object);
        super._insertObjectWithGlobalID(object, eoglobalid);

        /** ensure [in_objectsToBeInserted] objectsToBeInserted.containsObject(object);  **/
    }



    /**
     * Overriden to record this object as deleted so that notifications can be sent.  
     * The willDelete notification is sent from this method.
     *
     * @param object the EOEnterpriseObject to be deleted from this editing context
     */
    public void deleteObject(EOEnterpriseObject object)
    {
        /** require [valid_object] object != null;  **/

        if (objectGetsNotifications(object)
            && (!willBeDeletedObjects().containsObject(object)))
        {
            ((EOStateTransition) object).willDelete();
            willBeDeletedObjects().addObject(object);
        }

        objectsToBeDeleted().addObject(object);

        super.deleteObject(object);
        
        /** ensure [will_be_deleted_sent] ( ! objectGetsNotifications(object)) ||
                                            willBeDeletedObjects().containsObject(object);
         [in_objectsToBeDeleted] objectsToBeDeleted.containsObject(object);  **/
    }



    /**
     * Overriden to track objects which may be sent the willUpdate notification.
     * This is ignored if the object this is called for is objectBeingNotified().
     * If the object is already in notifiedWillUpdateSet() it is removed so that 
     * the notification will be sent again.
     *
     * @param object the EOEnterpriseObject that will be modified in this editing context
     */
    public void objectWillChange(Object object)
    {
        /** require [valid_object] object != null;  **/

        if (object != objectBeingNotified())
        {
            objectsToBeUpdated().addObject(object);
            notifiedWillUpdateSet().removeObject(object);
        }

        super.objectWillChange(object);
        /** ensure [valid_state] (object == objectBeingNotified()) || 
                                 (objectsToBeUpdated().containsObject(object) && 
                                  ! notifiedWillUpdateSet().containsObject(object));  **/

    }



    /**
     * Overriden to provide various notifications.  It is possible that objects which receive 
     * willDelete() will also recieve the willUpdate() notification.  Objects will only receive 
     * one of hasInserted, hasDeleted() or hasUpdated().  In other words, deleted or inserted 
     * objects will not receive hasUpdated().
     */
    public void saveChanges()
    {
        notifyWillUpdate();

        super.saveChanges();

        notifyHasDeleted();
        notifyHasInserted();
        notifyHasUpdated();

        resetLists();
    }



    /**
     * Overriden to keep the lists of modified objects in sync.
     */
    public void revert()
    {
        super.revert();

        resetLists();
    }



    /**
     * Reset the lists of inserted, updated etc. objects to be empty.  
     * Called at the end of saveChanges() and revert().
     */
    protected void resetLists()
    {
        objectsToBeInserted().removeAllObjects();
        objectsToBeUpdated().removeAllObjects();
        objectsToBeDeleted().removeAllObjects();
        willBeDeletedObjects().removeAllObjects();
        resetNotifiedWillUpdateSet();
    }



    /**
     * <p>Sends the willUpdate() notification to all modified objects.  Objects 
     * receiving this message may update other objects so this is done 
     * repeatedly until no more objects get updated and each updated object 
     * receives this message.  An object may recieve this message more than once 
     * if other objects being notified modify it.  The number of messages 
     * received depends on the order in which updated objects are processed.  
     * This is non-deterministic and must not be relied upon.  The willUpdate()
     * method should be written to handle multiple calls in a single save cycle.  
     * This class will prevent the willUpdate() method from producing 
     * notification cycles in the object being notified.</p>
     * 
     * <p>Newly inserted and deleted objects will also receive this message.  
     * This method is intended to be called in the context of saveChanges().  
     * Calling it at other times will result in the willUpdate() message being 
     * sent at potentially inappropriate times.  If the save fails, the message 
     * will be sent again if the save is attempted again.</p>
     * 
     * <p>This notification can be sent even if the object receiving it has not 
     * actually changed the values.  If this is a concern, you can determine if 
     * any values were actually changed by testing:</p>
     * <pre>
     * changesFromSnapshot(
     *     editingContext().committedSnapshotForObject(this)).count() > 0
     * </pre>
     */
    protected void notifyWillUpdate()
    {
        NSSet unNotifiedObjectsToBeUpdated = new NSSet(objectsToBeUpdated());
        resetNotifiedWillUpdateSet();
        
        while (unNotifiedObjectsToBeUpdated.count() > 0)
        {
            Enumeration objectsToBeUpdatedEnumerator =
                unNotifiedObjectsToBeUpdated.objectEnumerator();
            while (objectsToBeUpdatedEnumerator.hasMoreElements())
            {
                EOEnterpriseObject updatedObject = 
                    (EOEnterpriseObject)objectsToBeUpdatedEnumerator.nextElement();
                setObjectBeingNotified(updatedObject);
                if (objectGetsNotifications(updatedObject))
                {
                    ((EOStateTransition) updatedObject).willUpdate();
                }

                // Mark this object as notified, it may be removed from this set
                // by a later update.
                notifiedWillUpdateSet().addObject(updatedObject);
            }

            // Call process recent changes so that inserts and deletes are processed.  
            // This may result in more updated objects.
            processRecentChanges();

            unNotifiedObjectsToBeUpdated = objectsToBeUpdated().setBySubtractingSet(notifiedWillUpdateSet());
        }
        
        // Reset to avoid interfering with willChange()
        resetNotifiedWillUpdateSet();
        setObjectBeingNotified(null);
    }



    /**
     * Sends the hasDeleted() notification to all the objects which have just been removed from 
     * the persistent object store.
     */
    protected void notifyHasDeleted()
    {
        Enumeration objectsToBeDeletedEnumerator =
            objectsToBeDeleted().objectEnumerator();
        while (objectsToBeDeletedEnumerator.hasMoreElements())
        {
            Object deletedObject = objectsToBeDeletedEnumerator.nextElement();
            if (objectGetsNotifications((EOEnterpriseObject)deletedObject))
            {
                ((EOStateTransition) deletedObject).hasDeleted();
            }
        }
    }



    /**
     * Sends the hasInserted() notification to all the new objects which have just been saved 
     * to the persistent object store.
     */
    protected void notifyHasInserted()
    {
        Enumeration objectsToBeInsertedEnumerator =
            objectsToBeInserted().objectEnumerator();
        while (objectsToBeInsertedEnumerator.hasMoreElements())
        {
            Object insertedObject = objectsToBeInsertedEnumerator.nextElement();
            if (objectGetsNotifications((EOEnterpriseObject)insertedObject))
            {
                ((EOStateTransition) insertedObject).hasInserted();
            }
        }
    }



    /**
     * Sends the hasUpdated() notification to all the updated objects which have just been saved
     * to the persistent object store.  Note that this is not sent to objects which recieve 
     * hasInserted or hasDeleted().
     */
    public void notifyHasUpdated()
    {
        // Don't send this notification to objects which have just been inserted or deleted.
        NSMutableSet updatesOnly = objectsToBeUpdated().mutableClone();
        updatesOnly.subtractSet(objectsToBeDeleted());
        updatesOnly.subtractSet(objectsToBeInserted());

        Enumeration objectsToBeUpdatedEnumerator = updatesOnly.objectEnumerator();
        while (objectsToBeUpdatedEnumerator.hasMoreElements())
        {
            Object updatedObject = objectsToBeUpdatedEnumerator.nextElement();
            if (objectGetsNotifications((EOEnterpriseObject)updatedObject))
            {
                ((EOStateTransition) updatedObject).hasUpdated();
            }
        }
    }


    /**
     * Returns <code>true</code> if eo should get notifications from this CooperatingEditingContext
     * 
     * @param eo the EOEnterpriseObject to check
     * @return <code>true</code> if eo should get notifications from this CooperatingEditingContext
     */
    public boolean objectGetsNotifications(EOEnterpriseObject eo)
    {
        /** require [valid_eo] eo != null;  **/

        return eo instanceof EOStateTransition;
    }


    /**
     * Returns the list of objects inserted into this editing context.  These need to be notified 
     * of insertion once this editing context has saved changed to the external store.
     * 
     * @return the list of objects inserted into this editing context
     */
    protected NSMutableSet objectsToBeInserted()
    {
        return objectsToBeInserted;
    }
    
    
    
    /**
     * Returns the list of objects updated in this editing context.  These need to be notified 
     * prior to this editing context saving changes to the external store.  These objects
     * (excluding ones that were inserted or deleted) will also be notified after the save
     * finishes.
     * 
     * @return the list of objects updated in this editing context
     */
    protected NSMutableSet objectsToBeUpdated()
    {
        return objectsToBeUpdated;
    }

    

    /**
     * Returns the list of objects deleted from this editing context.  These need to be notified 
     * prior to this editing context saving changes to the external store.  These objects will 
     * also be notified after the save finishes.
     * 
     * @return the list of objects deleted from this editing context
     */
    protected NSMutableSet objectsToBeDeleted()
    {
        return objectsToBeDeleted;
    }
    


    /**
     * Returns the list of objects which have been notified prior to being deleted from 
     * this editing context.  
     * 
     * @return the list of objects deleted from this editing context
     */
    protected NSMutableSet willBeDeletedObjects()
    {
        return willBeDeletedObjects;
    }

    
    
    /**
     * Returns the set of objects already notified willUpdate in this save cycle.  Returns an empty
     * set if willUpdate notification is not in progress. 
     * 
     * @return the set of objects already notified willUpdate in this save cycle
     */
    protected NSMutableSet notifiedWillUpdateSet()
    {
        return notifiedWillUpdateSet;
        /** ensure [valid_result] Result != null;   **/
    }



    /**
     * Removes all objects from the set of objects already notified willUpdate in this save cycle
     */
   protected void resetNotifiedWillUpdateSet()
   {
       notifiedWillUpdateSet.removeAllObjects();
   }

    
    
   /**
    * Sets the eo object currently being sent the willUpdate notification.
    * 
    * @param eoObject  the eo object currently being sent the willUpdate notification
    */
   protected void setObjectBeingNotified(EOEnterpriseObject eoObject)
   {
       objectBeingNotified = eoObject;
   }
    
    
   /**
    * Returns the eo object currently being sent the willUpdate notification.  This is used to
    * prevent notification cycles if the eo calls willChange() while processing the notification.
    * 
    * @return the eo object currently being sent the willUpdate notification
    */
   protected EOEnterpriseObject objectBeingNotified()
   {
       return objectBeingNotified;
   }

    /** invariant [objectsToBeInserted_notnull] objectsToBeInserted() != null;
      [objectsToBeUpdated_notnull] objectsToBeUpdated() != null;
      [objectsToBeDeleted_notnull] objectsToBeDeleted() != null;
      [willBeDeletedObjects_notnull] willBeDeletedObjects() != null;  **/

}
