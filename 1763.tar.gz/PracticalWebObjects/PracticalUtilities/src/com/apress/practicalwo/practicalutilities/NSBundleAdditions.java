package com.apress.practicalwo.practicalutilities;

import java.util.Enumeration;

import com.webobjects.foundation.*;


/**
 * Convenience and bug fixes for NSBundle.
 *
 * @author Chuck Hill and Sacha Mallais
 */
public class NSBundleAdditions
{
    protected static final String StringsFileExtension = ".strings";


    /**
     * Static methods only.  You'll never need to instantiate this class.
     */
    private NSBundleAdditions()
    {
        super();
    }



    /**
     * Returns any bundle except for the given bundle.  This is used by the unit tests to return a bundle in which the test resources should not be found.
     *
     * @param exceptBundle the bundle that we shouldn't return
     * @return any bundle but the given bundle
     */
    public static NSBundle anyBundle(NSBundle exceptBundle)
    {
        /** require [valid_param] exceptBundle != null; **/

        Enumeration bundles = NSBundle.frameworkBundles().objectEnumerator();

        while (bundles.hasMoreElements())
        {
            NSBundle aBundle = (NSBundle)bundles.nextElement();
            if ( ! aBundle.equals(exceptBundle))
            {
                return aBundle;
            }
        }

        throw new RuntimeException("anyBundle() could not return a valid result - possibly there is only one bundle!");

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Returns the localized string table <code>tableName</code>, or <code>null</code> if the file could not be found.<p>
     *
     * This does not use <code>Collection.collectionWithContentsOfFile()</code> because the path returned by <code>resourcePathForLocalizedResourceNamed()</code> is not fully qualified (and there is no way to get the FQ name!).<p>
     *
     * Note: uses the <em>server's</em> locale for localization.  This is not appropriate for web apps.
     *
     * @param bundle the bundle in which to look for <code>tableName</code>.
     * @param tableName the string table for which to search.
     * @return a string table or <code>null</code>.
     */
    protected static NSDictionary findTableWithName(NSBundle bundle, String tableName)
    {
        /** require [valid_bundle_param] bundle != null; [valid_tableName_param] tableName != null; **/

        NSDictionary table = null;
        String tablePath = bundle.resourcePathForLocalizedResourceNamed(tableName, null);

        if (tablePath != null)
        {
            byte[] tableBytes = bundle.bytesForResourcePath(tablePath);
            String tableString = new String(tableBytes);

            // If the file is a .strings file, propertyListFromString() doesn't recongnize it without the "{" and "}"
            if (tableName.endsWith(StringsFileExtension))
            {
                tableString = "{" + tableString + "}";
            }

            // Since we are only using this to get .strings files and the CustomInfo.plist, this will always return a dictionary.
            table = (NSDictionary)NSPropertyListSerialization.propertyListFromString(tableString);
        }

        return table;
    }


    /**
     * Returns <code>true</code> if the string table <code>tableName</code> could be found, <code>false</code> otherwise.<p>
     *
     * Note: uses the <em>server's</em> locale for localization.  This is not appropriate for web apps.
     *
     * @param bundle the bundle in which to look for <code>tableName</code>.
     * @param tableName the string table.
     * @return <code>true</code> if the string table <code>tableName</code> could be found, <code>false</code> otherwise.
     */
    public static boolean tableExistsWithName(NSBundle bundle, String tableName)
    {
        /** require [valid_bundle_param] bundle != null; [valid_tableName_param] tableName != null; **/

        return findTableWithName(bundle, tableName) != null;
    }


    /**
     * Returns the string table <code>tableName</code>.<p>
     *
     * Note: uses the <em>server's</em> locale for localization.  This is not appropriate for web apps.
     *
     * @param bundle the bundle in which to look for <code>tableName</code>.
     * @param tableName the string table.
     * @return a string table
     */
    public static NSDictionary tableWithName(NSBundle bundle, String tableName)
    {
        /** require
        [valid_bundle_param] bundle != null;
        [valid_tableName_param] tableName != null;
        [table_exists] tableExistsWithName(bundle, tableName); **/

        return findTableWithName(bundle, tableName);
    }



    /**
     * Returns a localized version of <code>key</code> in table <code>&lt;tableName&gt;.strings</code>.<p>
     *
     * Note: uses the <em>server's</em> locale for localization.  This is not appropriate for web apps.
     *
     * @param bundle the bundle in which to look for the table.
     * @param key the string to localize.
     * @param tableName the string table to search.
     * @return a localized version of <code>key</code> or <code>null</code> if <code>key</code> could not be found.
     */
    protected static String findLocalizedStringForKey(NSBundle bundle, String key, String tableName)
    {
        /** require
        [valid_bundle_param] bundle != null;
        [valid_key_param] key != null;
        [valid_tableName_param] tableName != null; **/

        String mungedTableName = tableName + StringsFileExtension;
        String localizedString = null;
        if (tableExistsWithName(bundle, mungedTableName))
        {
            NSDictionary table = tableWithName(bundle, mungedTableName);
            localizedString = (String)table.objectForKey(key);
        }
        return localizedString;
    }


    /**
     * Returns <code>true</code> if a localized version of <code>key</code> exists in table <code>tableName</code>, <code>false</code> otherwise.<p>
     *
     * Note: uses the <em>server's</em> locale for localization.  This is not appropriate for web apps.
     *
     * @param bundle the bundle in which to look for the table.
     * @param key the string for which to search.
     * @param tableName the string table to search.
     * @return <code>true</code> if a localized version of <code>key</code> exists in table <code>tableName</code>, <code>false</code> otherwise.
     */
    public static boolean localizedStringExistsForKey(NSBundle bundle, String key, String tableName)
    {
        /** require
        [valid_bundle_param] bundle != null;
        [valid_key_param] key != null;
        [valid_tableName_param] tableName != null; **/

        return findLocalizedStringForKey(bundle, key, tableName) != null;
    }


    /**
     * Returns a localized version of <code>key</code> in table <code>tableName</code>.<p>
     *
     * Note: uses the <em>server's</em> locale for localization.  This is not appropriate for web apps.
     *
     * @param bundle the bundle in which to look for the table.
     * @param key the string to localize.
     * @param tableName the string table to search.
     * @return a localized version of <code>key</code>.
     */
    public static String localizedStringForKey(NSBundle bundle, String key, String tableName)
    {
        /** require
        [valid_bundle_param] bundle != null;
        [valid_key_param] key != null;
        [valid_tableName_param] tableName != null;
        [localized_string_exists] localizedStringExistsForKey(bundle, key, tableName); **/

        return findLocalizedStringForKey(bundle, key, tableName);

        /** ensure [valid_result] Result != null; **/
    }


    /**
     * Note: the semantics for this method are different than that of WO4.5!  See the description and contract for more info.<p>
     *
     * Returns a localized version of <code>key</code> in table <code>tableName</code>.<p>
     *
     * Note: uses the <em>server's</em> locale for localization.  This is not appropriate for web apps.
     *
     * @param bundle the bundle in which to look for the table.
     * @param key the string to localize.
     * @param defaultValue the value to return if the localized string for <code>key</code> can't be found in the table.
     * @param tableName the string table to search.
     * @return a localized version of <code>key</code>. If <code>key</code> could not be localized, returns <code>defaultValue</code>.
     */
    public static String localizedStringForKey(NSBundle bundle, String key, String defaultValue, String tableName)
    {
        /** require
        [valid_bundle_param] bundle != null;
        [valid_key_param] key != null;
        [valid_defaultValue_param] defaultValue != null;
        [valid_tableName_param] tableName != null; **/

        String rv;

        if (localizedStringExistsForKey(bundle, key, tableName))
        {
            rv = localizedStringForKey(bundle, key, tableName);
        }
        else
        {
            rv = defaultValue;
        }

        return rv;

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Replacement for the infoDictionary() method, which is now deprecated.  Looks for a file called <bundlename>.plist and returns the dictionary created from that file.
     *
     * @param bundle the bundle in which to look for the file.
     * @return the dictionary created from a file.  Returns an empty dictionary if the file does not exist.
     */
    public static NSDictionary infoDictionary(NSBundle bundle)
    {
        /** require [valid_param] bundle != null; **/

        NSDictionary theDictionary;

        // For compatability first try <bundle name>.plist
        if (NSBundleAdditions.tableExistsWithName(bundle, bundle.name() + ".plist"))
        {
            theDictionary = NSBundleAdditions.tableWithName(bundle, bundle.name() + ".plist");
        }
        // If that is not there try Info.plist which is more properly the WO5 successor to the info dictionary
        else if (NSBundleAdditions.tableExistsWithName(bundle, "Info.plist"))
        {
            theDictionary = NSBundleAdditions.tableWithName(bundle, "Info.plist");
        }
        else
        {
            theDictionary = new NSDictionary();
        }

        return theDictionary;

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Given a path to a framework, this converts it to a path to a java zip file in that framework (a java zip file may or may not exist in the framework - that makes no difference to this method).
     *
     * @param framworkPath the path that this will convert to point to the java zip
     * @return path to the Java classes that may (or may not) exist in the given framework
     */
    protected static String frameworkPathToJavaZipPath(String frameworkPath)
    {
        /** require [valid_param] frameworkPath != null; **/

        String stringTail = NSPathUtilities.lastPathComponent(frameworkPath);
        stringTail = NSPathUtilities.stringByDeletingPathExtension(stringTail);
        stringTail = stringTail.toLowerCase();
        stringTail = NSPathUtilities.stringByAppendingPathExtension(stringTail, "zip");

        String javaZipPath = NSPathUtilities.stringByAppendingPathComponent(frameworkPath, "Resources");
        javaZipPath = NSPathUtilities.stringByAppendingPathComponent(javaZipPath, "Java");
        javaZipPath = NSPathUtilities.stringByAppendingPathComponent(javaZipPath, stringTail);

        return javaZipPath;

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Fix a problem with <code>bundleForClass</code> which causes a call to a class in the main bundle to return null.  We catch that and return <code>mainBundle()</code> if so.
     *
     * @param aClass the class for which this returns the bundle
     * @return the bundle for the given class
     * @see com.apple.yellow.foundation.NSBundle#bundleForClass()
     */
    public static NSBundle bundleForClass(java.lang.Class aClass)
    {
        /** require [valid_param] aClass != null; **/

        if (NSBundle.bundleForClass(aClass) == null)
        {
            return NSBundle.mainBundle();
        }
        else
        {
            return NSBundle.bundleForClass(aClass);
        }

        /** ensure [valid_result] Result != null; **/
    }



}
