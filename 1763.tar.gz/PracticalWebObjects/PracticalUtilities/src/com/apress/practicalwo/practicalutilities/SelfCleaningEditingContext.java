package com.apress.practicalwo.practicalutilities;

import com.webobjects.eocontrol.EOObjectStore;



/**
 * This EOEditingContext subclass clears its undo stack afer a successful save.  This is used as a 
 * work around for a bug in EOF. This bug occurs when validateForDelete() fails to allow a deletion.
 * This will occur if you are using the Deny delete rule, the relationship is mandatory, or you have 
 * a custom validateForDelete() method.  The error only occurs in this scenario:<br>
 * 1. The editing context has multiple generations, meaning that saveChanges() has been called one or 
 *    more times after one or more EOs has been created / inserted / updated.<br>
 * 2. An EO is deleted from the editing context by deleteObject().<br>
 * 3. saveChanges() fails due to an NSValidation.ValidationException raised in validateForDelete.<br>
 * <br>
 * This result of this appears to be that undo() is called on the editing context's undo manager too
 * many times.  Instead of rolling back to the state when saveChanges() was called it rolls back past 
 * several of previous saveChanges()!  The result of this is that the editing context shows a historical
 * state that does not match the object store or the database.<br>
 * <br>
 * This class also reduces the memory footprint of editing contexts as there is no need for the undo 
 * stack after a successful save.
 * 
 * @author Chuck Hill and Sacha Mallais
 */
public class SelfCleaningEditingContext extends com.webobjects.eocontrol.EOEditingContext
{

    public SelfCleaningEditingContext(EOObjectStore anObjectStore)
    {
        super(anObjectStore);
    }


    public SelfCleaningEditingContext()
    {
        super();
    }
        public void saveChanges()
        {
            super.saveChanges();
            undoManager().removeAllActions();
        }

}
