/*
 * Created on 28-Jun-03
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.apress.practicalwo.practicalutilities.tests;

import java.util.Enumeration;

import junit.framework.TestCase;

import com.apress.practicalwo.practicalutilities.EOPrototypeSwitcher;
import com.apress.practicalwo.practicalutilities.EOTestSuite;
import com.webobjects.eoaccess.EOAttribute;
import com.webobjects.eoaccess.EOEntity;
import com.webobjects.eoaccess.EOModel;
import com.webobjects.eoaccess.EOModelGroup;
import com.webobjects.foundation.NSNotification;



public class EOPrototypeSwitcherTest extends TestCase
{
    protected String originalDatabaseType;
    protected String testDatabaseType;
    protected EOEntity testPrototypesEntity;
    protected EOEntity prototypesEntity;
    
    protected EOModel testModel;
    protected EOPrototypeSwitcher testSwitcher;


    public EOPrototypeSwitcherTest(String arg0)
    {
        super(arg0);
    }



    protected void setUp() throws Exception
    {
        super.setUp();

        testModel = EOModelGroup.defaultGroup().modelNamed("PracticalUtilitiesTestEOModel");

        // We will need this to reset things when we are done.  Creating a new suite
        // seems a tad dangerous but it is the lazy way to get the DB type.
        EOTestSuite dummySuite = new EOTestSuite("dummy");
        originalDatabaseType = dummySuite.databaseType();
        testDatabaseType = originalDatabaseType.equals("FrontBase") ?
            "OpenBase" : "FrontBase";
        testPrototypesEntity = EOModelGroup.defaultGroup().entityNamed("EO" + 
            testDatabaseType + "Prototypes");
        prototypesEntity = EOModelGroup.defaultGroup().entityNamed("EOJDBCPrototypes");
    }


    public void testDesignatedConstructor()
    {
        testSwitcher = new EOPrototypeSwitcher(testDatabaseType);
        
        
        Enumeration modelEnumerator = EOModelGroup.defaultGroup().models().objectEnumerator();
        while (modelEnumerator.hasMoreElements())
		{
            testSwitcher.updatePrototypes((EOModel) modelEnumerator.nextElement());
		}

        verifyPrototypesMatch();        
    }



    public void testNotificationHandler()
    {
        testSwitcher = new EOPrototypeSwitcher(testDatabaseType);
                                    
        Enumeration modelEnumerator = EOModelGroup.defaultGroup().models().objectEnumerator();
        while (modelEnumerator.hasMoreElements())
        {
            NSNotification testNotification = 
                new NSNotification(EOModelGroup.ModelAddedNotification, modelEnumerator.nextElement());

            // Can not do this there is already a prototype switcher created by the 
            // test suite and the result are unpredictable.
            //NSNotificationCenter.defaultCenter().postNotification(testNotification);            
            
            testSwitcher.handleModelAddedNotification(testNotification);
        }
        
        verifyPrototypesMatch();
    }



    public void verifyPrototypesMatch()
    {
        for (int i = 0; i < prototypesEntity.attributes().count(); i++)
        {
            EOAttribute jdbcPrototype = 
            (EOAttribute)prototypesEntity.attributes().objectAtIndex(i);
            String prototypesName = (String)jdbcPrototype.name();
            EOAttribute testPrototype = 
            (EOAttribute)testPrototypesEntity.attributeNamed(prototypesName);
            if (testPrototype != null)
            {
                assertEquals(jdbcPrototype.definition(), testPrototype.definition());
                assertEquals(jdbcPrototype.externalType(), testPrototype.externalType()); 
                assertEquals(jdbcPrototype.precision(), testPrototype.precision()); 
                assertEquals(jdbcPrototype.readFormat(), testPrototype.readFormat()); 
                assertEquals(jdbcPrototype.scale(), testPrototype.scale()); 
                assertEquals(jdbcPrototype.userInfo(), testPrototype.userInfo()); 
                assertEquals(jdbcPrototype.valueType(), testPrototype.valueType()); 
                assertEquals(jdbcPrototype.width(), testPrototype.width()); 
                assertEquals(jdbcPrototype.writeFormat(), testPrototype.writeFormat());
            }
        }
    }



    protected void tearDown() throws Exception
    {
        testSwitcher = new EOPrototypeSwitcher(originalDatabaseType);

        Enumeration modelEnumerator = EOModelGroup.defaultGroup().models().objectEnumerator();
        while (modelEnumerator.hasMoreElements())
        {
            testSwitcher.updatePrototypes((EOModel) modelEnumerator.nextElement());
        }
        super.tearDown();
    }

}
