package com.apress.practicalwo.practicalutilities.tests;


/**
 * EOEnterprise object used in testing of EOCopying / CopyableGenericRecord
 * Owned object copies deeply.
 */
public class OwnedObject extends _OwnedObject 
{

}
