package com.apress.practicalwo.practicalutilities;

import java.util.Enumeration;

import com.webobjects.appserver.*;
import com.webobjects.eoaccess.*;
import com.webobjects.eocontrol.*;
import com.webobjects.foundation.*;


/**
 * ValidatingPage should be used for any pages that allow the user to
 * create or edit enterprise object.  It was written to control a single
 * entity.  If the page is altering multiple entities, it will likely not
 * be suitable.<br>
 * ValidatingPage uses the EOFValidation framework to produce localized
 * exception messages for any exceptions raised, either at the UI (e.g.
 * formatter failures) or EOF layer (e.g. EOModel constraint violations.
 * <br><br><br>
 *
 * <b>How to Use ValidatingPage</b><br>
 * 1. Change the header file for the page to inherit from <code>ValidatingPage()</code>
 *    instead of <code>WOComponent</code><br>
 * 2. Override <code>pageToProceedToAfterSave()<code><br>
 * 3. Use <code>editingContext()</code> NOT <code>session().defaultEditingContext()</code><br>
 * 4. Add <code>privateCopyOfObject(theObject)</code> to all methods that take
 *    an Enterprise Object parameter and which may be called from outside this object.<br>
 * 5. Add <code>publicCopyOfObject(((WOSession) session()).defaultEditingContext(), theObject)</code>
 *    to all methods that pass an Enterprise Object to another page.<br>
 * 7. Call <code>attemptSave()</code> to save any changes and return the
 *    result as the next page to show.<br>
 * 8. Add components to your page to show the contents of errors if <code>hasErrors()</code>
 *    is <code>true</code>.<br>
 * 9. Optionally override <code>willSubclassHandleException()</code> and call
 *    <code>addError()<code> if you need special handling of certain exceptions.
 *    This is usually not needed.<br>
 * 
 * NB: You will need to lock and unlock the EditingContext manually.
 *
 * @author Chuck Hill and Sacha Mallais
 */
public class ValidatingPage extends WOComponent
{
    protected static String InvalidDateStringReason = "Format.parseObject(String) failed";
    protected static String InvalidNumberStringReason = "not a valid character for a number with a pattern";
    protected static String InvalidNumberNotIntegerStringReason = "is not an integer value, and this number formatter does not accept floating point values";

    protected EOEditingContext privateEditingContext;
    protected NSMutableArray _errors;


    /**
     * Designated constructor.
     */
    public ValidatingPage(WOContext aContext)
    {
        super(aContext);

        // Don't use the setters so that the invariant works...
        privateEditingContext = new ValidatingEditingContext();
        privateEditingContext.setStopsValidationAfterFirstError(false);
        privateEditingContext.setDelegate(this);
        _errors = new NSMutableArray();
    }



    /**
     * Sets the editing context to use for this page.  This should only be called in exceptional circumstances, usually the one created by the page is sufficient.  <em>Warning:</em>  replaces, without checking, the delegate for this editing context.
     *
     * @param editingContext the editing context to be set
     */
    public void setEditingContext(EOEditingContext editingContext)
    {
        /** require [valid_param] editingContext != null; **/

        if (privateEditingContext != editingContext)
        {
            privateEditingContext = editingContext;
            privateEditingContext.setStopsValidationAfterFirstError(false); // Allow aggregating of exceptions
            privateEditingContext.setDelegate(this);
        }

        /** ensure
        [has_private_editing_context] privateEditingContext != null;
        [this_is_delegate_of_private_editing_context] privateEditingContext.delegate().equals(this);
        [private_editing_context_continues_validation_after_first_error] privateEditingContext.stopsValidationAfterFirstError() == false; **/
    }



    /**
     * Returns the editing context to be used with objects on this page.  Do not use session().defaultEditingContext() with this page!
     *
     * @return the editing context to be used with objects in this page.
     */
    public EOEditingContext editingContext()
    {
        return privateEditingContext;

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Subclasses should override this if they want some say in how an exception is handled.  The subclass  should return YES if it handled the exception.  If a subclass handles an exception, it is responsible for calling addError: if it wants a message displayed.  This allows the subclass to veto an exception, alter the exception reported, or simple take special actions for certain exceptions.
     */
    public boolean willSubclassHandleException(Throwable anException)
    {
        return false;
    } 



    /**
     * Adds the message to the list of errors.  Subclasses can call this if they need to add a validation error message.
     *
     * @param anErrorMessage the String to be added to the list of errors
     */
    public void addError(String anErrorMessage)
    {
        /** require [valid_param] anErrorMessage != null; **/

        // Errors detected during <code>takeValuesFromRequest()</code> can duplicate errors from validateForSave.  The easiest way to deal with ths is to not add the message if it is already there.
        if ( ! (_errors.containsObject(anErrorMessage)))
        {
            _errors.addObject(anErrorMessage);
        }

        /** ensure [has_errors] hasErrors(); **/
    }



    /**
     * Adds the reason from the exception to the list of errors if willSubclassHandleException: returns false.  Also handles the exception being an NSValidation.ValidationException with additionalExceptions().
     *
     * @param anException the exception to be added to the list of errors
     */
    public void addError(Throwable anException)
    {
        /** require [valid_param] anException != null; **/

        if ( ! willSubclassHandleException(anException))
        {
            // Find the additional exceptions, if any
            NSArray additionalExceptions = null;
            if (anException instanceof com.webobjects.foundation.NSValidation.ValidationException)
            {
                additionalExceptions = ((com.webobjects.foundation.NSValidation.ValidationException)anException).additionalExceptions();
            }

            // Unwrap the exceptions and start again if there are additional exceptions.
            if ((additionalExceptions != null) && (additionalExceptions.count() > 0))
            {
                addError(additionalExceptions);
            }

            String localizedMessage;
            if (anException instanceof EOFValidationException)
            {
                EOFValidationException validationException = (EOFValidationException)anException;
                localizedMessage = anException.getLocalizedMessage();
            }
            else
            {
                // It is not one of our exceptions, so there is not much we can do.
                localizedMessage = anException.getMessage();
            }
            addError(localizedMessage);
        }

        /** ensure [has_errors] hasErrors(); **/
    }



    /**
     * Calls addErrorFromException: once for every element of the passed array.
     *
     * @param someExceptions the array of exceptions to be added to the list of errors
     */
    public void addError(NSArray someExceptions)
    {
        /** require [valid_param] someExceptions != null; **/

        Enumeration exceptionEnumerator = someExceptions.objectEnumerator();
        while (exceptionEnumerator.hasMoreElements())
        {
            Throwable thisException = (Throwable)exceptionEnumerator.nextElement();
            addError(thisException);
        }

        /** ensure [has_errors] hasErrors(); **/
    }



    /**
     * Returns true if errors have been detected.
     *
     * @return true if errors have been detected, false otherwise
     */
    public boolean hasErrors()
    {
        return _errors.count() > 0;
    }



    /**
     * Removes all errors from the list of errors.
     */
    public void clearErrors()
    {
        _errors.removeAllObjects();
        /** ensure [has_no_errors] ! hasErrors(); **/
    }



    /**
     * Returns any error messages occured during <code>takeValuesFromRequest()</code>, attemptSave: or from optimistic locking failures.
     *
     * @return an array of error messages
     */
    public NSArray errors()
    {
        return _errors;
        /** ensure [valid_result] Result != null; **/
    }



    /**
     * This method actually does the save, but does not handle any exceptions that arise.  Sub-classes can override this if extra processing is needed, but they should not trap any exceptions.  Generally, sub-classes should be overriding attemptSave and not this method.
     */
    public void doSave()
    {
        if ( ! hasErrors())
        {
            editingContext().saveChanges();
        }
    }



    /**
     * Subclasses must call this method to save any changes they have made.
     * If there are no validation or optimistic locking problems, attempts to save the changes in the editing context by calling doSave.  If there were errors either before or during the save, returns nil to indicate the save failed (and so the page will be shown to the user again).  If the save succeeded, calls pageToProceedToAfterSave to determine which page to show next.
     *
     * @return if the save was successful, the page returned by <code>pageToProceedToAfterSave()</code>, this page otherwise
     */
    public com.webobjects.appserver.WOComponent attemptSave()
    {
        try
        {
            doSave();
        }
        catch (Throwable t) //for other exceptions
        {
            addError(t);
        }

        return hasErrors() ? context().page() : pageToProceedToAfterSave();
    }



    /**
     * Subclasses override this to return an already set up page to be displayed after a successful save.  Default implementation returns null, which causes a postcondition exception.
     *
     * @return the WOComponent to be displayed after a successful save
     */
    public com.webobjects.appserver.WOComponent pageToProceedToAfterSave()
    {
        return null;
        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Subclasses can call this to "reset" the page: the editing context is reverted and any errors are cleared.  No other actions are taken: guarded objects remain guarded etc.
     *
     * @return the WOComponent to be displayed after reset is called
     */
    public WOComponent resetPage()
    {
        clearErrors();
        editingContext().revert();

        return (WOComponent) context().page();

        /** ensure
        [has_no_errors] ! hasErrors();
        [editing_context_has_no_changes] ! editingContext().hasChanges(); **/
    }



    /**
     * Convenience method useful when working with pages which have their own editing context.  Given an object in an unknown editing context, this method ensures that it exists in this page's privateEditingContext.  This should be used in all set... methods and anywhere else that an object is taken from outside this page.
     *
     * @param someObject the object
     * @return the private copy of someObject
     */
    public Object privateCopyOfObject(Object someObject)
    {
        /** require [valid_param] someObject != null; **/

        return EOUtilities.localInstanceOfObject(editingContext(), (EOEnterpriseObject) someObject);

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Convenience method useful when working with pages which have their own editing context.  Given an object in the page's editing context, returns the object in <code>anotherEditingContext</code>.  This should be used in all methods that set an object in another object (outside this page) e.g. when passing an object from this page to another page.<br>
     *
     * @param anotherEditingContext the editing context to put <code>someObject</code> into
     * @param someObject the object
     * @return the public copy of someObject
     */
    public Object publicCopyOfObject(EOEditingContext anotherEditingContext, EOEnterpriseObject someObject)
    {
        /** require
        [valid_anotherEditingContext_param] anotherEditingContext != null;
        [valid_someObject_param] someObject != null; **/

        return EOUtilities.localInstanceOfObject(anotherEditingContext, someObject);

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * This is the start of the takeValuesFromRequest phase.  It clears any errors accumulated from the last request-response cycle.  If there are any validation errors, the next method that will get called is validationFailedWithException:value:keyPath:<br>
     * To handle this will also need to over ride invoke action and add a flag to clearErrors there if not already done.
     */
    public void takeValuesFromRequest(WORequest aRequest, WOContext aContext)
    {
        clearErrors();
        super.takeValuesFromRequest(aRequest, aContext);
    }



    /**
     * Returns <code>true</code> if the exception is a formatter failure, <code>false</code> otherwise.
     *
     * @param exception the exception to examine
     * @return <code>true</code> if the exception is a formatter failure, <code>false</code> otherwise
     */
    public boolean isFormatterFailure(java.lang.Throwable exception)
    {
        /** require [valid_param] exception != null; **/

        return ((exception.getMessage().indexOf(InvalidDateStringReason) != -1) ||
                (exception.getMessage().indexOf(InvalidNumberStringReason) != -1) ||
                (exception.getMessage().indexOf(InvalidNumberNotIntegerStringReason) != -1));
    }



    /**
     * This method is called during the take values phase. As each value is taken from the request, any validation exceptions, formatter failures etc. are sent here. This is the best place to catch these as both the old and new values are available here. Also, WebObjects will leave the old value unchanged when a formatter fails, but will overwrite the old value when a validateAttribute method returns an exception.
     *
     * @param exception the exception raised
     * @param value the object that raised the exception
     * @param keyPath the keyPath of the exception ?
     */
    public void validationFailedWithException(java.lang.Throwable exception, java.lang.Object value, java.lang.String keyPath)
    {
        /** require
        [valid_exception_param] exception != null;
        [valid_keyPath_param] keyPath != null;
        [is_valid_validation_error] ( ! isFormatterFailure(exception)) || (EOObject.isKeyPathToAttribute(this, keyPath)); **/

        if (isFormatterFailure(exception))
        {
            // Exceptions from formatter failures are not created by the Validation framework and do not have the customized exception messages.  Look up the correct message and use that.
            EOAttribute attribute = EOObject.attributeFromKeyPath(this, keyPath);
            EOFValidationException formattedException = new EOFValidationException(attribute, EOFValidation.InvalidValue, value);

            addError(formattedException);
        }
        else
        {
            addError(exception);
        }
    }



    
    /**
     * Work-around for intermittent crashing problem.  Somehow, the editingContext() of some pages inheriting from ValidatingPage is not being freed even if the page is already freed. When a notification is sent to this editingContext(), it still has a reference to its delegate which is the freed page, thus, delegate should be set to null when finalize() is called to avoid this problem.
     */
    protected void finalize() throws Throwable
    {
        editingContext().setDelegate(null);
        super.finalize();
    }



    /** invariant
    [has_editing_context] editingContext() != null;
    [has_errors_array] errors() != null; **/



}
