package com.apress.practicalwo.practicalutilities.tests;

import com.apress.practicalwo.practicalutilities.*;

import com.webobjects.eocontrol.EOClassDescription;


/**
 * Tests for EOFValidation class
 *
 * @author Copyright (c) 2001-2  Global Village Consulting, Inc.  All rights reserved.
 * @version $Revision: 2$
 */
public class EOFValidationTest extends EOTestCase
{


    /**
     * Designated constuctor.
     */
    public EOFValidationTest(String name)
    {
        super(name);
    }



    /**
     * Tests whether empty strings are correctly handled as nulls.
     */
    public void testShouldTreatEmptyStringsAsNullDoesNotAffectTrueNulls()
    {
        EOClassDescription description = EOClassDescription.classDescriptionForEntityName("AttributeValidationTestEntity");
        AttributeValidationTestEntity testEntity = new AttributeValidationTestEntity();

        editingContext().insertObject(testEntity);

        try
        {
            EOFValidation.setShouldTreatEmptyStringsAsNull(false);
            editingContext().saveChanges();
        }
        catch (EOFValidationException e)
        {
            assertTrue(e.doesFailureExist("requiredString", EOFValidation.NullNotAllowed));
        }

        try
        {
            EOFValidation.setShouldTreatEmptyStringsAsNull(true);
            editingContext().saveChanges();
        }
        catch (EOFValidationException e)
        {
            assertTrue(e.doesFailureExist("requiredString", EOFValidation.NullNotAllowed));
        }
    }



    /**
     * Tests whether true empty strings are correctly handled as nulls.
     */
    public void testShouldTreatEmptyStringsWithEmptyStrings()
    {
        EOClassDescription description = EOClassDescription.classDescriptionForEntityName("SimpleAttributeTestEntity");
        AttributeValidationTestEntity testEntity = new AttributeValidationTestEntity();
        testEntity.setRequiredString("");
        
        editingContext().insertObject(testEntity);

        try
        {
            EOFValidation.setShouldTreatEmptyStringsAsNull(false);
            editingContext().saveChanges();
        }
        catch (EOFValidationException e)
        {
            assertTrue( ! e.doesFailureExist("requiredString", EOFValidation.NullNotAllowed));
        }

        try
        {
            EOFValidation.setShouldTreatEmptyStringsAsNull(true);
            editingContext().saveChanges();
        }
        catch (EOFValidationException e)
        {
            assertTrue(e.doesFailureExist("requiredString", EOFValidation.NullNotAllowed));
        }
    }



    /**
     * Tests whether white space strings are correctly handled as nulls.
     */
    public void testShouldTreatEmptyStringsAsNullWithWhiteSpace()
    {
        EOClassDescription description = EOClassDescription.classDescriptionForEntityName("SimpleAttributeTestEntity");
        AttributeValidationTestEntity testEntity = new AttributeValidationTestEntity();
        testEntity.setRequiredString("\r\n\t  \t");

        editingContext().insertObject(testEntity);

        try
        {
            EOFValidation.setShouldTreatEmptyStringsAsNull(false);
            editingContext().saveChanges();
        }
        catch (EOFValidationException e)
        {
            assertTrue( ! e.doesFailureExist("requiredString", EOFValidation.NullNotAllowed));
        }

        try
        {
            EOFValidation.setShouldTreatEmptyStringsAsNull(true);
            editingContext().saveChanges();
        }
        catch (EOFValidationException e)
        {
            assertTrue(e.doesFailureExist("requiredString", EOFValidation.NullNotAllowed));
        }
    }



}
