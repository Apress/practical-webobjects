
package com.apress.practicalwo.practicalutilities.tests;




/**
 * Describe class here.
 *
 * @author Copyright (c) 2000-2  Global Village Consulting, Inc.  All rights reserved.
 * @version $Revision: 2$
 */  
public class ToOneEntity extends _ToOneEntity
{

}
