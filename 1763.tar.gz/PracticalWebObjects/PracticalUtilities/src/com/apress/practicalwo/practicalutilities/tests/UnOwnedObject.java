package com.apress.practicalwo.practicalutilities.tests;

import com.webobjects.eocontrol.EOEnterpriseObject;
import com.webobjects.foundation.NSMutableDictionary;

import com.apress.practicalwo.practicalutilities.EOCopyable;

/**
 * EOEnterprise object used in testing of EOCopying / CopyableGenericRecord
 * Unowned object copied by reference like a lookup list would.
 *
 * @author Global Village Consulting, Inc.  Copyright 2001-2003 All Rights Reserved.
 */
public class UnOwnedObject extends _UnOwnedObject
{

    public EOEnterpriseObject duplicate(NSMutableDictionary copiedObjects)
    {
        return EOCopyable.Utility.referenceCopy(this);
    }


}
