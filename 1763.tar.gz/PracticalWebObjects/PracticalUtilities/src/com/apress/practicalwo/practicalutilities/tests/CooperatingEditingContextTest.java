
package com.apress.practicalwo.practicalutilities.tests;

import com.apress.practicalwo.practicalutilities.CooperatingEditingContext;
import com.apress.practicalwo.practicalutilities.EOTestCase;
import com.webobjects.eoaccess.EOUtilities;
import com.webobjects.eocontrol.EOEditingContext;


public class CooperatingEditingContextTest extends EOTestCase
{
    CooperatingEditingContextTestObject testObject;


    public CooperatingEditingContextTest(String name)
    {
        super(name);
    }



    public void setUp() throws java.lang.Exception
    {
        super.setUp();
        // Make sure all tests use our fancy new editing context subclass...
        setEditingContext(new CooperatingEditingContext());

        testObject = new CooperatingEditingContextTestObject();
        editingContext().insertObject(testObject);
        testObject.setStringValue("original value");
    }



    public void testInsertNotifications()
    {
        editingContext().saveChanges();
        assertEquals(1, testObject.calledHasInserted);
    }



    public void testDeleteNotifications()
    {
        // Make the test object permanent first.
        editingContext().saveChanges();
        
        editingContext().deleteObject(testObject);
        assertEquals(1, testObject.calledWillDelete);

        // Test redundant call
        editingContext().deleteObject(testObject);
        assertEquals(1, testObject.calledWillDelete);

        editingContext().saveChanges();
        assertEquals(1, testObject.calledWillDelete);
        assertEquals(1, testObject.calledHasDeleted);
    }



    /**
     * Test willUpdate propogated correctly
     */
    public void testwillUpdateNotifications()
    {
        editingContext().saveChanges();
        testObject.setStringValue("test");
        editingContext().processRecentChanges();
        assertEquals(1, testObject.calledWillUpdate);
        assertEquals(0, testObject.calledHasUpdated);

        testObject.resetCounters();
        editingContext().saveChanges();
        assertEquals(1, testObject.calledWillUpdate);
        assertEquals(1, testObject.calledHasUpdated);
        
        // Set up a related object so that we can test additional objects getting 
        // updated via willUpdate().
        CooperatingEditingContextTestObject relatedObject = 
            new CooperatingEditingContextTestObject();
        editingContext().insertObject(relatedObject);
        relatedObject.setStringValue("related");
        testObject.setRelatedObject(relatedObject);
        editingContext().saveChanges();

        // Needed as willUpdate on testObject will change this and interefere
        // with the test below.
        relatedObject.setStringValue("related");
        editingContext().saveChanges();

        // Needed for the next tests
        testObject.resetCounters();
        relatedObject.resetCounters();

        testObject.setStringValue("willUpdate test");
        editingContext().saveChanges();

        assertEquals(1, testObject.calledWillUpdate);   
        assertEquals(1, testObject.calledHasUpdated);
        assertEquals(1, relatedObject.calledWillUpdate);
        assertEquals(1, relatedObject.calledHasUpdated);
    }



    /**
     * Test EOEditingContext nested in a CooperatingEditingContext
     * works correctly
     */
    public void testNesting()
    {
        // We don't want the partially constructed object.
        editingContext().revert();
        
        // Setup of nesting
        EOEditingContext nestedEC = new EOEditingContext(editingContext());
        CooperatingEditingContextTestObject nestedObject = new CooperatingEditingContextTestObject();
        nestedEC.insertObject(nestedObject);
        nestedObject.setStringValue("nested value");
  
        // Test insertion notifications  
        nestedEC.saveChanges();
        assertEquals(0, nestedObject.calledHasInserted);

        // Now that the child has saved we can get a reference to the equivalent 
        // object in the parent.
        CooperatingEditingContextTestObject parentObject = 
            (CooperatingEditingContextTestObject)
            EOUtilities.localInstanceOfObject(editingContext(), nestedObject);

        editingContext().saveChanges();
        assertEquals(1, parentObject.calledHasInserted);

        // Reset for next test
        nestedObject.resetCounters();
        parentObject.resetCounters();
        
        // Test update notifications  
        nestedObject.setStringValue("new nested value");
        nestedEC.saveChanges();
        assertEquals(0, nestedObject.calledWillUpdate);
        assertEquals(0, nestedObject.calledHasUpdated);
        assertEquals(0, parentObject.calledWillUpdate);
        assertEquals(0, parentObject.calledHasUpdated);

        editingContext().saveChanges();
        assertEquals(0, nestedObject.calledWillUpdate);
        assertEquals(0, nestedObject.calledHasUpdated);
        assertEquals(1, parentObject.calledWillUpdate);
        assertEquals(1, parentObject.calledHasUpdated);

        // Reset for next test
        nestedObject.resetCounters();
        parentObject.resetCounters();
        
        
        // Test delete notifications  
        nestedEC.deleteObject(nestedObject);
        assertEquals(0, nestedObject.calledWillDelete);
        assertEquals(0, parentObject.calledWillDelete);

        nestedEC.saveChanges();
        assertEquals(0, nestedObject.calledWillDelete);
        assertEquals(0, nestedObject.calledHasDeleted);
        assertEquals(1, parentObject.calledWillDelete);
        assertEquals(0, parentObject.calledHasDeleted);

        editingContext().saveChanges();
        assertEquals(0, nestedObject.calledWillDelete);
        assertEquals(0, nestedObject.calledHasDeleted);
        assertEquals(1, parentObject.calledWillDelete);
        assertEquals(1, parentObject.calledHasDeleted);
    }




    /**
     * Test CooperatingEditingContext nested in a CooperatingEditingContext
     * works correctly
     */
    public void testDoubleNesting()
    {
        // We don't want the partiall constructed object.
        editingContext().revert();
        
        // Setup of nesting
        EOEditingContext nestedEC = new CooperatingEditingContext(editingContext());
        CooperatingEditingContextTestObject nestedObject = new CooperatingEditingContextTestObject();
        nestedEC.insertObject(nestedObject);
        nestedObject.setStringValue("nested value");
  
        // Test insertion notifications  
        nestedEC.saveChanges();
        assertEquals(1, nestedObject.calledHasInserted);

        // Now that the child has saved we can get a reference to the equivalent 
        // object in the parent.
        CooperatingEditingContextTestObject parentObject = 
            (CooperatingEditingContextTestObject)
            EOUtilities.localInstanceOfObject(editingContext(), nestedObject);

        editingContext().saveChanges();
        assertEquals(1, parentObject.calledHasInserted);

        // Reset for next test
        nestedObject.resetCounters();
        parentObject.resetCounters();
        
        // Test update notifications  
        nestedObject.setStringValue("new nested value");
        nestedEC.saveChanges();
        assertEquals(1, nestedObject.calledWillUpdate);
        assertEquals(1, nestedObject.calledHasUpdated);
        assertEquals(0, parentObject.calledWillUpdate);
        assertEquals(0, parentObject.calledHasUpdated);

        editingContext().saveChanges();
        assertEquals(1, nestedObject.calledWillUpdate);
        assertEquals(1, nestedObject.calledHasUpdated);
        assertEquals(1, parentObject.calledWillUpdate);
        assertEquals(1, parentObject.calledHasUpdated);

        // Reset for next test
        nestedObject.resetCounters();
        parentObject.resetCounters();
        
        
        // Test delete notifications  
        nestedEC.deleteObject(nestedObject);
        assertEquals(1, nestedObject.calledWillDelete);
        assertEquals(0, parentObject.calledWillDelete);

        nestedEC.saveChanges();
        assertEquals(1, nestedObject.calledWillDelete);
        assertEquals(1, nestedObject.calledHasDeleted);
        assertEquals(1, parentObject.calledWillDelete);
        assertEquals(0, parentObject.calledHasDeleted);

        editingContext().saveChanges();
        assertEquals(1, nestedObject.calledWillDelete);
        assertEquals(1, nestedObject.calledHasDeleted);
        assertEquals(1, parentObject.calledWillDelete);
        assertEquals(1, parentObject.calledHasDeleted);
    }



    public void tearDown() throws java.lang.Exception
    {
        if (testObject.editingContext() !=  null)
        {
            editingContext().deleteObject(testObject);
        }
        editingContext().saveChanges();
        super.tearDown();
    }



}
