/*
 * Created on 28-Jun-03
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.apress.practicalwo.practicalutilities.tests;

import junit.framework.TestCase;

import com.apress.practicalwo.practicalutilities.EOModelConnector;
import com.webobjects.eoaccess.EOModel;
import com.webobjects.eoaccess.EOModelGroup;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSDictionary;
import com.webobjects.foundation.NSNotification;



public class EOModelConnectorTest extends TestCase
{
    protected NSDictionary originalConnectionInfo;
    protected String originalAdaptorName;
    protected EOModel testModel;
    protected EOModelConnector testConnector;

	public EOModelConnectorTest(String arg0)
	{
		super(arg0);
	}



	protected void setUp() throws Exception
	{
		super.setUp();

        testModel = EOModelGroup.defaultGroup().modelNamed("PracticalUtilitiesTestEOModel");

        // We will need this to reset things when we are done.
        originalConnectionInfo = testModel.connectionDictionary();
        originalAdaptorName = testModel.adaptorName();
	}


    public void testDesignatedConstructor()
    {
        NSDictionary testDictionary = new NSDictionary("DummyObject", "DummyKey");
        testConnector = new EOModelConnector(testDictionary, 
                                              "JDBC",
                                              new NSArray("Dummy"));
        testConnector.connectModel(testModel);
        assertTrue(testModel.connectionDictionary().equals(testDictionary));
        assertTrue(testModel.adaptorName().equals("JDBC"));
    }



    public void testJDBCConstructor()
    {
        NSDictionary testDictionary = new NSDictionary("DummyObject", "DummyKey");
        testConnector = new EOModelConnector(testDictionary, new NSArray("Dummy"));
        testConnector.connectModel(testModel);
        
        assertTrue(testModel.connectionDictionary().equals(testDictionary));
        assertTrue(testModel.adaptorName().equals("JDBC"));
    }
    
    

    public void testIgnoredModelsIgnored()
    {
        NSDictionary testDictionary = new NSDictionary("DummyObject", "DummyKey");
        testConnector = new EOModelConnector(testDictionary, new NSArray(testModel.name()));
        testConnector.connectModel(testModel);
        
        assertTrue(testModel.connectionDictionary().equals(originalConnectionInfo));
        assertTrue(testModel.adaptorName().equals(originalAdaptorName));
    }



    public void testNotificationHandler()
    {
        NSDictionary testDictionary = new NSDictionary("DummyObject", "DummyKey");
        testConnector = new EOModelConnector(testDictionary, 
                                              "JDBC",
                                              new NSArray("Dummy"));
                                    
        NSNotification testNotification = 
            new NSNotification(EOModelGroup.ModelAddedNotification, testModel);
            
        // Can not do this there is already a connector created by the test suite
        // and the result are unpredictable.
        //NSNotificationCenter.defaultCenter().postNotification(testNotification);
        
        testConnector.handleModelAddedNotification(testNotification);
        
        assertTrue(testModel.connectionDictionary().equals(testDictionary));
        assertTrue(testModel.adaptorName().equals("JDBC"));
    }



	protected void tearDown() throws Exception
	{
        testModel.setConnectionDictionary(originalConnectionInfo);
         testModel.setAdaptorName(originalAdaptorName);
        super.tearDown();
	}

}
