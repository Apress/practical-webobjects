package com.apress.practicalwo.practicalutilities;

import java.util.Vector;

import com.webobjects.eoaccess.EOAdaptorChannel;
import com.webobjects.eoaccess.EODatabaseContext;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.eocontrol.EOEnterpriseObject;
import com.webobjects.eocontrol.EOGlobalID;
import com.webobjects.eocontrol.EOObjectStoreCoordinator;
import com.webobjects.foundation.*;

/**
 * A dog's breakfast of unrelated debugging methods mostly useful with EOF.
 * 
 * @author Chuck Hill and Sacha Mallais
 */
public class EOFDebugAdditions
{

    private static Vector _notificationLoggers = new Vector();


    /**
     * Delegate on EODatabaseContext that gets called when a to-one fault cannot 
     * find its corresponding data in the database. The object is a cleared fault. 
     * An exception is thrown to bring attention to this problem.   
     * 
     * Credit for the original idea goes to Kelly Hawk 
     * http://www.omnigroup.com/mailman/archive/eof/2000-December/001578.html
     */
    public boolean databaseContextFailedToFetchObject(EODatabaseContext context,
                                                        Object object,
                                                        EOGlobalID globalID) {
        EOEditingContext ec = ((EOEnterpriseObject) object).editingContext();

        // We need to refault the object before raising, otherwise, if the caller
        // traps the exception, it will be a successful lookup the next time a fault
        // with the same global id fires.
        context.refaultObject((EOEnterpriseObject) object, globalID, ec);

        String failureMessage = "Failed to fetch " + object.getClass() + 
            " with globalID " + globalID;
        RuntimeException integrityException = new RuntimeException(failureMessage);

        // When thrown during one of the R-R loop phases (or due to Key-Value 
        // coding?), the integrityException gets swallowed.  This seems to happen 
        // often. To accomodate this, the exception should be written to an error
        // log that is checked so that it is not lost.
        NSLog.err.appendln(failureMessage);
        
        throw integrityException;
    }




    /**
     * EOF resolves faults for objects that don't exist in the database to a dummy 
     * object with empty attributes.  This method detects whether the parameter 
     * is such a dummy object.<br>
     * <br>
     * A distinguishing feature of these dummy EOs is that they don't have a 
     * corresponding database context snapshot.  This is used to detect dummy 
     * objects.<br>
     * <br>
     * You should ask the editingContext to forgetObject(dummy) and null any 
     * references to it before attempting to save changes that might affect them 
     * to avoid snaptshot related exceptions.<br>
     * <br>
     * See also: http://www.omnigroup.com/mailman/archive/eof/2001-May/001986.html 
     * and following.
     * 
     * @param anObject the eo to test.  The eo's editing context must be locked before entry
     * @return returns true if <code>anObject</code> is a dummy object with empty attributes,
     * <code>false</code> otherwise
     */
    public static boolean isDummyFaultEO(EOEnterpriseObject anObject)
    {
        boolean isDummyFaultEO = false;

        // This method will fail if the object is still a fault.  We fire the fault 
        // so that the correct result is returned.
        if (anObject.isFault())
        {
            anObject.willRead();
        }

        EOEditingContext ec = anObject.editingContext();
            EOGlobalID globalID = ec.globalIDForObject(anObject);

        // NB: objects with temporary globalIDs legitimately have no DB snapshots, 
        // since these are by definition not yet saved to the database.
        if (globalID != null && ! globalID.isTemporary())
        {
            // Find the EODatabaseContext instance associated with anObject, or 
            // null if no databaseContext association can be found.
            EOObjectStoreCoordinator rootStore = 
                (EOObjectStoreCoordinator)ec.rootObjectStore();

            EODatabaseContext dbContext = 
                (EODatabaseContext)rootStore.objectStoreForObject(anObject);

            dbContext.lock();
            try
            {
                isDummyFaultEO = dbContext.snapshotForGlobalID(globalID) == null;
            }
            finally
            {
                dbContext.unlock();
            }
        }

        return isDummyFaultEO;
    }
    
    
    
    /**
     * Turns EOAdaptor SQL logging on or off to aid in debugging.
     *
     * @param shouldLog <code>true</code> if SQL logging should be turned on, 
     * <code>false</code> if it should be turned off.
     */
    public static void logSQL(boolean shouldLog)
    {
        if (shouldLog)
        {
            NSLog.allowDebugLoggingForGroups(NSLog.DebugGroupSQLGeneration
                                             | NSLog.DebugGroupDatabaseAccess
                                             | NSLog.DebugGroupEnterpriseObjects);
        }
        else
        {
            NSLog.refuseDebugLoggingForGroups(NSLog.DebugGroupSQLGeneration
                                              | NSLog.DebugGroupDatabaseAccess
                                              | NSLog.DebugGroupEnterpriseObjects);
        }
    }
    


    /**
     * EOAdaptorChannel.Delegate that gets called after a row is fetched.  
     * This is used to log the row contents during debugging.
     * 
     * @param channel An adaptor channel object
     * @param row The row fetched
     */
    public void adaptorChannelDidFetchRow( EOAdaptorChannel channel, 
                                           NSMutableDictionary row)
    {
        NSLog.out.appendln("Fetched row " + row);
    }



    /**
     * Causes a debug message to be logged whenever the named notification is
     * sent.  If null is passed as the notification name, a debug message is
     * logged whenever any notification is sent.
     * 
     * @param notificationName the name of the notification to log, or null to 
     * log all notifications
     * @param filterObject only notifications for this object are logged, if null 
     * logs all notifications for <code>notificationName</code>.  Ignored if
     * <code>notificationName</code> is null. 

     */
    public static void logNotification(String notificationName, Object filterObject)
    {
        NSNotificationCenter defaultCenter = NSNotificationCenter.defaultCenter();
        Object notificationLogger = new EOFDebugAdditions();
        NSSelector notificationCallback = 
            new NSSelector("notificationCallback", 
                           new Class[] {NSNotification.class});
        
        if (notificationName == null)
        {
            defaultCenter.addOmniscientObserver(notificationLogger, 
                                                notificationCallback);
        }
        else
        {
            defaultCenter.addObserver(notificationLogger, notificationCallback, 
                                      notificationName, filterObject);
        }
        
        // NSNotificationCenter uses weak references so we keep a dummy reference to 
        // the object logging this notification from being garbage collected.
        _notificationLoggers.add(notificationLogger);
    }




    /**
     * Notification call back that logs the sent notification.  If logging
     * NSLog.DebugLevelDetailed it also prints a stack trace of the notification.
     * 
     * @param notification the notification which was sent
     */
    public void notificationCallback(NSNotification notification)
    {
        NSLog.debug.appendln("Recieived notification " + notification.name() + 
            " with object: " + notification.object() + 
            ", userInfo: " + notification.userInfo());

        if (NSLog.debugLoggingAllowedForLevel(NSLog.DebugLevelDetailed))
        {
            NSLog.debug.appendln(new Exception("Notification Backtrace"));
        }
    }

    
}
