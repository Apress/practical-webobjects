package com.apress.practicalwo.practicalutilities.tests;

/**
 *
 *
 * @author author  Copyright (c) 2003
 */ 
public class NamedObject extends _NamedObject
{


}

