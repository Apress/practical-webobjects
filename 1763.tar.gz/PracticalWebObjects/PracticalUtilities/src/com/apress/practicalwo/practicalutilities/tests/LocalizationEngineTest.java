package com.apress.practicalwo.practicalutilities.tests;

import com.apress.practicalwo.practicalutilities.*;

import com.webobjects.eoaccess.*;
import com.webobjects.foundation.NSBundle;


/**
 * Tests for validation's LocalizationEngine.  
 *
 * @author Copyright (c) 2001-2  Global Village Consulting, Inc.  All rights reserved.
 * @version $Revision: 2$
 */
public class LocalizationEngineTest extends EOTestCase
{
    protected NSBundle validationBundle;
    protected EOEntity entity;
    protected EOEntity subClassedEntity;
    protected String localizationTestProperty;


    /**
     * Designated constuctor.
     */
    public LocalizationEngineTest(String name)
    {
        super(name);
    }



    /**
     * Common test code.
     */
    public void setUp() throws java.lang.Exception
    {
        super.setUp();
        validationBundle = NSBundleAdditions.bundleForClass(getClass());
        entity = EOModelGroup.defaultGroup().entityNamed("AttributeValidationTestEntity");
        subClassedEntity = EOModelGroup.defaultGroup().entityNamed("DecimalPKSubclass");
        localizationTestProperty = "localizationTestProperty";
    }



    /**
     * Test NSBundle localization cover methods.
     */
    public void testDoesBundleHaveLocalizedString()
    {
        // DBC
        try
        {
            NSBundleAdditions.localizedStringExistsForKey(null, "keyThatExists", "PracticalUtilities");
            fail("Missing null bundle precondition");
        }
        catch (Throwable t) {}

        try
        {
            NSBundleAdditions.localizedStringExistsForKey(validationBundle, null, "PracticalUtilities");
            fail("Missing null key precondition");
        }
        catch (Throwable t) {}

        try
        {
            NSBundleAdditions.localizedStringExistsForKey(validationBundle, "keyThatExists", null);
            fail("Missing null fileName precondition");
        }
        catch (Throwable t) {}


        assertTrue(NSBundleAdditions.localizedStringExistsForKey(validationBundle, "keyThatExists", "PracticalUtilities"));
        assertTrue( ! NSBundleAdditions.localizedStringExistsForKey(validationBundle, "keyThatDoesNotExist", "PracticalUtilities"));

        assertTrue(NSBundleAdditions.localizedStringForKey(validationBundle, "keyThatExists", "PracticalUtilities").equals("Localized string for keyThatExists"));
    }



    /**
     * Test method checking one bundle for a key.
     */
    public void testlocalizedStringFromBundle()
    {
        // DBC
        try
        {
            LocalizationEngine.localizedStringFromBundle(null,
                                                         entity.name(),
                                                         localizationTestProperty,
                                                         "fullyQualifiedKeyTest");
            fail("Missing null bundle precondition");
        }
        catch (Throwable t) {}

        try
        {
            LocalizationEngine.localizedStringFromBundle(validationBundle,
                                                         null,
                                                         localizationTestProperty,
                                                         "fullyQualifiedKeyTest");
            fail("Missing null entity precondition");
        }
        catch (Throwable t) {}

        try
        {
            LocalizationEngine.localizedStringFromBundle(validationBundle,
                                                         entity.name(),
                                                         localizationTestProperty,
                                                         null);
            fail("Missing null key precondition");
        }
        catch (Throwable t) {}

        // Check for fully qualified key in entity's strings file
        assertEquals(LocalizationEngine.localizedStringFromBundle(validationBundle, entity.name(), localizationTestProperty, "fullyQualifiedKeyTest"), "Localization key for fully qualified key");

        // Check for partially qualified key in entity's strings file, and empty property name
        assertEquals(LocalizationEngine.localizedStringFromBundle(validationBundle, entity.name(), "", "partiallyQualifiedKeyTest"), "Localization key for partially qualified key");

        // Check for generic key not being found in entity's strings file
        assertTrue(LocalizationEngine.localizedStringFromBundle(validationBundle,
                                                                entity.name(),
                                                                localizationTestProperty,
                                                                "genericKeyTest") == null);
        // Check for fully qualified key in bundle's strings file
        assertEquals("Localization key for fully qualified bundle key",
            LocalizationEngine.localizedStringFromBundle(validationBundle, 
                entity.name(), localizationTestProperty, "fullyQualifiedBundleKeyTest"));

        // Check for partially qualified key in bundle's strings file and null property name
        assertEquals(LocalizationEngine.localizedStringFromBundle(validationBundle, entity.name(), null, "partiallyQualifiedBundleKeyTest"), "Localization key for partially qualified bundle key");

        // Check for generic key in bundle's strings file
        assertEquals(LocalizationEngine.localizedStringFromBundle(validationBundle, entity.name(), localizationTestProperty, "genericBundleKeyTest"), "Localization key for generic bundle key");
    }



    /**
     * Test method checking full localization search for a key.
     */
    public void testlocalizedString()
    {
        // DBC
        try
        {
            LocalizationEngine.localizedString((String)null, null, EOFValidation.DisplayName);
            fail("Missing null entity precondition");
        }
        catch (RuntimeException t) {}

        try
        {
            LocalizationEngine.localizedString(subClassedEntity, null, null);
            fail("Missing null key precondition");
        }
        catch (RuntimeException t) {}

        // Check exception for no localized message for key
        try
        {
            LocalizationEngine.localizedString(entity, localizationTestProperty, "nonExistantKey");
            fail("Missing localized string non-existant precondition");
        }
        catch (RuntimeException r) {}

        // Check for key in main bundle.
        // NOTE: this needs to be added to whatever WOApp is testing this framework!
        // Removed as it can not pass when using jUnit directly to test framworks. - ch
        // assertTrue(LocalizationEngine.localizedString(subClassedEntity, null, EOFValidation.DisplayName).equals("Localization Test: Display Name from main bundle."));

        // Check for key on most derived class
        assertEquals("Localization Test: most derived class invalid value.",
            LocalizationEngine.localizedString(subClassedEntity, 
                localizationTestProperty, EOFValidation.InvalidValue));

        // Check for default key
        assertEquals("<<failedValue>> is below the acceptable limit for <<propertyName>> for <<entityName>>.",
            LocalizationEngine.localizedString(subClassedEntity, 
                localizationTestProperty, EOFValidation.BelowMinimum));
    }



}
