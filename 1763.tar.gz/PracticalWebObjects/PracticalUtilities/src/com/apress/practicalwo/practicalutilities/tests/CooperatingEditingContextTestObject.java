package com.apress.practicalwo.practicalutilities.tests;

import com.apress.practicalwo.practicalutilities.EOStateTransition;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.eocontrol.EOGlobalID;
import com.webobjects.foundation.NSLog;
import com.webobjects.foundation.NSTimestamp;

/**
 * EOEnterpriseObject specially configured to assist in testing the
 * CooperatingEditingContext.
 *
 * @author Chuck Hill and Sacha Mallais  Copyright (c) 2003
 */ 
public class CooperatingEditingContextTestObject extends _CooperatingEditingContextTestObject 
implements EOStateTransition
{
    // Use int's so that we can tell if it was called more than once
    public int calledHasInserted = 0;
    public int calledWillDelete = 0;
    public int calledHasDeleted = 0;
    public int calledWillUpdate = 0;
    public int calledHasUpdated = 0;
    public EOGlobalID ourGlobalID;
    public EOEditingContext ourEC;
    

    public void hasInserted()
    {
        calledHasInserted++;

        if (NSLog.debugLoggingAllowedForLevel(NSLog.DebugLevelDetailed))
        {
            NSLog.out.appendln("Called hasInserted for " + 
            editingContext().globalIDForObject(this) + " in " + editingContext());
        }
    }



    public void willDelete()
    {
        calledWillDelete++;

        if (NSLog.debugLoggingAllowedForLevel(NSLog.DebugLevelDetailed))
        {
            NSLog.out.appendln("Called willDelete for " + 
            editingContext().globalIDForObject(this) + " in " + editingContext());
            
            // Capture these as they go away once the delete is saved.
            ourGlobalID = editingContext().globalIDForObject(this);
            ourEC = editingContext();
        }
    }


    public void hasDeleted()
    {
        calledHasDeleted++;

        if (NSLog.debugLoggingAllowedForLevel(NSLog.DebugLevelDetailed))
        {
            NSLog.out.appendln("Called hasDeleted for " + 
            ourGlobalID + " in " + ourEC);
        }
    }



    public void willUpdate()
    {
        calledWillUpdate++;

        // This is used to test willUpdate causing updates to other objects.
        if (relatedObject() != null)
        {
            relatedObject().setStringValue(new NSTimestamp().toString());
        }

        if (NSLog.debugLoggingAllowedForLevel(NSLog.DebugLevelDetailed))
        {
            NSLog.out.appendln("Called willUpdate for " + 
            editingContext().globalIDForObject(this) + " in " + editingContext());
        }
    }


    public void hasUpdated()
    {
        calledHasUpdated++;

        if (NSLog.debugLoggingAllowedForLevel(NSLog.DebugLevelDetailed))
        {
            NSLog.out.appendln("Called hasUpdated for " + 
            editingContext().globalIDForObject(this) + " in " + editingContext());
        }
    }


    public void resetCounters()
    {
        calledHasInserted = 0;
        calledWillDelete = 0;
        calledHasDeleted = 0;
        calledWillUpdate = 0;
        calledHasUpdated = 0;
    }

}
