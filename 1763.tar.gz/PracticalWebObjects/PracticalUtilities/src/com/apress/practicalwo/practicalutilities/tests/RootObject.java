package com.apress.practicalwo.practicalutilities.tests;

import com.webobjects.eocontrol.EOEditingContext;


/**
 * EOEnterprise object used in testing of EOCopying / CopyableGenericRecord 
 * Root object copies deeply.
 * @author Global Village Consulting, Inc.  Copyright 2001-2003 All Rights Reserved.
 */
public class RootObject extends _RootObject 
{

    public void awakeFromInsertion(EOEditingContext ec)
    {
        super.awakeFromInsertion(ec);
        setAValue(new Integer(10));
    }
}
