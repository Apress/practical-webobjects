package com.apress.practicalwo.practicalutilities.tests;

import java.math.BigDecimal;

import com.apress.practicalwo.practicalutilities.*;

import com.webobjects.eoaccess.*;
import com.webobjects.foundation.NSKeyValueCoding;


/**
 * Tests for EOFValidation's EOFValidationException class.
 *
 * @author Copyright (c) 2001-2  Global Village Consulting, Inc.  All rights reserved.
 * @version $Revision: 2$
 */
public class EOFValidationExceptionTest extends EOTestCase
{
    protected EOEntity entity;
    protected EOEntity relationshipEntity;
    protected EOAttribute attribute;
    protected EORelationship relationship;
    protected final String stringTooLong = "Unreasonably long string";
    protected RuntimeException FIXME;// fakeAdaptorFailureException;


    /**
     * Designated constuctor.
     */
    public EOFValidationExceptionTest(String name)
    {
        super(name);
    }



    /**
     * Common test code.
     */
    public void setUp() throws java.lang.Exception
    {
        super.setUp();
        entity = EOModelGroup.defaultGroup().entityNamed("AttributeValidationTestEntity");
        attribute = entity.attributeNamed("requiredString");

        relationshipEntity = EOModelGroup.defaultGroup().entityNamed("RelationshipValidationTestEntity");
        relationship = relationshipEntity.relationshipNamed("requiredBareEntity");
/*
        // Create fakeAdaptorFailureException as they are difficult to set up.  This is a very minimal example and is just enough to trick out code into believing it is a real exception.
        NSMutableDictionary adaptorFailureDictionary = new NSMutableDictionary();
        NSMutableDictionary failedDatabaseOperationDictionary = new NSMutableDictionary();
        EOEnterpriseObject someObject = new AttributeValidationTestEntity();

        // Just to indicate this is an adaptor failure exception.
        adaptorFailureDictionary.setObjectForKey("Place holder", EOAdaptorChannel.FailedAdaptorOperationKey);

        failedDatabaseOperationDictionary.setObjectForKey(entity, "_entity");
        failedDatabaseOperationDictionary.setObjectForKey(someObject, "_object");
        adaptorFailureDictionary.setObjectForKey(failedDatabaseOperationDictionary, "EOFailedDatabaseOperationKey");

        fakeAdaptorFailureException =  new RuntimeException("Ignore" + " " + "Ignore");
*/
    }



    /**
     * Tests getLocalizedMessage
     */
    public void testGetLocalizedMessage()
    {
        EOFValidationException exception = new EOFValidationException(attribute, EOFValidation.NullNotAllowed, null);
        assertEquals(exception.getLocalizedMessage(), "The mandatory string must be entered for this Test Entity For Attribute Validation.");

        exception = new EOFValidationException(attribute, EOFValidation.TooLong, stringTooLong);
        exception.setFailedValue(stringTooLong);
        assertEquals("The mandatory string you entered, '" + stringTooLong + "', is longer than the 50 characters permitted.", exception.getLocalizedMessage());
    }



    /**
     * Tests for creation of EOFValidationException.
     */
    public void testEOFValidationException()
    {
        // Attribute version
        EOFValidationException testException = new EOFValidationException(attribute, EOFValidation.TooLong, stringTooLong);

        assertEquals(testException.getLocalizedMessage(), "The mandatory string you entered, '" + stringTooLong + "', is longer than the 50 characters permitted.");
        assertEquals(testException.propertyKey(), attribute.name());
        assertEquals(testException.failedValue(), stringTooLong);
        assertEquals(testException.failureKey(), EOFValidation.TooLong);

        // Relationship version
        testException = new EOFValidationException(relationship, EOFValidation.NullNotAllowed, NSKeyValueCoding.NullValue);
        assertEquals(testException.getLocalizedMessage(), "You must enter a mandatory unadorned entity for this Relationship Validation Test Entity");
        assertEquals(testException.propertyKey(), relationship.name());
        assertEquals(testException.failedValue(), NSKeyValueCoding.NullValue);
        assertEquals(testException.failureKey(), EOFValidation.NullNotAllowed);
    }



    /**
     * Tests for exception checking methods.
     */
    public void testExceptionCheckingMethods()
    {
        AttributeValidationTestEntity testEntity = new AttributeValidationTestEntity();

        // FIXME commented out values no longer work...
        editingContext().insertObject(testEntity);
        //testEntity.takeValueForKey("7", "requiredInteger");
        testEntity.setRequiredDecimalNumber(new BigDecimal("13.13"));
        //testEntity.takeValueForKey(new NSTimestamp(), "requiredDouble");
        //testEntity.takeValueForKey(NSKeyValueCoding.NullValue, "requiredString");
        testEntity.setShortString("1234567890X");

        try
        {
            editingContext().saveChanges();
            fail("InvalidChanges saved");
        }
        catch (EOFValidationException e)
        {
            assertTrue("Failed to find exception with class method", e.doesFailureExist("requiredInteger", EOFValidation.NullNotAllowed));

            EOFValidationException specificException = e.exceptionForFailure("requiredInteger", EOFValidation.NullNotAllowed);
            assertTrue("Failed to verify exception with class method", specificException.isExceptionForFailure("requiredInteger", EOFValidation.NullNotAllowed));
            assertTrue("Failed to find exception with instance method",
                   specificException.doesFailureExist("requiredInteger", EOFValidation.NullNotAllowed));
        }
    }


    
}
