package com.apress.practicalwo.practicalutilities;

import java.util.Enumeration;

import com.webobjects.eoaccess.EOAttribute;
import com.webobjects.eoaccess.EOEntity;
import com.webobjects.eoaccess.EORelationship;
import com.webobjects.eoaccess.EOUtilities;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.eocontrol.EOEnterpriseObject;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSSet;


public class EOEntityCopier {
	
	
	public static synchronized EOEnterpriseObject 
        deepCopy(EOEditingContext editingContext, EOEnterpriseObject original) 
	{
        // Get the entity like this to handle editingContext and original being 
        // different EOF stacks.
		EOEntity entity = EOUtilities.entityForObject(editingContext, original);
        
        // This is the preferred method for creating a new class as it ensures
        // that the object is matched to its correct class description and that it
        // is inserted into an editing context before being worked with.
		EOEnterpriseObject copy = EOUtilities.createAndInsertInstance(editingContext, 
                                                                      entity.name());
      
        // Non class properties will be handled by EOF, we should not copy them.
        NSSet classProperties = new NSSet(entity.classProperties());
        
		// Copy all attributes on the EO, ignoring non-class properties
        NSSet allAttributes = new NSSet(entity.attributes());
        NSSet publicAttributes = allAttributes.setByIntersectingSet(classProperties);

		Enumeration attributeEnumerator = publicAttributes.objectEnumerator();
        EOAttribute anAttribute;
        while (attributeEnumerator.hasMoreElements()) 
        {
            anAttribute = (EOAttribute)attributeEnumerator.nextElement();
            copy.takeValueForKey(original.valueForKey(anAttribute.name()), 
                                                      anAttribute.name());
        }


        // Copy relationships ignoring non-class properties. Owned objects are
        // deep copied, all others are copied by reference.
        NSSet allRelationships = new NSSet(entity.relationships());
        NSSet publicRelationships = allRelationships.
            setByIntersectingSet(classProperties);

        Enumeration relationshipEnumerator = publicRelationships.objectEnumerator();
        EORelationship aRelationship;
        while (relationshipEnumerator.hasMoreElements()) 
        {
            aRelationship = (EORelationship)relationshipEnumerator.nextElement();
            if (aRelationship.isToMany()) 
            {
                // Copy each element of the to-many array
                NSArray relatedObjects = (NSArray)original.valueForKey(
                    aRelationship.name());
                for (int i = 0, count = relatedObjects.count(); i < count ; i++) 
                {
                    EOEnterpriseObject relatedObject = 
                        (EOEnterpriseObject)relatedObjects.objectAtIndex(i);
                    EOEnterpriseObject copiedRelationship;
                    if (aRelationship.ownsDestination()) 
                    {
                        copiedRelationship = deepCopy(editingContext, relatedObject);
                    } 
                    else 
                    {
                        copiedRelationship = EOUtilities.
                            localInstanceOfObject(editingContext, relatedObject);
                    }
                    copy.addObjectToBothSidesOfRelationshipWithKey(
                        copiedRelationship, aRelationship.name());
                }
            } 
            else 
            {
                EOEnterpriseObject relatedObject = (EOEnterpriseObject)original.
                    valueForKey(aRelationship.name());
                // To-one relationships are easier to copy but we need to handle
                // null relationships
                if (original != null) 
                {
                    EOEnterpriseObject copiedRelationship;

                    if (aRelationship.ownsDestination()) 
                    {
                        copiedRelationship = deepCopy(editingContext, relatedObject);
                    } 
                    else 
                    {
                        copiedRelationship = EOUtilities.localInstanceOfObject(
                            editingContext, relatedObject);
                    }
                    copy.addObjectToBothSidesOfRelationshipWithKey(
                        copiedRelationship, aRelationship.name());
                 }
            }
        }
        return copy;
    }

}
