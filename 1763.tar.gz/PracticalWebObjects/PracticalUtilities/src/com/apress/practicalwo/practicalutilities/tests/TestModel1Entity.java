package com.apress.practicalwo.practicalutilities.tests;

/**
 *
 *
 * @author author  Copyright (c) 2003
 */ 
public class TestModel1Entity extends _TestModel1Entity
{


}

