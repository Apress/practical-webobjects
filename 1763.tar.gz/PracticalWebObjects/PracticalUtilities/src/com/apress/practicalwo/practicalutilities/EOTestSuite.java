package com.apress.practicalwo.practicalutilities;


import com.webobjects.eoaccess.EOModelGroup;
import com.webobjects.foundation.*;



/**
 * TestSuite extended to support testing of EO objects.  Sets the connection
 * dictionary and prototypes for the database being tested. 
 * 
 * @author Chuck Hill and Sacha Mallais
 */
public class EOTestSuite extends junit.framework.TestSuite
{

    public static final String CONNECTION_DICTIONARIES_KEY = "connectionDictionaries";
    public static final String DATABASE_TYPE_KEY = "databaseToUse";
    public static final String MODELS_TO_IGNORE_KEY = "modelsToIgnore";    


    protected NSDictionary testConfigurationDictionary;
    protected EOPrototypeSwitcher prototypeSwitcher;
    protected EOModelConnector modelConnector;


    /**
     * Designated constuctor.  
     * 
     * @param suiteName user presentable name for this test suite
     */
    public EOTestSuite(String suiteName)
    {
        super(suiteName);
        
        // Redirect NSLog.debug to NSLog.out so that the debug information will come out in the test window.  
        // This makes it a lot easier to debug tests.
        NSLog.setDebug(NSLog.out);

        // This can help to debug test configuration
        // NSLog.setAllowedDebugLevel(NSLog.DebugLevelDetailed);

        // Make sure all the models are using the correct set of prototypes before starting the tests.
        prototypeSwitcher = new EOPrototypeSwitcher(databaseType());
        prototypeSwitcher.listenForAddedModels();
        
        // Make sure all the models are connected with the same connection dictionary before starting the tests.
        modelConnector = new EOModelConnector(connectionDictionary(), modelsToIgnore());
        modelConnector.listenForAddedModels();
        
        // This line causes the EOModels to be loaded from the bundles referenced on the classpath.
        EOModelGroup.defaultGroup().models();
    }



    /**
     * Returns the connection dictionary to be used in this test run for all EOModels 
     * in this Suite of tests.  This can be overridden in sub-classes if a different 
     * connection dictionary is needed.  This class gets the connection dictionary 
     * from the DATABASE_TYPE_KEY in testConfigurationDictionary(). 
     *
     * @return the connection dictionary for all EOModels used in this Suite of tests.
     */
    public NSDictionary connectionDictionary()
    {
        NSDictionary connectionDictionaries =
            (NSDictionary) testConfigurationDictionary().objectForKey(CONNECTION_DICTIONARIES_KEY); 
        
        return (NSDictionary) connectionDictionaries.objectForKey(databaseType());

        /** ensure
        [valid_result] Result != null;
        [url_key_is_present] Result.objectForKey("URL") != null; **/
    }



    /**
     * Returns the database type (e.g. DB2, Oracle, FrontBase, OpenBase, mySQL etc.)
     * that is to be used for this test run.  This should match the database name 
     * as used in the EO<database name>Prototypes prototypes entity for this 
     * database and also the the name used in testConfigurationDictionary()if that 
     * is relevant.  Remeber - case counts!  This class gets the database type from
     * the DATABASE_TYPE_KEY in testConfigurationDictionary(). 
     *
     * @return the database type that is to be used for this test run
     */
     public String databaseType()
    {
        return (String) testConfigurationDictionary().objectForKey(DATABASE_TYPE_KEY);
        
        /** ensure [valid_result] Result != null;  **/
    }



    /**
     * Returns a list of the model names to <b>not</b>connect using connectionDictionary().  This
     * can be used if some of the models that will be loaded are not needed for testing, or need
     * to be connected to a different database.
     * 
     * @return a list of the model names to <b>not</b>connect using connectionDictionary()
     */
    public NSArray modelsToIgnore()
    {
        return (NSArray) testConfigurationDictionary().objectForKey(MODELS_TO_IGNORE_KEY);

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Returns the configuration dictionary for this test run.  This is used to 
     * implement the other methods in this class.  This method can be overridden to
     * get the dictionary from some other source, or the other methods can be 
     * re-implemented in a different manner.  By default, this class gets the
     * dictionary from the TestConfigurationDictionary.plist of the framework in 
     * the working directory when the tests are run.<br>
     * <br>
     * The dictionary is expected to have this format:
     * <code>
     * {
     *     databaseToUse = "<database type>";
     *     connectionDictionaries = {
     *         <database type1> = {
     *             URL = ...
     *             etc
     *         };
     *         <database type2> = {
     *             URL = ...
     *             etc
     *         };
     *     };
     *
     *     modelsToIgnore = ();
     * };
     * </code>
     *
     * @return the configuration dictionary for this test run
     */
    protected NSDictionary testConfigurationDictionary()
    {
        if (testConfigurationDictionary == null)
        {
            NSBundle bundle = NSBundle.mainBundle();
            byte[] tableBytes = bundle.bytesForResourcePath("TestConfiguration.plist");
            String tableString = new String(tableBytes);
            NSDictionary configDictionary = 
                 (NSDictionary)NSPropertyListSerialization.propertyListFromString(tableString);

            // Validate dictionary contents
            if (configDictionary.objectForKey(DATABASE_TYPE_KEY) == null)
            {
                throw new IllegalArgumentException(DATABASE_TYPE_KEY + 
                    " key missing from testConfigurationDictionary()");
            }
            
            if (configDictionary.objectForKey(CONNECTION_DICTIONARIES_KEY) == null)
            {
                throw new IllegalArgumentException(CONNECTION_DICTIONARIES_KEY + 
                    " key missing from testConfigurationDictionary()");
            }
            
            if (((NSDictionary)configDictionary.objectForKey(CONNECTION_DICTIONARIES_KEY)).
                objectForKey(configDictionary.objectForKey(DATABASE_TYPE_KEY)) == null)
            {
                throw new IllegalArgumentException(DATABASE_TYPE_KEY + " '" + 
                    configDictionary.objectForKey(configDictionary.objectForKey(DATABASE_TYPE_KEY)) + 
                    "' has no corresponding entry in " +
                    CONNECTION_DICTIONARIES_KEY + " from testConfigurationDictionary()");
            }
            
            if (configDictionary.objectForKey(MODELS_TO_IGNORE_KEY) == null)
            {
                throw new IllegalArgumentException(MODELS_TO_IGNORE_KEY + 
                    " key missing from testConfigurationDictionary()");
            }
            
            testConfigurationDictionary = configDictionary;
        }
        
        return testConfigurationDictionary;
        
        /** ensure
        [valid_result] Result != null;
        [database_type_key_is_present] Result.objectForKey(DATABASE_TYPE_KEY) != null;
        [connection_dictionaries_key_is_present] Result.objectForKey(CONNECTION_DICTIONARIES_KEY) != null;
        [database_type_has_connection_dictionary] ((NSDictionary)Result.objectForKey(CONNECTION_DICTIONARIES_KEY)).
                objectForKey(Result.objectForKey(DATABASE_TYPE_KEY)) != null;
        [modelsToIgnore_key_is_present] Result.objectForKey(MODELS_TO_IGNORE_KEY) != null; **/
    }


}
