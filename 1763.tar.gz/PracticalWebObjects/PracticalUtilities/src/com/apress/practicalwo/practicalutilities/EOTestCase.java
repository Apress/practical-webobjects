package com.apress.practicalwo.practicalutilities;

import junit.framework.TestCase;

import com.webobjects.eocontrol.EOEditingContext;


/**
 * TestCase that provides some support and convenience methods for use when testing EOEnterpriseObjects.
 * 
 * @author Chuck Hill and Sacha Mallais
 */
public class EOTestCase extends TestCase
{
    private EOEditingContext editingContext;


    public EOTestCase(String testCase)
    {
        super(testCase);
    }



    /**
     * Creates editingContext() for use in tests. 
     */
    protected void setUp() throws java.lang.Exception
    {
        super.setUp();
        setEditingContext(new EOEditingContext());
        editingContext().setStopsValidationAfterFirstError(false);
        /** ensure [has_ec] editingContext() != null;  
        [ec_continues_validation] ! editingContext.stopsValidationAfterFirstError();  **/
    }



    /**
     * Disposes of the editing context created in setUp().  Call this after doing your own tearDown.
     */
    protected void tearDown() throws java.lang.Exception
    {
        editingContext.unlock();
        editingContext().dispose();
        editingContext = null;
        super.tearDown();

        /** ensure [ec_cleared] editingContext() == null;  **/
    }



    /**
     * Sets the EOEditingContext to use for this test case and locks it.  If an editing context was
     * previously set it is disposed of and unlocked.
     * 
     * @param newEditingContext the EOEditingContext to use for this test case
     */
     public void setEditingContext(EOEditingContext newEditingContext)
     {
         /** require [valid_param] newEditingContext != null;  **/

         if (editingContext != null)
         {        
             editingContext.unlock();
             editingContext().dispose();
         }

         newEditingContext.lock();
         editingContext = newEditingContext;
     }
     
     
     
    /**
     * Returns a locked EOEditingContext that can be used when writing tests.
     * 
     * @return a locked EOEditingContext that can be used when writing tests
     */
    public EOEditingContext editingContext() 
    {
        return editingContext;

        /** ensure [valid_result] Result != null;  **/
    }



    /**
     * Generates a globally unique string.  This can be useful if you need to give unique names
     * to objects used in testing.
     * 
     * @return a globally unique string
     */
    public String globallyUniqueString()
    {
        String localIP = null;
        String uniqueString = null;
        String uniqueThang = null;

        try
        {
            localIP = java.net.InetAddress.getLocalHost().getHostAddress();
        }
        catch (java.net.UnknownHostException e)
        {
            throw new RuntimeException("EOTestCase.globallyUniqueString() couldn't get IP!"); 
        }

        uniqueThang = (new java.rmi.server.UID()).toString(); // nasty, but seems to work ok
        uniqueString = localIP + " " + uniqueThang;

        return uniqueString;

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Saves changes on <code>editingContext</code> and calls <code>fail(String)</code> 
     * if an exception is thrown.
     *
     * @param message the message to pass to <code>fail(String)</code>
     */
    public void saveChangesShouldntThrow(String message)
    {
        /** require [valid_param] message != null; **/

        try
        {
            editingContext.saveChanges();
        }
        catch (Exception e)
        {
            fail(message);
        }
    }



    /**
     * Saves changes on <code>editingContext</code> and calls <code>fail(String)</code> 
     * if an exception is not thrown.
     *
     * @param message the message to pass to <code>fail(String)</code>
     */
    public void saveChangesShouldThrow(String message)
    {
        /** require [valid_param] message != null; **/

        try
        {
            editingContext.saveChanges();
            fail(message);
        }
        catch (Exception e) { }
    }



}
