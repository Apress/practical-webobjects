package com.apress.practicalwo.practicalutilities;

import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSDictionary;


/**
 * <p>This component is an alternative to <code>WOPopUp</code>.  
 * <code>WOPopUp</code> assumes that the displayed and selected values come from 
 * the same source (e.g. an <code>NSArray</code> of <code>EOEnterpriseObjects
 * </code>).  The <code>PWOMappedPopup</code> is useful when the display and 
 * internal representations are not available from the same object.  For example, 
 * consider a popup displaying Yes and No while selecting <code>Boolean.TRUE
 * </code> and <code>Boolean.False</code>.  It is easy to display <code>true
 * </code> and <code>false</code> while selecting <code>Boolean.TRUE</code> and 
 * <code>Boolean.False</code> but how can you display Yes and No useing a 
 * <code>WOPopUp</code>? This is also useful when the user presentable name for 
 * an object is not an attribute of the object.</p>
 * <br />
 * <p><code>PWOMappedPopup</code> solves this by taking two lists: one to 
 * display and one to take the<code>selection</code> from.  The display list is
 * an array which is assumed to be in the correct order for display. The objects
 * to select can come from an <code>NSDictionary</code> of objects keyed on the 
 * display names or from an array with the objects at matching indexes (element 
 * N of the display list matches element N of the selection list.</p>
 * <br />
 * <p>The bindings are:<br/>
 * <table>
 * <th><td>Binding</td><td>Usage</td></th>
 * <tr><td>displayFrom</td><td>the <code>NSArray</code> to take the UI display 
 * values from</td></tr>
 * <tr><td>selectFromArray</td><td>the <code>NSArray</code> to take the values 
 * for <code>selection</code> from</td></tr>
 * <tr><td>selectFromDictionary</td><td>the <code>NSDictionary</code> to take 
 * the values for <code>selection</code> from</td></tr>
 * <tr><td>selection</td><td>the value to be changed when a different item is 
 * selected from the list</td></tr>
 * <tr><td>noSelectionString</td><td>Optional.  Enables the first item to be 
 * "empty."  Bind this attribute to a string (such as an empty string) that, if 
 * chosen, represents an empty selection. When this item is selected, the 
 * <code>selection</code> attribute is set to <code>null</code>.</td></tr>
 * <tr><td>formatter</td><td>Optional.  The formatter to format items in 
 * <code>displayFrom</code> with before displaying them.</td></tr>
 * <table></p>
 *
 * @author Charles Hill and Sacha Mallais
 */
public class PWOMappedPopup extends WOComponent 
{
    // Constants for binding
    public static final String NO_SELECTION_STRING_BINDING = "noSelectionString";
    public static final String FORMATTER_BINDING = "formatter";
    public static final String DISPLAY_FROM_BINDING = "displayFrom";
    public static final String SELECT_FROM_ARRAY_BINDING = "selectFromArray";
    public static final String SELECT_FROM_DICTIONARY_BINDING = "selectFromDictionary";
    public static final String SELECTION_BINDING = "selection";


    // Instance variables to cache binding values
    protected String noSelectionString;
    protected java.text.Format formatter;
    protected NSArray displayFrom;
    protected NSArray selectionArray;
    protected NSDictionary selectionDictionary;
    protected Object parentSelection;
    
    /** Used for the iteration over <code>displayFrom</code> */
    public Object anItem;


    /**
     * Designated constructor.
     * 
     * @param context the <code>WOContext</code> in which this was created
     */
    public PWOMappedPopup(WOContext context) 
    {
        super(context);
    }



    /**
     * Returns true, this component is stateless with the default manual 
     * syncrhonization of bindings
     *
     * @return true, this component is stateless.
     */
    public boolean isStateless()
    {
        return true;
    }

   
   
    /**
     * Sets the instances variables used to cache binding values to null before
     * the next use of this component.
     */
    public void reset()
    {
        noSelectionString = null;
        formatter = null;
        displayFrom = null;
        selectionArray = null;
        selectionDictionary = null;
        parentSelection = null;

        super.reset();
    }
    
    
    

    /**
     * Returns the value to display for <code>anItem</code>. This value will be
     * formatted if <code>formatter()</code> is not null.  
     *  
     * @return the value to display for <code>anItem</code>
     */
    public Object displayString() 
    {
        /** require [valid_item] anItem != null;  **/
        
        return (formatter() != null) ? formatter().format(anItem) : anItem;
        
        /** ensure [valid_result] Result != null;  **/
    }
                
                                
                
    /**
     * Returns the value from <code>displayList()</code> that maps to 
     * <code>parentSelection()</code>. If <code>parentSelection()</code> is null 
     * then the <code>defaultSelection</code> is returned. 
     * 
     * @return the value from <code>displayList()</code> to display as the 
     * selected value
     */
    public Object selection() 
    {
        Object selection;
        
        if (parentSelection() == null)
        {
            selection = defaultSelection();
        }
        else if (isSelectingFromArray())
        {
            selection = displayList().objectAtIndex(selectionArray().
                indexOfObject(parentSelection()));
        }
        else
        {
            selection = selectionDictionary().
                 allKeysForObject(parentSelection()).lastObject();
        }
        
        return selection;
        /** ensure [valid_result] Result != null && 
                                  (Result.equals(noSelectionString()) ||
                                   displayList().containsObject(Result));  
         **/
    }
    


    /**
     * Sets the <code>parentSelection</code> based on the value that maps to 
     * <code>newSelection</code>. If <code>noSelectionString</code> is
     * selected, sets the <code>parentSelection()</code> to <code>null</code>.
    
     * 
     * @param newSelection value from <code>displayList</code> or 
     * <code>noSelectionString</code>
     */
    public void setSelection(String newSelection) 
    {
        /** require [valid_selection] (newSelection != null) && 
                                      (newSelection.equals(noSelectionString()) ||
                                       displayList().containsObject(newSelection));  
         **/
        
        if (newSelection == null)
        {
            setParentSelection(null);
        }
        else if (isSelectingFromArray())
        {
            setParentSelection(selectionArray().objectAtIndex(displayList().
                indexOfObject(newSelection)));
        }
        else
        {
            setParentSelection(selectionDictionary().objectForKey(newSelection));
        }
        /** ensure [value_set] selection().equals(newSelection);  **/
    }



    /**
     * Returns <code>true</code> if objects are being selected from 
     * <code>selectionArray</code> and <code>false</code> if objects are being 
     * selected from <code>selectionDictionary</code>.
     *  
     * @return <code>true</code> if objects are being selected from 
     * <code>selectionArray</code>
     */
    public boolean isSelectingFromArray()
    {
        return selectionArray() != null;
    }
   
   
   
   /**
    * Returns the default selection value.  This will either be the first value 
    * from <code>displayList</code> or the <code>noSelectionString</code>.
    * 
    * @return the default selection value
    */
   public Object defaultSelection()
   {
       return (noSelectionString() == null) ? 
           displayList().objectAtIndex(0) : null;
           
   }



   /**
    * Returns the value for the optional <code>noSelectionString</code> binding.
    * 
    * @return the value for the optional <code>noSelectionString</code> binding
    */
    public String noSelectionString() 
    {
        if (noSelectionString == null)
        {
            noSelectionString = (String) valueForBinding(
                NO_SELECTION_STRING_BINDING); 
        }
        return noSelectionString;
    }



    /**
     * Returns the value for the optional <code>formatter</code> binding.
     * 
     * @return the value for the optional <code>formatter</code> binding
     */
    public java.text.Format formatter() 
    {
        if (formatter == null)
        {
            formatter = (java.text.Format) valueForBinding(FORMATTER_BINDING);
        }
        return formatter;
    }



    /**
     * Returns the value for the <code>displayList</code> binding.
     * 
     * @return the value for the <code>displayList</code> binding
     * @exception IllegalStateException if this is not bound
     */
    public NSArray displayList() 
    {
        if (displayFrom == null)
        {
            if (! bindingKeys().containsObject(DISPLAY_FROM_BINDING))
            {
                throw new IllegalStateException("<" + getClass().getName() + 
                    "> : "+ DISPLAY_FROM_BINDING + " binding is missing.");
            }
            displayFrom = (NSArray) valueForBinding(DISPLAY_FROM_BINDING);
        }
        return displayFrom;
        /** ensure [valid_result] Result != null;  **/ 

    }
    
    
    
    /**
     * Returns the value for the <code>selectionArray</code> binding.
     * 
     * @return the value for the <code>selectionArray</code> binding
     * @exception IllegalStateException if this or 
     * <code>selectionDictionary</code> is not bound, or if both are bound
     */
    public NSArray selectionArray() 
    {
        if (selectionArray == null)
        {
            validateSelectFromBindings();
            selectionArray = (NSArray) valueForBinding(SELECT_FROM_ARRAY_BINDING);
        }
        return selectionArray;
    }
    
    
    
    /**
     * Returns the value for the <code>selectionDictionary</code> binding.
     * 
     * @return the value for the <code>selectionDictionary</code> binding
     * @exception IllegalStateException if this or 
     * <code>selectionArray</code> is not bound, or if both are bound
     */
    public NSDictionary selectionDictionary() 
    {
        if (selectionDictionary == null)
        {
            validateSelectFromBindings();
            selectionDictionary = (NSDictionary) valueForBinding(
                SELECT_FROM_DICTIONARY_BINDING);
        }
        return selectionDictionary;
    }
    
   
   
    /**
     * Validation common to both the <code>selectionArray</code> and 
     * <code>selectionDictionary</code> bindings. 
     * 
     * @exception IllegalStateException if neither or both of these bindings are 
     * set
     */
    public void validateSelectFromBindings()
    {
        if (! (bindingKeys().containsObject(SELECT_FROM_ARRAY_BINDING) || 
               bindingKeys().containsObject(SELECT_FROM_DICTIONARY_BINDING)))
        {
            throw new IllegalStateException("<" + getClass().getName() + 
                "> : One of " + SELECT_FROM_ARRAY_BINDING + " or " + 
                SELECT_FROM_DICTIONARY_BINDING + " is required.");
        }

        if ((bindingKeys().containsObject(SELECT_FROM_ARRAY_BINDING) && 
             bindingKeys().containsObject(SELECT_FROM_DICTIONARY_BINDING)))
        {
            throw new IllegalStateException("<" + getClass().getName() + 
                "> : Only one of " + SELECT_FROM_ARRAY_BINDING + " or " + 
                SELECT_FROM_DICTIONARY_BINDING + " can be set.");
        }
    }



   /**
     * Returns the value for the <code>selection</code> binding.
     * 
     * @return the value for the <code>parentSelection</code> binding
     * @exception IllegalStateException if this is not bound
     */
    public Object parentSelection() 
    {
        if (parentSelection == null)
        {
            if (! bindingKeys().containsObject(SELECTION_BINDING))
           {
               throw new IllegalStateException("<" + getClass().getName() + 
                   "> : " + SELECTION_BINDING + " binding is missing.");
           }
           parentSelection = valueForBinding(SELECTION_BINDING);
        }
        return parentSelection;
    }
    
    

    /**
     * Sets the value for the <code>selection</code> binding.
     * 
     * @param newSelection the new value for the <code>selection</code> binding
     * @exception IllegalStateException if this is not settable
     */
    public void setParentSelection(Object newSelection)
    {
        if (! canSetValueForBinding(SELECTION_BINDING))
        { 
            throw new IllegalStateException("<" + getClass().getName() + 
                "> : " + SELECTION_BINDING + " must not be bound to a constant.");
        }
       setValueForBinding(newSelection, SELECTION_BINDING);
    }

}