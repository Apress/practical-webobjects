package com.apress.practicalwo.practicalutilities;

import java.util.*;

import com.webobjects.eoaccess.*;
import com.webobjects.eocontrol.EOEnterpriseObject;
import com.webobjects.foundation.*;


/**
 * An exception that contains a message key path, which can be used to retrieve a localzed text message for display to the user.
 *
 * @author Chuck Hill and Sacha Mallais
 */
public class EOFValidationException extends com.webobjects.foundation.NSValidation.ValidationException
{
    protected Object failedValue;


    /**
     * Checks that a message key path is valid.
     *
     * @param messageKeyPath the message key path to check
     */
    public static boolean isValidMessageKeyPath(String messageKeyPath)
    {
        /** require [valid_param] messageKeyPath != null; **/
        return StringAdditions.isValidPropertyKeyPath(messageKeyPath);
    }



    /**
     * Constructs an exception with the same params as the superclass. <code>messageKeyPath</code> should be a valid failure key path.
     *
     * @param messageKeyPath the failure key path in the form of &lt;entity name&gt;.&lt;property key&gt;.&lt;failure key&gt;
     * @param object the EO object that failed to validate
     * @param propertyKey the attribute/relationship of <code>object</code> that failed validation
     */
    public EOFValidationException(String messageKeyPath, EOEnterpriseObject object, String propertyKey)
    {
        super(messageKeyPath, object, propertyKey);
        /** require
        [valid_messageKeyPath_param] messageKeyPath != null;
        [valid_message_keypath] isValidMessageKeyPath(messageKeyPath); **/
    }



    /**
     * Constructs an exception with just a message. <code>messageKeyPath</code> should be a valid failure key path.
     *
     * @param messageKeyPath the failure key path in the form of &lt;entity name&gt;.&lt;property key&gt;.&lt;failure key&gt;
     */
    public EOFValidationException(String messageKeyPath)
    {
        this(messageKeyPath, null, null);
        /** require
        [valid_messageKeyPath_param] messageKeyPath != null;
        [valid_message_keypath] isValidMessageKeyPath(messageKeyPath); **/
    }



    /**
     * Constructs the message key path using the EOAttribute and a failureKey.
     *
     * @param attribute the attribute that failed to validate
     * @param failureKey the key from EOFValidation that indicates the type of validation failure
     */
    public EOFValidationException(EOAttribute attribute, String failureKey, Object newFailedValue)
    {
        this(attribute.entity().name() + "." + attribute.name() + "." + failureKey);
        /** require
        [valid_attribute_param] attribute != null;
        [valid_failureKey_param] failureKey != null; **/

        failedValue = newFailedValue;
    }



    /**
     * Constructs the message key path using the EORelationship and a failureKey.
     *
     * @param relationship the relationship that failed to validate
     * @param failureKey the key from EOFValidation that indicates the type of validation failure
     */
    public EOFValidationException(EORelationship relationship, String failureKey, Object newFailedValue)
    {
        super(relationship.entity().name() + "." + relationship.name() + "." + failureKey);
        /** require
        [valid_relationship_param] relationship != null;
        [valid_failureKey_param] failureKey != null; **/

        failedValue = newFailedValue;
    }



    /**
     * Returns the entity name (the first part of the message key path).
     */
    public String entityName()
    {
        String firstPart = StringAdditions.objectKeyPathFromKeyPath(getMessage());
        if (StringAdditions.isValidPropertyKeyPath(firstPart))
        {
            firstPart = StringAdditions.objectKeyPathFromKeyPath(firstPart);
        }
        return firstPart;

        /** ensure [valid_result] Result != null; **/
    }


    /**
     * Returns the entity (from the first part of the message key path).
     *
     * @return the entity
     */
    public EOEntity entity()
    {
        return EOModelGroup.defaultGroup().entityNamed(entityName());

        /** ensure [valid_result] Result != null; **/
    }


    /**
     * Helper method for <code>propertyKey()</code> and <code>hasPropertyKey()</code>.
     *
     * @return the property key if one exists, null otherwise
     */
    public String findPropertyKey()
    {
        String middlePart = null;
        String firstPart = StringAdditions.objectKeyPathFromKeyPath(getMessage());
        if (StringAdditions.isValidPropertyKeyPath(firstPart))
        {
            middlePart = StringAdditions.propertyNameFromKeyPath(firstPart);
        }
        return middlePart;
    }


    /**
     * Returns <code>true</code> if the message key path has a property component.
     *
     * @return <code>true</code> if the message key path has a property component
     */
    public boolean hasPropertyKey()
    {
        return findPropertyKey() != null;
    }


    /**
     * Returns the property key (the middle part of the message key path).
     *
     * @return the property key
     */
    public String propertyKey()
    {
        /** require [has_property_key] hasPropertyKey(); **/

        return findPropertyKey();

        /** ensure [valid_result] Result != null; **/
    }


    /**
     * Returns <code>true</code> if the property key refers to an attribute.
     *
     * @return <code>true</code> if the property key refers to an attribute
     */
    public boolean propertyKeyRefersToAttribute()
    {
        /** require [has_property_key] hasPropertyKey(); **/

        return entity().attributeNamed(propertyKey()) != null;
    }


    /**
     * Returns the property key as an attribute.
     *
     * @return the property key as an attribute
     */
    public EOAttribute propertyKeyAsAttribute()
    {
        /** require
        [has_property_key] hasPropertyKey();
        [property_key_refers_to_attribute] propertyKeyRefersToAttribute(); **/

        return entity().attributeNamed(propertyKey());
    }


    /**
     * Returns the failure key (the last part of the message key path).
     */
    public String failureKey()
    {
        return StringAdditions.propertyNameFromKeyPath(getMessage());

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Sets the value that failed to validate.
     */
    public void setFailedValue(Object newFailedValue)
    {
        failedValue = newFailedValue;
    }


    /**
     * Returns the value that failed to validate.
     */
    public Object failedValue()
    {
        return failedValue;
    }


    
    /**
     * Returns a dictionary with keys used to substitute values in the localized error message.
     *
     * @return a dictionary with keys used to substitute values in the localized error message
     */
    protected NSDictionary substitutionDictionary()
    {
        NSMutableDictionary dictionary = new NSMutableDictionary();

        if (entity() != null)
        {
            dictionary.setObjectForKey(entity(), EOFValidation.EntityFailedOn);
            dictionary.setObjectForKey(EOEntityAdditions.displayNameForEntity(entity()), EOFValidation.EntityName);
        }
        else
        {
            dictionary.setObjectForKey(entityName(), EOFValidation.EntityName);
        }

        if (failedValue() != null)
        {
            dictionary.setObjectForKey(failedValue(), EOFValidation.FailedValue);
        }

        if (object() != null)
        {
            dictionary.setObjectForKey(object(), EOFValidation.ObjectFailedOn);
        }

        if (hasPropertyKey())
        {
            dictionary.setObjectForKey(EOEntityAdditions.displayNameForPropertyNamed(propertyKey(), entity()), EOFValidation.PropertyName);

            if (propertyKeyRefersToAttribute())
            {
                dictionary.setObjectForKey(propertyKeyAsAttribute(), EOFValidation.AttributeFailedOn);
            }
            // CHECKME not sure if we need the same for relationships...
        }

        return dictionary;

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Returns a localized message based on the message key path returned by getMessage().  Note that the localization is based on the <em>server's</em> locale, so this method is not appropriate for web apps.
     *
     * @see #getLocalizedMessage(NSArray)
     *
     * @return the localized message
     */
    public String getLocalizedMessage()
    {
        /** require [localized_message_exists] LocalizationEngine.localizedStringExists(entityName(), hasPropertyKey() ? propertyKey() : null, failureKey()); **/

        String propertyKey = hasPropertyKey() ? propertyKey() : null;
        String localizedTemplate = LocalizationEngine.localizedString(entityName(), propertyKey, failureKey());
        return TemplateSubstitution.substituteValuesInStringFromDictionary(localizedTemplate, substitutionDictionary());

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Returns an array of localized messages based on the message key path returned by getMessage() of this exception and any exceptions in this' <code>additionalExceptions()</code>.  Note that the localization is based on the <em>server's</em> locale, so this method is not appropriate for web apps.
     *
     * @see #getLocalizedMessage()
     *
     * @return an array of localized messages, one message per exception
     */
    public NSArray getLocalizedMessageForUnaggregatedExceptions()
    {
        NSMutableArray exceptionMessages = new NSMutableArray();
        Enumeration exceptions = unaggregateExceptions().objectEnumerator();
        while (exceptions.hasMoreElements())
        {
            EOFValidationException x = (EOFValidationException)exceptions.nextElement();
            exceptionMessages.addObject(x.getLocalizedMessage());
        }

        return exceptionMessages;

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Returns <code>true</code> if this exception is for the indicated type of validation failure on the named property.  This can be useful when implementing specific validation exception handling.
     *
     * @param propertyKey the name of the property to match for this failure. <code>null</code> matches when <code>propertyKey()</code> is <code>null</code>
     * @param failureKey the type of validation failure.  See EOFValidation
     * @return <code>true</code> if this exception equals the indicated type of validation failure on the named property
     */
    public boolean isExceptionForFailure(String propertyKey, String failureKey)
    {
        /** require
        [valid_failureKey_param] failureKey != null;
        [failureKey_is_a_valid_key] EOFValidation.setOfAllFailureKeys.containsObject(failureKey); **/

        boolean failureKeyMatches = failureKey().equals(failureKey);
        boolean propertyKeyMatches;

        if (hasPropertyKey())
        {
            propertyKeyMatches = propertyKey.equals(propertyKey());
        }
        else
        {
            propertyKeyMatches = propertyKey == null;
        }

        return failureKeyMatches && propertyKeyMatches;
    }



    /**
     * Helper method for <code>doesFailureExist</code> and <code>exceptionForFailure</code>.
     *
     * @param propertyKey the name of the property to match for this failure.
     * @param failureKey the type of validation failure.  See EOFValidation
     * @return <code>true</code> if this exception or any of it's additional exceptions equals the indicated type of validation failure on the named property
     */
    protected EOFValidationException findExceptionForFailure(String propertyKey, String failureKey)
    {
        /** require
        [valid_propertyKey_param] propertyKey != null;
        [valid_failureKey_param] failureKey != null;
        [failureKey_is_a_valid_key] EOFValidation.setOfAllFailureKeys.containsObject(failureKey); **/

        EOFValidationException exceptionForFailure = null;
        Enumeration exceptions = unaggregateExceptions().objectEnumerator();
        while (exceptions.hasMoreElements())
        {
            EOFValidationException subException = (EOFValidationException)exceptions.nextElement();
            if ((subException != null) && subException.isExceptionForFailure(propertyKey, failureKey))
            {
                exceptionForFailure = subException;
                break;
            }
        }
        
        return exceptionForFailure;
    }



    /**
     * Returns <code>true</code> if this exception, or any of the exceptions it contains equals the indicated type of validation failure on the named property.  This can be useful when implementing specific validation exception handling.  It determines this by checking to see if the parent exception or any of the additional exceptions return <code>true</code> for <code>isExceptionForFailure()</code>.
     *
     * @param propertyKey the name of the property to match for this failure.
     * @param failureKey the type of validation failure.  See EOFValidation
     * @return <code>true</code> if this exception or any of it's additional exceptions equals the indicated type of validation failure on the named property
     */
    public boolean doesFailureExist(String propertyKey, String failureKey)
    {
        /** require
        [valid_propertyKey_param] propertyKey != null;
        [valid_failureKey_param] failureKey != null;
        [failureKey_is_a_valid_key] EOFValidation.setOfAllFailureKeys.containsObject(failureKey); **/

        return findExceptionForFailure(propertyKey, failureKey) != null;
    }



    /**
     * Returns the exception for the indicated type of validation failure on the named property from either this exception, or any of its additional exceptions.  This can be useful when implementing specific validation exception handling.
     *
     * @param failureKey the type of validation failure.  See EOFValidation and EOFValidationException.
     * @param propertyName the name of the property to match for this failure.
     * @return the exception for the indicated type of validation failure on the named property from either this exception, or any of the exceptions under it's AdditionalExceptionsKey.
     */
    public EOFValidationException exceptionForFailure(String propertyKey, String failureKey)
    {
        /** require
        [valid_propertyKey_param] propertyKey != null;
        [valid_failureKey_param] failureKey != null;
        [failureKey_is_a_valid_key] EOFValidation.setOfAllFailureKeys.containsObject(failureKey);
        [failure_exists] doesFailureExist(propertyKey, failureKey); **/

        return findExceptionForFailure(propertyKey, failureKey);

        /** ensure [valid_result] Result != null; **/
    }



    /**
     * Returns an array of all the exceptions contained in <code>additionalExceptions()</code>, or just this exception if there are no additional exceptions.
     *
     * @return an array of all the exceptions
     */
    public NSArray unaggregateExceptions()
    {
        NSMutableArray subExceptions = new NSMutableArray(this);

        if (additionalExceptions() != null)
        {
            subExceptions.addObjectsFromArray(additionalExceptions());
        }

        return subExceptions;

        /** ensure [valid_result] Result != null; **/
    }



}
