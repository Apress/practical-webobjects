package com.apress.practicalwo.practicalutilities;

import com.webobjects.eoaccess.EOAttribute;
import com.webobjects.eoaccess.EOEntity;
import com.webobjects.eoaccess.EOModel;
import com.webobjects.eoaccess.EOModelGroup;
import com.webobjects.foundation.NSLog;
import com.webobjects.foundation.NSNotification;
import com.webobjects.foundation.NSNotificationCenter;
import com.webobjects.foundation.NSSelector;


/**
 * EOPrototypeSwitcher handles configuring the prototypes in the EOJDBCPrototypes 
 * entity for a single database at runtime.  It takes the settings to use from the 
 * entity named <code>dbPrototypesEntityName()</code> which must be in the same 
 * model as the EOJDBCPrototypes entity.  This same model restriction is to avoid 
 * references to entities in unloaded models as there is no control over the order
 * in which models get loaded.  Not all prototypes are updated.  Prototypes are 
 * matched by name, prototypes are skipped if there is no corresponding attribute 
 * in the database specific entity.<br> 
 * <br>
 * If you need to connect to more than one type of database you will need to 
 * segregate the prototype names in each database (according to domain <b>not</b>
 * database) and use one EOPrototypeSwitcher instance to handle each.<br>
 * <br>
 * EOPrototypeSwitcher can be installed as a notification handler catching the 
 * EOModelGroup.ModelAddedNotification.  It can also be used when enumerating over
 * EOModelGroup.defaultGroup().models() or other similar situations.
 * 
 * @author Chuck Hill and Sacha Mallais
 */
public class EOPrototypeSwitcher
{
    protected String dbPrototypesEntityName;



    /**
     * Constructs a new EOPrototypeSwitcher to switch the default EOJDBCPrototypes to
     * match those for databaseType.
     * 
     * @param databaseType the type or name of the database to take prototype configuration from
     */
    public EOPrototypeSwitcher(String databaseType)
    {
        super();
        /** require [valid_databaseType] databaseType != null;  **/
        
        dbPrototypesEntityName = "EO" + databaseType + "Prototypes";
    }

   
    
    /**
     * Installs this object as a listener for <code>EOModelGroup.ModelAddedNotification</code>
     * <code>handleModelAddedNotification()</code> will be called when this 
     * notification is received.
     */
    public void listenForAddedModels()
    {
        NSSelector modelAddedSelector = 
            new NSSelector("handleModelAddedNotification", new Class[] { NSNotification.class } );
        NSNotificationCenter.defaultCenter().
            addObserver(this, modelAddedSelector, EOModelGroup.ModelAddedNotification, null);
    }
    
    
    
    /**
     * The object in the notification is the model being added.  The model is 
     * extracted from this notification and passed to <code>updatePrototypes()</code>.
     *
     * @param aNotification notification of which EOModel is being added.
     */
    public void handleModelAddedNotification(NSNotification aNotification)
    {
        /** require [valid_param] aNotification != null; 
                    [is_model_added_notification] 
                        aNotification.name().equals(EOModelGroup.ModelAddedNotification);  **/

        EOModel theModel = (EOModel) aNotification.object();
        updatePrototypes(theModel);
    }


    
    /**
     * Updates the EOJDBCPrototypes entity in <code>aModel</code> if it is present.
     * Updates selected properties from attributes with the same name in the entity 
     * named dbPrototypesEntityName(). 
     * 
     * @param aModel the EOModel to check for the EOPrototypes entity
     * @exception IllegalStateException if EOJDBCPrototypes is found but no entity named
     * dbPrototypesEntityName() is found
     */
    public void updatePrototypes(EOModel aModel)
    {
        /** require [aModel_valid] aModel != null; **/
        
        EOEntity jdbcPrototypesEntity = aModel.entityNamed("EOJDBCPrototypes");
        EOEntity databasePrototypesEntity = aModel.entityNamed(dbPrototypesEntityName());
        
        // Validate model
        if (jdbcPrototypesEntity != null)
        {
            if (databasePrototypesEntity == null)
            {
                throw new IllegalStateException("Found EOJDBCPrototypes in model " +
                    aModel.name() + " but did not find database entity named " + 
                    databasePrototypesEntity.name());
            }
            else
            {
                if (NSLog.debugLoggingAllowedForLevel(NSLog.DebugLevelDetailed))
                {
                    NSLog.debug.appendln("Updating EOJDBCPrototypes with configuration from " + 
                        dbPrototypesEntityName + " in model " + aModel.name());
                }
                
                for (int i = 0; i < jdbcPrototypesEntity.attributes().count(); i++)
                {
                    EOAttribute jdbcPrototype = 
                        (EOAttribute)jdbcPrototypesEntity.attributes().objectAtIndex(i);
                    String prototypesName = (String)jdbcPrototype.name();
                    EOAttribute dbPrototype = 
                        (EOAttribute)databasePrototypesEntity.attributeNamed(prototypesName);
                    if (dbPrototype != null)
                    {
                        jdbcPrototype.setDefinition(dbPrototype.definition());
                        jdbcPrototype.setExternalType(dbPrototype.externalType()); 
                        jdbcPrototype.setPrecision(dbPrototype.precision()); 
                        jdbcPrototype.setReadFormat(dbPrototype.readFormat()); 
                        jdbcPrototype.setScale(dbPrototype.scale()); 
                        jdbcPrototype.setUserInfo(dbPrototype.userInfo()); 
                        jdbcPrototype.setValueType(dbPrototype.valueType()); 
                        jdbcPrototype.setWidth(dbPrototype.width()); 
                        jdbcPrototype.setWriteFormat(dbPrototype.writeFormat());
                    }
                }
            }
        }
        
        /** ensure [prototpes_updated] /# All the prototypes in EOJDBCPrototypes
         which have matching prototypes in the database specific prototypes have
         been updated.#/ true; **/
    }
    
    
    
    /**
     * Returns the name of the entity (formed as EO<databaseType>Prototypes ) that 
     * the EOJDBCPrototypes entity should be updated from. 
     * 
     * @return the name of the entity that the EOJDBCPrototypes entity should be 
     * updated from
     */
    public String dbPrototypesEntityName()
    {
        return dbPrototypesEntityName;
    }
    
    
    /** invariant [has_dbPrototypesEntityName] dbPrototypesEntityName != null;  **/
    
}
