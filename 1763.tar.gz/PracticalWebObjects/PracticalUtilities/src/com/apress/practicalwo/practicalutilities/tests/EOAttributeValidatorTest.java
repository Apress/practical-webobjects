package com.apress.practicalwo.practicalutilities.tests;

import java.math.BigDecimal;

import com.apress.practicalwo.practicalutilities.*;

import com.webobjects.eoaccess.*;
import com.webobjects.foundation.*;


/**
 * Tests for EOAttributeValidator
 *
 * @author Copyright (c) 2001-2  Global Village Consulting, Inc.  All rights reserved.
 * @version $Revision: 2$
 */
public class EOAttributeValidatorTest extends EOTestCase
{
    protected EOEntity entity;
    protected EOAttribute stringAttribute;
    protected EOAttribute decimalAttribute;
    protected EOAttribute booleanAttribute;


    /**
     * Designated constuctor.
     */
    public EOAttributeValidatorTest(String name)
    {
        super(name);
    }



    /**
     * Common test code.
     */
    public void setUp() throws java.lang.Exception
    {
        super.setUp();
        entity = EOModelGroup.defaultGroup().entityNamed("AttributeValidationTestEntity");
        stringAttribute = entity.attributeNamed("requiredString");
        decimalAttribute = entity.attributeNamed("requiredDecimalNumber");
        booleanAttribute = entity.attributeNamed("requiredBoolean");
    }



    /**
     * Tests checkTypeCompatibility
     */
    public void testcheckTypeCompatibility()
    {
        try
        {
            EOAttributeValidator.checkTypeCompatibility("test string", null);
            fail("DBC not correct");
        }
        catch (RuntimeException x) { }

        try { EOAttributeValidator.checkTypeCompatibility("test string", stringAttribute); }
        catch (EOFValidationException e) { fail("correct class failed type compatibility check"); }

        try { EOAttributeValidator.checkTypeCompatibility(new BigDecimal(".3333"), decimalAttribute); }
        catch (EOFValidationException e) { fail("correct sub-class failed type compatibility check"); }

        try { EOAttributeValidator.checkTypeCompatibility(null, stringAttribute); }
        catch (EOFValidationException e) {fail("null value failed type compatibility check"); }

        try { EOAttributeValidator.checkTypeCompatibility(NSKeyValueCoding.NullValue, stringAttribute); }
        catch (EOFValidationException e) {fail("EONullValue failed type compatibility check"); }

        try
        {
            EOAttributeValidator.checkTypeCompatibility("17", decimalAttribute);
            fail("Accepted string for decimal.");
        }
        catch (EOFValidationException e)
        {
            assertEquals("Dictionary contains correct attribute", e.propertyKey(), decimalAttribute.name());
            assertEquals("Dictionary contains correct invalid value", e.failedValue(), "17");
            assertEquals("Dictionary contains correct validation failure", e.failureKey(), EOFValidation.InvalidValue);
        }
    }



    /**
     * Tests for  checkNullity
     */
    public void testcheckNullity()
    {
        try
        {
            EOAttributeValidator.checkNullity(null, null);
            fail("DBC not correct");
        }
        catch (RuntimeException x) { }

        try { EOAttributeValidator.checkNullity(null, entity.attributeNamed("optionalString")); }
        catch (EOFValidationException e) { fail("null check failed for nullable attribute"); }

        try { EOAttributeValidator.checkNullity(null, entity.attributeNamed("optionalString")); }
        catch (EOFValidationException e) { fail("null check failed for nullable attribute"); }

        try { EOAttributeValidator.checkNullity(null, entity.attributeNamed("theID")); }
        catch (EOFValidationException e) { fail("null check failed for PK"); }

        try
        {
            EOAttributeValidator.checkNullity(NSKeyValueCoding.NullValue, stringAttribute);
            fail("Allowed null for not null attribute");
        }
        catch (EOFValidationException e)
        {
            assertEquals("Dictionary contains incorrect attribute", e.propertyKey(), stringAttribute.name());
            assertEquals("Dictionary contains incorrect invalid value", e.failedValue(), NSKeyValueCoding.NullValue);
            assertEquals("Dictionary contains incorrect validation failure", e.failureKey(), EOFValidation.NullNotAllowed);
        }

        try
        {
            EOAttributeValidator.checkNullity(NSKeyValueCoding.NullValue, stringAttribute);
            fail("Allowed EONullValue.nullValue() for not null attribute");
        }
        catch (EOFValidationException e) {}
    }



    /**
     * Tests for checkWidth
     */
    public void testcheckWidth() 
    {
        try
        {
            EOAttributeValidator.checkWidth("123", null);
            fail("null attribute precondition not detected");
        }
        catch (RuntimeException x) { }

        try
        {
            EOAttributeValidator.checkWidth(null, stringAttribute);
            fail("null value precondition not detected");
        }
        catch (RuntimeException x) { }

        try { EOAttributeValidator.checkWidth("0123456789", entity.attributeNamed("shortString")); }
        catch (EOFValidationException e) { fail("too long check failed for OK string"); }

        try { EOAttributeValidator.checkWidth("0123456789", entity.attributeNamed("shortData")); }
        catch (EOFValidationException e) { fail("too long check failed for OK data"); }

        try { EOAttributeValidator.checkWidth(new Integer(1), entity.attributeNamed("requiredInteger")); }
        catch (EOFValidationException e) { fail("too long check failed for requiredInteger"); }

        try
        {
            EOAttributeValidator.checkWidth("0123456789X", entity.attributeNamed("shortString"));
            fail("too long check failed for long string"); 
        }
        catch (EOFValidationException e) { }

        try
        {
            EOAttributeValidator.checkWidth("0123456789X", entity.attributeNamed("shortData"));
            fail("too long check failed for long data");
        }
        catch (EOFValidationException e)
        {
            assertEquals("Dictionary contains incorrect attribute", e.propertyKey(), entity.attributeNamed("shortData").name());
            assertEquals("Dictionary contains incorrect invalid value", e.failedValue(), "0123456789X");
            assertEquals("Dictionary contains incorrect validation failure", e.failureKey(), EOFValidation.TooLong);
        }
   }



    /**
     * Test for isGeneratedPrimaryKey
     */
    public void testIsGeneratedPrimaryKey()
    {
        try
        {
            EOAttributeValidator.isGeneratedPrimaryKey(null);
            fail("DBC not correct");
        }
        catch (RuntimeException r) {}

        assertTrue("Integer PK key improperly detected", EOAttributeValidator.isGeneratedPrimaryKey(entity.attributeNamed("theID")));

        assertTrue("Decimal PK key improperly detected", EOAttributeValidator.isGeneratedPrimaryKey(EOModelGroup.defaultGroup().entityNamed("EntityWithDecimalPK").attributeNamed("theDecimalPK")));

        assertTrue("NSData non-PK attribute improperly detected", ! EOAttributeValidator.isGeneratedPrimaryKey(EOModelGroup.defaultGroup().entityNamed("EntityWithDecimalPK").attributeNamed("dataAttribute")));

        assertTrue("Integer non-PK attribute improperly detected", ! EOAttributeValidator.isGeneratedPrimaryKey(entity.attributeNamed("requiredInteger")));
    }



    /**
     * Tests for classForAttribute
     */
    public void testClassForAttribute()
    {
        try
        {
            EOAttributeValidator.classForAttribute(null);
            fail("DBC not correct");
        }
        catch (RuntimeException r) {}

       assertEquals("NSString not translated", EOAttributeValidator.classForAttribute(entity.attributeNamed("requiredString")), String.class);

       assertEquals("NSData not translated", EOAttributeValidator.classForAttribute(entity.attributeNamed("requiredData")), NSData.class);

       assertEquals("NSNumber from integer not translated", EOAttributeValidator.classForAttribute(entity.attributeNamed("requiredInteger")), Number.class);

       assertEquals("NSDecimalNumber not translated", EOAttributeValidator.classForAttribute(entity.attributeNamed("requiredDecimalNumber")), BigDecimal.class);

       assertEquals("NSCalendarDate not translated", EOAttributeValidator.classForAttribute(entity.attributeNamed("requiredTimestamp")), NSTimestamp.class);
    }



    /**
     * Tests for displayNameForAttribute
     */
    public void testDisplayNameForAttribute()
    {
        try
        {
            EOAttributeValidator.displayNameForAttribute(null);
            fail("DBC not correct");
        }
        catch (RuntimeException r) { }

        assertEquals("Custom display name not found", EOAttributeValidator.displayNameForAttribute(stringAttribute), "mandatory string");

        assertEquals("Display name not created", EOAttributeValidator.displayNameForAttribute(entity.attributeNamed("optionalString")), "optional string");
    }



}
