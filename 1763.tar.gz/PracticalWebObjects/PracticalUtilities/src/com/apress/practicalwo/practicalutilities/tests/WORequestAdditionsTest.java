package com.apress.practicalwo.practicalutilities.tests;

import junit.framework.TestCase;

/**
 *
 * @author Charles Hill and Sacha Mallais
 */
public class WORequestAdditionsTest extends TestCase
{

	/**
	 * Constructor for WORequestAdditionsTest.
	 * @param name test name
	 */
	public WORequestAdditionsTest(String name)
	{
		super(name);
	}
    
    

    protected void setUp() throws Exception
    {
        super.setUp();
    }



    /**
     * No tests for this, depends on wo adaptor and web server.
     *
     */public void testIsSecure()
    {
    }



    protected void tearDown() throws Exception
    {
        super.tearDown();
    }


}
