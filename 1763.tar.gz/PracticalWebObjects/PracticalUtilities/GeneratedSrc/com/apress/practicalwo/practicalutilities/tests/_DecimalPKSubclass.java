package com.apress.practicalwo.practicalutilities.tests;


import com.webobjects.foundation.NSData;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to DecimalPKSubclass.java instead.
 *
 * @author author  Copyright (c) 2003
 */  
public abstract class _DecimalPKSubclass extends com.apress.practicalwo.practicalutilities.tests.EntityWithDecimalPK 
{


    public static final String SUBCLASSDATA = "subClassData";
    public static final String THEDECIMALPK = "theDecimalPK";
    public static final String DATAATTRIBUTE = "dataAttribute";


    public NSData subClassData() 
    {
        return (NSData)storedValueForKey("subClassData");
    }



    public void setSubClassData(NSData aValue) 
    {
        takeStoredValueForKey(aValue, "subClassData");
    }



}
