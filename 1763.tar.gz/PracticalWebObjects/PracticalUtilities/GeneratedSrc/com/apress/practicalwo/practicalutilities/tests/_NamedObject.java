package com.apress.practicalwo.practicalutilities.tests;


import com.webobjects.eocontrol.*;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to NamedObject.java instead.
 *
 * @author author  Copyright (c) 2003
 */  
public abstract class _NamedObject extends EOGenericRecord 
{


    public static final String COOPERATINGEDITINGCONTEXTTESTOBJECT = "cooperatingEditingContextTestObject";
    public static final String NAME = "name";


    public String name() 
    {
        return (String)storedValueForKey("name");
    }



    public void setName(String aValue) 
    {
        takeStoredValueForKey(aValue, "name");
    }




    public com.apress.practicalwo.practicalutilities.tests.CooperatingEditingContextTestObject cooperatingEditingContextTestObject() 
    {
        return (com.apress.practicalwo.practicalutilities.tests.CooperatingEditingContextTestObject)storedValueForKey("cooperatingEditingContextTestObject");
    }



    public void setCooperatingEditingContextTestObject(com.apress.practicalwo.practicalutilities.tests.CooperatingEditingContextTestObject aValue) 
    {
        /** require [same_ec] 
            (aValue == null) ||
            ((aValue.editingContext() instanceof EOSharedEditingContext) ||
            (aValue.editingContext() == editingContext()) ); 
         **/

        takeStoredValueForKey(aValue, "cooperatingEditingContextTestObject");
    }



}
