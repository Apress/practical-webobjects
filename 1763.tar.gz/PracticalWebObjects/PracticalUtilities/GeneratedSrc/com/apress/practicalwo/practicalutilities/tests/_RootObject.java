package com.apress.practicalwo.practicalutilities.tests;


import com.webobjects.foundation.*;
import com.webobjects.eocontrol.*;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to RootObject.java instead.
 *
 * @author author  Copyright (c) 2003
 */  
public abstract class _RootObject extends com.apress.practicalwo.practicalutilities.CopyableGenericRecord 
{


    public static final String AVALUE = "aValue";
    public static final String OID = "oid";
    public static final String UNOWNEDOBJECTS = "unOwnedObjects";
    public static final String OWNEDOBJECTS = "ownedObjects";
    public static final String NAME = "name";


    public String name() 
    {
        return (String)storedValueForKey("name");
    }



    public void setName(String aValue) 
    {
        takeStoredValueForKey(aValue, "name");
    }




    public Number oid() 
    {
        return (Number)storedValueForKey("oid");
    }



    public void setOid(Number aValue) 
    {
        takeStoredValueForKey(aValue, "oid");
    }




    public Number aValue() 
    {
        return (Number)storedValueForKey("aValue");
    }



    public void setAValue(Number aValue) 
    {
        takeStoredValueForKey(aValue, "aValue");
    }




    public NSArray ownedObjects() 
    {
        return (NSArray)storedValueForKey("ownedObjects");
    }



    public void setOwnedObjects(NSMutableArray newValues) 
    {
        /** require [same_ec] (forall i : {0 .. newValues.count() - 1} # 
            ((EOEnterpriseObject)newValues.objectAtIndex(i)).editingContext() == editingContext());  **/

        takeStoredValueForKey(newValues, "ownedObjects");
    }



    public void addToOwnedObjects(com.apress.practicalwo.practicalutilities.tests.OwnedObject object) 
    {
        /** require [same_ec] 
            object.editingContext() instanceof EOSharedEditingContext ||
            object.editingContext() == editingContext(); 
         **/

        NSMutableArray array = (NSMutableArray)ownedObjects();
        willChange();
        array.addObject(object);
    }



    public void removeFromOwnedObjects(com.apress.practicalwo.practicalutilities.tests.OwnedObject object) 
    {
        NSMutableArray array = (NSMutableArray)ownedObjects();

        willChange();
        array.removeObject(object);
    }




    public NSArray unOwnedObjects() 
    {
        return (NSArray)storedValueForKey("unOwnedObjects");
    }



    public void setUnOwnedObjects(NSMutableArray newValues) 
    {
        /** require [same_ec] (forall i : {0 .. newValues.count() - 1} # 
            ((EOEnterpriseObject)newValues.objectAtIndex(i)).editingContext() == editingContext());  **/

        takeStoredValueForKey(newValues, "unOwnedObjects");
    }



    public void addToUnOwnedObjects(com.apress.practicalwo.practicalutilities.tests.UnOwnedObject object) 
    {
        /** require [same_ec] 
            object.editingContext() instanceof EOSharedEditingContext ||
            object.editingContext() == editingContext(); 
         **/

        NSMutableArray array = (NSMutableArray)unOwnedObjects();
        willChange();
        array.addObject(object);
    }



    public void removeFromUnOwnedObjects(com.apress.practicalwo.practicalutilities.tests.UnOwnedObject object) 
    {
        NSMutableArray array = (NSMutableArray)unOwnedObjects();

        willChange();
        array.removeObject(object);
    }



}
