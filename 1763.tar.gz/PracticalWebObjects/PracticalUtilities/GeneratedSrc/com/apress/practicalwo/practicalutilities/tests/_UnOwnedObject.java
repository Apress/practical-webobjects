package com.apress.practicalwo.practicalutilities.tests;


import com.webobjects.foundation.*;
import com.webobjects.eocontrol.*;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to UnOwnedObject.java instead.
 *
 * @author author  Copyright (c) 2003
 */  
public abstract class _UnOwnedObject extends com.apress.practicalwo.practicalutilities.CopyableGenericRecord 
{


    public static final String ROOTOBJECTS = "rootObjects";
    public static final String NAME = "name";


    public String name() 
    {
        return (String)storedValueForKey("name");
    }



    public void setName(String aValue) 
    {
        takeStoredValueForKey(aValue, "name");
    }




    public NSArray rootObjects() 
    {
        return (NSArray)storedValueForKey("rootObjects");
    }



    public void setRootObjects(NSMutableArray newValues) 
    {
        /** require [same_ec] (forall i : {0 .. newValues.count() - 1} # 
            ((EOEnterpriseObject)newValues.objectAtIndex(i)).editingContext() == editingContext());  **/

        takeStoredValueForKey(newValues, "rootObjects");
    }



    public void addToRootObjects(com.apress.practicalwo.practicalutilities.tests.RootObject object) 
    {
        /** require [same_ec] 
            object.editingContext() instanceof EOSharedEditingContext ||
            object.editingContext() == editingContext(); 
         **/

        NSMutableArray array = (NSMutableArray)rootObjects();
        willChange();
        array.addObject(object);
    }



    public void removeFromRootObjects(com.apress.practicalwo.practicalutilities.tests.RootObject object) 
    {
        NSMutableArray array = (NSMutableArray)rootObjects();

        willChange();
        array.removeObject(object);
    }



}
