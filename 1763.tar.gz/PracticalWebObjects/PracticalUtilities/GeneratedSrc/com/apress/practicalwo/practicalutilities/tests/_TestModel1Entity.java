package com.apress.practicalwo.practicalutilities.tests;


import com.webobjects.eocontrol.EOGenericRecord;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to TestModel1Entity.java instead.
 *
 * @author author  Copyright (c) 2003
 */  
public abstract class _TestModel1Entity extends EOGenericRecord 
{


    public static final String NAME = "name";


    public String name() 
    {
        return (String)storedValueForKey("name");
    }



    public void setName(String aValue) 
    {
        takeStoredValueForKey(aValue, "name");
    }



}
