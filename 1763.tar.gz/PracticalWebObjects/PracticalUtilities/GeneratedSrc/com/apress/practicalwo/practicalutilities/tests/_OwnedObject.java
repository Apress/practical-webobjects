package com.apress.practicalwo.practicalutilities.tests;

import com.webobjects.eocontrol.EOSharedEditingContext;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to OwnedObject.java instead.
 *
 * @author author  Copyright (c) 2003
 */  
public abstract class _OwnedObject extends com.apress.practicalwo.practicalutilities.CopyableGenericRecord 
{


    public static final String ROOTOBJECT = "rootObject";
    public static final String NAME = "name";


    public String name() 
    {
        return (String)storedValueForKey("name");
    }



    public void setName(String aValue) 
    {
        takeStoredValueForKey(aValue, "name");
    }




    public com.apress.practicalwo.practicalutilities.tests.RootObject rootObject() 
    {
        return (com.apress.practicalwo.practicalutilities.tests.RootObject)storedValueForKey("rootObject");
    }



    public void setRootObject(com.apress.practicalwo.practicalutilities.tests.RootObject aValue) 
    {
        /** require [same_ec] 
            (aValue == null) ||
            ((aValue.editingContext() instanceof EOSharedEditingContext) ||
            (aValue.editingContext() == editingContext()) ); 
         **/

        takeStoredValueForKey(aValue, "rootObject");
    }



}
