package com.apress.practicalwo.practicalutilities.tests;


import java.math.BigDecimal;

import com.webobjects.foundation.NSData;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to EntityWithDecimalPK.java instead.
 *
 * @author author  Copyright (c) 2003
 */  
public abstract class _EntityWithDecimalPK extends com.apress.practicalwo.practicalutilities.CopyableGenericRecord 
{


    public static final String DATAATTRIBUTE = "dataAttribute";
    public static final String THEDECIMALPK = "theDecimalPK";


    public BigDecimal theDecimalPK() 
    {
        return (BigDecimal)storedValueForKey("theDecimalPK");
    }



    public void setTheDecimalPK(BigDecimal aValue) 
    {
        takeStoredValueForKey(aValue, "theDecimalPK");
    }




    public NSData dataAttribute() 
    {
        return (NSData)storedValueForKey("dataAttribute");
    }



    public void setDataAttribute(NSData aValue) 
    {
        takeStoredValueForKey(aValue, "dataAttribute");
    }



}
