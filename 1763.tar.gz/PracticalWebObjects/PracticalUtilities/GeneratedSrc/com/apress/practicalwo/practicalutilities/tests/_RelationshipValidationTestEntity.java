package com.apress.practicalwo.practicalutilities.tests;


import com.webobjects.foundation.*;
import com.webobjects.eocontrol.*;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to RelationshipValidationTestEntity.java instead.
 *
 * @author author  Copyright (c) 2003
 */  
public abstract class _RelationshipValidationTestEntity extends com.apress.practicalwo.practicalutilities.CopyableGenericRecord 
{


    public static final String REQUIREDBAREENTITIES = "requiredBareEntities";
    public static final String OPTIONALDECIMALENTITIES = "optionalDecimalEntities";
    public static final String REQUIREDBAREENTITY = "requiredBareEntity";
    public static final String RELATIONSHIPTODECIMALS = "relationshipToDecimals";
    public static final String OPTIONALDECIMALENTITY = "optionalDecimalEntity";
    public static final String BAREENTITYRELATIONSHIPS = "bareEntityRelationships";
    public static final String THEID = "theID";


    public Number theID() 
    {
        return (Number)storedValueForKey("theID");
    }



    public void setTheID(Number aValue) 
    {
        takeStoredValueForKey(aValue, "theID");
    }




    public com.apress.practicalwo.practicalutilities.tests.EntityWithDecimalPK optionalDecimalEntity() 
    {
        return (com.apress.practicalwo.practicalutilities.tests.EntityWithDecimalPK)storedValueForKey("optionalDecimalEntity");
    }



    public void setOptionalDecimalEntity(com.apress.practicalwo.practicalutilities.tests.EntityWithDecimalPK aValue) 
    {
        /** require [same_ec] 
            (aValue == null) ||
            ((aValue.editingContext() instanceof EOSharedEditingContext) ||
            (aValue.editingContext() == editingContext()) ); 
         **/

        takeStoredValueForKey(aValue, "optionalDecimalEntity");
    }




    public com.apress.practicalwo.practicalutilities.tests.ValidationBareEntity requiredBareEntity() 
    {
        return (com.apress.practicalwo.practicalutilities.tests.ValidationBareEntity)storedValueForKey("requiredBareEntity");
    }



    public void setRequiredBareEntity(com.apress.practicalwo.practicalutilities.tests.ValidationBareEntity aValue) 
    {
        /** require [same_ec] 
            (aValue == null) ||
            ((aValue.editingContext() instanceof EOSharedEditingContext) ||
            (aValue.editingContext() == editingContext()) ); 
         **/

        takeStoredValueForKey(aValue, "requiredBareEntity");
    }




    public NSArray bareEntityRelationships() 
    {
        return (NSArray)storedValueForKey("bareEntityRelationships");
    }



    public void setBareEntityRelationships(NSMutableArray newValues) 
    {
        /** require [same_ec] (forall i : {0 .. newValues.count() - 1} # 
            ((EOEnterpriseObject)newValues.objectAtIndex(i)).editingContext() == editingContext());  **/

        takeStoredValueForKey(newValues, "bareEntityRelationships");
    }



    public void addToBareEntityRelationships(EOEnterpriseObject object) 
    {
        /** require [same_ec] 
            object.editingContext() instanceof EOSharedEditingContext ||
            object.editingContext() == editingContext(); 
         **/

        NSMutableArray array = (NSMutableArray)bareEntityRelationships();
        willChange();
        array.addObject(object);
    }



    public void removeFromBareEntityRelationships(EOEnterpriseObject object) 
    {
        NSMutableArray array = (NSMutableArray)bareEntityRelationships();

        willChange();
        array.removeObject(object);
    }




    public NSArray relationshipToDecimals() 
    {
        return (NSArray)storedValueForKey("relationshipToDecimals");
    }



    public void setRelationshipToDecimals(NSMutableArray newValues) 
    {
        /** require [same_ec] (forall i : {0 .. newValues.count() - 1} # 
            ((EOEnterpriseObject)newValues.objectAtIndex(i)).editingContext() == editingContext());  **/

        takeStoredValueForKey(newValues, "relationshipToDecimals");
    }



    public void addToRelationshipToDecimals(EOEnterpriseObject object) 
    {
        /** require [same_ec] 
            object.editingContext() instanceof EOSharedEditingContext ||
            object.editingContext() == editingContext(); 
         **/

        NSMutableArray array = (NSMutableArray)relationshipToDecimals();
        willChange();
        array.addObject(object);
    }



    public void removeFromRelationshipToDecimals(EOEnterpriseObject object) 
    {
        NSMutableArray array = (NSMutableArray)relationshipToDecimals();

        willChange();
        array.removeObject(object);
    }




    public NSArray optionalDecimalEntities() 
    {
        return (NSArray)storedValueForKey("optionalDecimalEntities");
    }



    public void setOptionalDecimalEntities(NSMutableArray newValues) 
    {
        /** require [same_ec] (forall i : {0 .. newValues.count() - 1} # 
            ((EOEnterpriseObject)newValues.objectAtIndex(i)).editingContext() == editingContext());  **/

        takeStoredValueForKey(newValues, "optionalDecimalEntities");
    }



    public void addToOptionalDecimalEntities(com.apress.practicalwo.practicalutilities.tests.EntityWithDecimalPK object) 
    {
        /** require [same_ec] 
            object.editingContext() instanceof EOSharedEditingContext ||
            object.editingContext() == editingContext(); 
         **/

        NSMutableArray array = (NSMutableArray)optionalDecimalEntities();
        willChange();
        array.addObject(object);
    }



    public void removeFromOptionalDecimalEntities(com.apress.practicalwo.practicalutilities.tests.EntityWithDecimalPK object) 
    {
        NSMutableArray array = (NSMutableArray)optionalDecimalEntities();

        willChange();
        array.removeObject(object);
    }




    public NSArray requiredBareEntities() 
    {
        return (NSArray)storedValueForKey("requiredBareEntities");
    }



    public void setRequiredBareEntities(NSMutableArray newValues) 
    {
        /** require [same_ec] (forall i : {0 .. newValues.count() - 1} # 
            ((EOEnterpriseObject)newValues.objectAtIndex(i)).editingContext() == editingContext());  **/

        takeStoredValueForKey(newValues, "requiredBareEntities");
    }



    public void addToRequiredBareEntities(com.apress.practicalwo.practicalutilities.tests.ValidationBareEntity object) 
    {
        /** require [same_ec] 
            object.editingContext() instanceof EOSharedEditingContext ||
            object.editingContext() == editingContext(); 
         **/

        NSMutableArray array = (NSMutableArray)requiredBareEntities();
        willChange();
        array.addObject(object);
    }



    public void removeFromRequiredBareEntities(com.apress.practicalwo.practicalutilities.tests.ValidationBareEntity object) 
    {
        NSMutableArray array = (NSMutableArray)requiredBareEntities();

        willChange();
        array.removeObject(object);
    }



}
