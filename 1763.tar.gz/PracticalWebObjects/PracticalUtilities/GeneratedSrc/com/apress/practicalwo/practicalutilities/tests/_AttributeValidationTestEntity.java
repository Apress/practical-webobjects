package com.apress.practicalwo.practicalutilities.tests;


import java.math.BigDecimal;

import com.webobjects.foundation.*;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to AttributeValidationTestEntity.java instead.
 *
 * @author author  Copyright (c) 2003
 */  
public abstract class _AttributeValidationTestEntity extends com.apress.practicalwo.practicalutilities.CopyableGenericRecord 
{


    public static final String OPTIONALBOOLEAN = "optionalBoolean";
    public static final String REQUIREDBOOLEAN = "requiredBoolean";
    public static final String SHORTSTRING = "shortString";
    public static final String SHORTDATA = "shortData";
    public static final String THEID = "theID";
    public static final String OPTIONALINTEGER = "optionalInteger";
    public static final String OPTIONALDECIMALNUMBER = "optionalDecimalNumber";
    public static final String REQUIREDDATA = "requiredData";
    public static final String OPTIONALTIMESTAMP = "optionalTimestamp";
    public static final String OPTIONALMEMO = "optionalMemo";
    public static final String OPTIONALSTRING = "optionalString";
    public static final String REQUIREDDECIMALNUMBER = "requiredDecimalNumber";
    public static final String REQUIREDINTEGER = "requiredInteger";
    public static final String REQUIREDTIMESTAMP = "requiredTimestamp";
    public static final String REQUIREDMEMO = "requiredMemo";
    public static final String REQUIREDSTRING = "requiredString";


    public String requiredString() 
    {
        return (String)storedValueForKey("requiredString");
    }



    public void setRequiredString(String aValue) 
    {
        takeStoredValueForKey(aValue, "requiredString");
    }




    public String requiredMemo() 
    {
        return (String)storedValueForKey("requiredMemo");
    }



    public void setRequiredMemo(String aValue) 
    {
        takeStoredValueForKey(aValue, "requiredMemo");
    }




    public NSTimestamp requiredTimestamp() 
    {
        return (NSTimestamp)storedValueForKey("requiredTimestamp");
    }



    public void setRequiredTimestamp(NSTimestamp aValue) 
    {
        takeStoredValueForKey(aValue, "requiredTimestamp");
    }




    public Number requiredInteger() 
    {
        return (Number)storedValueForKey("requiredInteger");
    }



    public void setRequiredInteger(Number aValue) 
    {
        takeStoredValueForKey(aValue, "requiredInteger");
    }




    public BigDecimal requiredDecimalNumber() 
    {
        return (BigDecimal)storedValueForKey("requiredDecimalNumber");
    }



    public void setRequiredDecimalNumber(BigDecimal aValue) 
    {
        takeStoredValueForKey(aValue, "requiredDecimalNumber");
    }




    public String optionalString() 
    {
        return (String)storedValueForKey("optionalString");
    }



    public void setOptionalString(String aValue) 
    {
        takeStoredValueForKey(aValue, "optionalString");
    }




    public String optionalMemo() 
    {
        return (String)storedValueForKey("optionalMemo");
    }



    public void setOptionalMemo(String aValue) 
    {
        takeStoredValueForKey(aValue, "optionalMemo");
    }




    public NSTimestamp optionalTimestamp() 
    {
        return (NSTimestamp)storedValueForKey("optionalTimestamp");
    }



    public void setOptionalTimestamp(NSTimestamp aValue) 
    {
        takeStoredValueForKey(aValue, "optionalTimestamp");
    }




    public NSData requiredData() 
    {
        return (NSData)storedValueForKey("requiredData");
    }



    public void setRequiredData(NSData aValue) 
    {
        takeStoredValueForKey(aValue, "requiredData");
    }




    public BigDecimal optionalDecimalNumber() 
    {
        return (BigDecimal)storedValueForKey("optionalDecimalNumber");
    }



    public void setOptionalDecimalNumber(BigDecimal aValue) 
    {
        takeStoredValueForKey(aValue, "optionalDecimalNumber");
    }




    public Number optionalInteger() 
    {
        return (Number)storedValueForKey("optionalInteger");
    }



    public void setOptionalInteger(Number aValue) 
    {
        takeStoredValueForKey(aValue, "optionalInteger");
    }




    public Number theID() 
    {
        return (Number)storedValueForKey("theID");
    }



    public void setTheID(Number aValue) 
    {
        takeStoredValueForKey(aValue, "theID");
    }




    public NSData shortData() 
    {
        return (NSData)storedValueForKey("shortData");
    }



    public void setShortData(NSData aValue) 
    {
        takeStoredValueForKey(aValue, "shortData");
    }




    public String shortString() 
    {
        return (String)storedValueForKey("shortString");
    }



    public void setShortString(String aValue) 
    {
        takeStoredValueForKey(aValue, "shortString");
    }




    public Number requiredBoolean() 
    {
        return (Number)storedValueForKey("requiredBoolean");
    }



    public void setRequiredBoolean(Number aValue) 
    {
        takeStoredValueForKey(aValue, "requiredBoolean");
    }




    public Number optionalBoolean() 
    {
        return (Number)storedValueForKey("optionalBoolean");
    }



    public void setOptionalBoolean(Number aValue) 
    {
        takeStoredValueForKey(aValue, "optionalBoolean");
    }



}
