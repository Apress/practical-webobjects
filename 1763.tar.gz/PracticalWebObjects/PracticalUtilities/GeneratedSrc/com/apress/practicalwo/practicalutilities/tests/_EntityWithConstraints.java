package com.apress.practicalwo.practicalutilities.tests;


import java.math.BigDecimal;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to EntityWithConstraints.java instead.
 *
 * @author author  Copyright (c) 2003
 */  
public abstract class _EntityWithConstraints extends com.apress.practicalwo.practicalutilities.CopyableGenericRecord 
{


    public static final String QUANTITY = "quantity";


    public BigDecimal quantity() 
    {
        return (BigDecimal)storedValueForKey("quantity");
    }



    public void setQuantity(BigDecimal aValue) 
    {
        takeStoredValueForKey(aValue, "quantity");
    }



}
