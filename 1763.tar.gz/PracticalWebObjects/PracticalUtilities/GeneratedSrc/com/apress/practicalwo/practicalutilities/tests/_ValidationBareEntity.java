package com.apress.practicalwo.practicalutilities.tests;




/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to ValidationBareEntity.java instead.
 *
 * @author author  Copyright (c) 2003
 */  
public abstract class _ValidationBareEntity extends com.apress.practicalwo.practicalutilities.CopyableGenericRecord 
{


    public static final String NAME = "name";


    public String name() 
    {
        return (String)storedValueForKey("name");
    }



    public void setName(String aValue) 
    {
        takeStoredValueForKey(aValue, "name");
    }



}
