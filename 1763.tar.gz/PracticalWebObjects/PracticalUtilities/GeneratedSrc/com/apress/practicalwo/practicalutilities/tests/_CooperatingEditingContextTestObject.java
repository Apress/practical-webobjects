package com.apress.practicalwo.practicalutilities.tests;


import com.webobjects.eocontrol.*;
import com.webobjects.foundation.*;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to CooperatingEditingContextTestObject.java instead.
 *
 * @author author  Copyright (c) 2003
 */  
public abstract class _CooperatingEditingContextTestObject extends EOGenericRecord 
{


    public static final String NAMEDOBJECTS = "namedObjects";
    public static final String RELATEDOBJECT = "relatedObject";
    public static final String STRINGVALUE = "stringValue";


    public String stringValue() 
    {
        return (String)storedValueForKey("stringValue");
    }



    public void setStringValue(String aValue) 
    {
        takeStoredValueForKey(aValue, "stringValue");
    }




    public com.apress.practicalwo.practicalutilities.tests.CooperatingEditingContextTestObject relatedObject() 
    {
        return (com.apress.practicalwo.practicalutilities.tests.CooperatingEditingContextTestObject)storedValueForKey("relatedObject");
    }



    public void setRelatedObject(com.apress.practicalwo.practicalutilities.tests.CooperatingEditingContextTestObject aValue) 
    {
        /** require [same_ec] 
            (aValue == null) ||
            ((aValue.editingContext() instanceof EOSharedEditingContext) ||
            (aValue.editingContext() == editingContext()) ); 
         **/

        takeStoredValueForKey(aValue, "relatedObject");
    }




    public NSArray namedObjects() 
    {
        return (NSArray)storedValueForKey("namedObjects");
    }



    public void setNamedObjects(NSMutableArray newValues) 
    {
        /** require [same_ec] (forall i : {0 .. newValues.count() - 1} # 
            ((EOEnterpriseObject)newValues.objectAtIndex(i)).editingContext() == editingContext());  **/

        takeStoredValueForKey(newValues, "namedObjects");
    }



    public void addToNamedObjects(com.apress.practicalwo.practicalutilities.tests.NamedObject object) 
    {
        /** require [same_ec] 
            object.editingContext() instanceof EOSharedEditingContext ||
            object.editingContext() == editingContext(); 
         **/

        NSMutableArray array = (NSMutableArray)namedObjects();
        willChange();
        array.addObject(object);
    }



    public void removeFromNamedObjects(com.apress.practicalwo.practicalutilities.tests.NamedObject object) 
    {
        NSMutableArray array = (NSMutableArray)namedObjects();

        willChange();
        array.removeObject(object);
    }



}
