package com.apress.practicalwo.ch2;


/**
 * Stand-alone class demonstrating slowness of BigDecimal compared to scalar types.
 *
 * @author Chuck Hill and Sacha Mallais
 */
import java.math.BigDecimal;

public class BigDecimalTest
{

    public static void main(String[] args)
    {
        final int NUMBER_OF_TRIALS = 100000;
        float[] floats = new float[NUMBER_OF_TRIALS];
        BigDecimal[] bigDecimals = new BigDecimal[NUMBER_OF_TRIALS];

        for (int i = 0; i < NUMBER_OF_TRIALS; i++)
        {
            floats[i] = i + (float)0.5221414;
            bigDecimals[i] = new BigDecimal(i + ".5221414");
        }

        long startFloat = System.currentTimeMillis();
        for (int i = 0; i < NUMBER_OF_TRIALS - 1; i++)
        {
            float junk = floats[i] * floats[i+1];
        }
        long endFloat = System.currentTimeMillis();
        System.out.println("Float test: " + (endFloat - startFloat));

        long startBD = System.currentTimeMillis();
        for (int i = 0; i < NUMBER_OF_TRIALS - 1; i++)
        {
            BigDecimal junk = bigDecimals[i].multiply(bigDecimals[i+1]);
        }
        long endBD = System.currentTimeMillis();
        System.out.println("BigDecimal test: " + (endBD - startBD));
    }
}
