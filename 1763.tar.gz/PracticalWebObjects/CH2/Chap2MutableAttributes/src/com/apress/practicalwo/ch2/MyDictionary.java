package com.apress.practicalwo.ch2;


import com.webobjects.foundation.NSMutableDictionary;
import com.webobjects.foundation.NSPropertyListSerialization;


/**
 * Sub-class of NSMutableDictionary that adds needed conversion method so that it
 * can be used as an attribute on an EOEnterpriseObject.
 * @see http://docs.info.apple.com/article.html?artnum=75173
 *
 * @author Chuck Hill and Sacha Mallais
 */
public class MyDictionary extends NSMutableDictionary
{

    static public NSMutableDictionary fromString(String dictionaryAsString) {
            /** require
            [non_null_param] dictionaryAsString != null; **/
            return (NSMutableDictionary)NSPropertyListSerialization.
                propertyListFromString(dictionaryAsString);
            /** ensure
            [non_null_result] Result != null; **/
        }

}
