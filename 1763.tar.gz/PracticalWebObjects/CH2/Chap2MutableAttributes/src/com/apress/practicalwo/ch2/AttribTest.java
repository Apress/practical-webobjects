package com.apress.practicalwo.ch2;


import com.webobjects.eocontrol.EOGenericRecord;
import com.webobjects.foundation.NSMutableDictionary;


/**
 * Simple EOEnterpriseObject with a name attribute and an NSMutableDictionary
 * attribute.
 *
 * @author Chuck Hill and Sacha Mallais
 */
public class AttribTest extends EOGenericRecord 
{

    public AttribTest() {
        super();
    }


    public String name() {
        return (String)storedValueForKey("name");
    }

    public void setName(String value) {
        takeStoredValueForKey(value, "name");
    }

    public NSMutableDictionary dictionary() {
        return (NSMutableDictionary)storedValueForKey("dictionary");
    }

    public void setDictionary(NSMutableDictionary value) {
        takeStoredValueForKey(value, "dictionary");
    }
}
