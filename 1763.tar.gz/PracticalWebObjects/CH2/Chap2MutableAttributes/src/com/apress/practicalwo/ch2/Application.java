package com.apress.practicalwo.ch2;


import com.webobjects.appserver.WOApplication;
import com.webobjects.eoaccess.EOUtilities;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSLog;


/**
 * Non-launching WO App demonstrating problems when using mutable attributes with
 * EOEnterpriseObjects.<br><br>
 * 1. Run the application once.  This will initialize the test data.<br>
 * 2. Run the application again and again.  Notice that EOF claims that it is
 *    updating the object but that the changes do not stick (are not written to 
 *    the database, not are they seen when comparing to the committed snapshot.<br>
 * <br><br>
 * [2003-09-03 17:58:54 PDT] SELECT t0."DICTIONARY", t0."NAME", t0."OID" FROM 
 * "ATTRIB_TEST" t0"<br>
 * Dictionary Before: {foo = "fooObject"; }<br>
 * Dictionary After: {bar = "barObject"; foo = "fooObject"; }<br>
 * has changes? true<br>
 * Changes from snapshot: {}
 *
 * @author Chuck Hill and Sacha Mallais
 */
public class Application extends WOApplication 
{
    
    public static void main(String argv[]) 
    {
        WOApplication.main(argv, Application.class);
    }

    public Application() 
    {
        super();
        EOEditingContext ec;
        AttribTest test;
        
        // Enable logging of SQL
        NSLog.allowDebugLoggingForGroups(NSLog.DebugGroupSQLGeneration
                                         | NSLog.DebugGroupDatabaseAccess
                                         | NSLog.DebugGroupEnterpriseObjects);
                                         
        ec = new EOEditingContext();
        ec.lock();
        NSArray tests = EOUtilities.objectsForEntityNamed(ec, "AttribTest");

        if (tests.count() == 0)
        {
            // Create test object if this is the first time the application 
            // has been run.
            test = new AttribTest();
            ec.insertObject(test);
            test.setName("First");
            test.setDictionary(new MyDictionary());
            test.dictionary().setObjectForKey("fooObject", "foo");
            ec.saveChanges();
        }
        else
        {
            // Test mutable attribute
            test = (AttribTest) tests.lastObject();
            NSLog.out.appendln("Dictionary Before: " + test.dictionary());

            test.willChange();
            test.dictionary().setObjectForKey("barObject", "bar");
            
            // The changes reported here:
            NSLog.out.appendln("Dictionary After: " + test.dictionary());
            NSLog.out.appendln("has changes? " + ec.hasChanges());
            NSLog.out.appendln(
                "Changes from snapshot: "
                    + test.changesFromSnapshot(
                        ec.committedSnapshotForObject(test)));
                        
            // Are not written to the database here.
            ec.saveChanges();
        }

        ec.unlock();
        
        terminate();
    }
}