package com.apress.practicalwo.chap4app;

import com.webobjects.appserver.WOCookie;
import com.webobjects.appserver.WOSession;
import com.webobjects.foundation.NSTimestamp;


/**
 * Example Session that authenticates and tracks users.  It can also persistently
 * remember the user in between sessions using cookies.  The commented out awake()
 * methods implements automatic login based on a previously remembered user.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class Session extends WOSession 
{
    public static final String USER_COOKIE_NAME = "PracticalWOUser";
    protected AbstractUser authenticatedUser;
    
   
    
    /**
     * Authenticates the user information provided and records the user 
     * as the authenticatedUser().
     * 
     * @param userID ID of user to authenticate
     * @param password information used to authenticate userID
     * @throws EOObjectNotAvailableException if userID can not be authenticated
     * with password
     */
	public void authenticateUser(String userID, String password)
	{
	    /** require [valid_user_id] userID != null;  
                    [valid_password] password != null;   **/
        authenticatedUser = AbstractUser.authenticatedUser(defaultEditingContext(), 
                                                         userID, password);
        /** ensure [has_authenticated_user] isUserAuthenticated();  **/
	}



    /**
     * Returns <code>true</code> if an authenticated user is associated with this
     * session.
     *   
     * @return <code>true</code> if an authenticated user is associated with this
     * session
     */
    public boolean isUserAuthenticated()
    {
        return authenticatedUser() != null;
    }
    


    /**
     * Returns the authenticated user associated with this session or null if there
     * isn't one.
     * 
     * @return the authenticated user associated with this session or null if there
     * isn't one
     */
    public AbstractUser authenticatedUser()
    {
        /** require [has_authenticatedUser] isUserAuthenticated();  **/
        return authenticatedUser;
        /** ensure [valid_result] Result != null;  **/
    }



    /**
     * Returns the userID from the user cookie, or null if there is no cookie.
     * 
     * @return the userID from the user cookie, or null if there is no cookie
     */
    public String rememberedUserID() 
    {
        return context().request().cookieValueForKey(USER_COOKIE_NAME); 
    }


    
    /**
     * Adds a cookie to the next response that will allow the userID of the
     * authenticated user to be retrieved later.  This cookie will expire two
     * months after the most recent login.
     */
    public void rememberUser()
    {
        /** require [authenticated_user] isUserAuthenticated();  **/
        
        WOCookie userCookie = new WOCookie(USER_COOKIE_NAME, authenticatedUser().userID());
        userCookie.setDomain(null);  // Let the browser set the domain
        userCookie.setPath("/");     // Return for all paths in this domain
        userCookie.setExpires(new NSTimestamp().
            timestampByAddingGregorianUnits(0, 2, 0, 0, 0, 0));
        context().response().addCookie(userCookie);
        /** ensure [cookie_added] true;  **/ 
    }



    /**
     * Adds a cookie to the next response that will remove any remembered userID.
     */
    public void forgetUser()
    {
        WOCookie userCookie = new WOCookie(USER_COOKIE_NAME, "dummy");
        userCookie.setDomain(null);  // Let the browser set the domain
        userCookie.setPath("/");     // Return for all paths in this domain
        userCookie.setExpires(new NSTimestamp().
            timestampByAddingGregorianUnits(0, -2, 0, 0, 0, 0));   
        context().response().addCookie(userCookie);
        /** ensure [cookie_added] true;  **/ 
    }



    /**
     * Overridden to implement auto-login.
     */
    /* Uncomment this to enable auto login
    public void awake()
    {
        super.awake();
        if ( ( ! isUserAuthenticated()) && (rememberedUserID() != null))
        {
            try 
            {
                authenticatedUser = (AbstractUser) com.webobjects.eoaccess.EOUtilities.
                    objectMatchingKeyAndValue(defaultEditingContext(), 
                                              "AbstractUser", 
                                              AbstractUser.USERID, rememberedUserID());
            }
            catch (Throwable t) {
                // Authentication failed, nothing to do - the cookie is bad
            }
        }
    }
    */


}