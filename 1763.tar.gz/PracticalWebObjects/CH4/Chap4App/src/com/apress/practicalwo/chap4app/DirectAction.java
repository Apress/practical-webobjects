package com.apress.practicalwo.chap4app;


import java.io.UnsupportedEncodingException;

import com.apress.practicalwo.practicalutilities.WORequestAdditions;
import com.webobjects.appserver.WOActionResults;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WODirectAction;
import com.webobjects.appserver.WORequest;
import com.webobjects.foundation.NSDictionary;
import com.webobjects.foundation.NSForwardException;


/**
 * Action and support methods for Just In Time Login and default action.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class DirectAction extends WODirectAction 
{
    public static final String DESTINATION_URL = "destinationUrl"; 


  /**
   * Returns an https URL for the login Direct Action.  A form value parameter of 
   * DESTINATION_URL is added to the URL.  The DESTINATION_URL paramters indicates
   * the URL that should be displayed after login. 
   * 
   * @param aContext the <code>WOContext</code> to get the destination URL from
   * @return an https URL for the login Direct Action
   */
    public static String secureLoginUrl(WOContext aContext)
    {
        /** require [valid_context] aContext != null;  **/
        String encodedUrl;
        try
        {
            encodedUrl =
                java.net.URLEncoder.encode(aContext.request().uri(), "UTF-8");
        }
        catch (UnsupportedEncodingException e)
        {
            throw new NSForwardException(e);
        }
        NSDictionary destination = new NSDictionary(encodedUrl, 
                                                    DirectAction.DESTINATION_URL);
        String loginActionUrl = "https://" +  
            WORequestAdditions.hostName(aContext.request()) +
            aContext.directActionURLForActionNamed("login", destination);
            
        return loginActionUrl;
        /** ensure [valid_result] Result != null;  **/
    }



    public DirectAction(WORequest aRequest) 
    {
        super(aRequest);
    }



    /**
     * Returns the page named Main. 
     */
    public WOActionResults defaultAction() 
    {
        return pageWithName("Main");
    }



    /**
     * Returns the page named JITLoginPage.  The form value from the DESTINATION_URL
     * parameter is passed into the JITLoginPage as the destinationURL.
     */
    public WOActionResults loginAction()
    {
        String destinationUrl = (String)request().formValueForKey(DESTINATION_URL);
        if (destinationUrl == null)
        {
            throw new RuntimeException(DESTINATION_URL + " missing from login URL");
        }
        
        JITLoginPage loginPage = (JITLoginPage)pageWithName("JITLoginPage");
        try
        {
            loginPage.setDestinationUrl(java.net.URLDecoder.decode(destinationUrl, "UTF-8"));
        }
        catch (UnsupportedEncodingException e)
        {
            throw new NSForwardException(e);
        }
        
        return loginPage;
    }


}