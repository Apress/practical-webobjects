package com.apress.practicalwo.chap4app;

import com.webobjects.eoaccess.EOObjectNotAvailableException;
import com.webobjects.eoaccess.EOUtilities;
import com.webobjects.eocontrol.EOEditingContext;


/**
 * Defines the interface for all users regardless of authentication type.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2003
 */ 
public abstract class AbstractUser extends _AbstractUser
{

    /**
     * Attempts to locate a user identified by userID and authenticated with
     * aPassword.  The user is returned if found, otherwise an exception is thrown. 
     * 
     * @param ec the EOEditingContext to return the authenticated user in (fetch 
     * the user into)
     * @param aUserID the identity of the user to be authenticated
     * @param aCredential the credential (e.g. password) to use to authenticate 
     * the userID
     * 
     * @return the SimpleUser with an identity of userID authenticated by the
     * aCredential 
     * 
     * @throws EOObjectNotAvailableException if a user matching the userID and 
     * credential cannot be found
     * @throws EOUtilities.MoreThanOneException if more than a single SimpleUser
     * object matches the userID and credential (this indicates a serious data
     * problem or programming error)
     */
    public static AbstractUser authenticatedUser(EOEditingContext ec,
                                                 String aUserID, 
                                                 String aPassword) 
        throws EOObjectNotAvailableException, EOUtilities.MoreThanOneException

    {
        /** require [valid_ec] ec != null;   
                    [valid_id] aUserID != null;     
                    [valid_credential] aPassword != null;  **/

        AbstractUser userWithIdentity =(AbstractUser) EOUtilities.
            objectMatchingKeyAndValue(ec, "AbstractUser", USERID, aUserID);
            
        if ( ! userWithIdentity.canAuthenticateWithPassword(aPassword))
        {
            throw new EOObjectNotAvailableException("Failed to authenticate");
        }

        return userWithIdentity;

        /** ensure [valid_result] Result != null;  **/
    }



    /**
     * Return <code>true</code> if this user can be authenticated with password.
     *  
     * @param password the password to attempt authentication with
     * 
     * @return <code>true</code> if this user can be authenticated with aCredential
     */
    public abstract boolean canAuthenticateWithPassword(String password);
    
    
    
    /**
     * Sets authentication credential based on supplied password.
     * 
     * @param password the text to process into the credential for authentication
     */
    public abstract void setPassword(String password);
    
}

