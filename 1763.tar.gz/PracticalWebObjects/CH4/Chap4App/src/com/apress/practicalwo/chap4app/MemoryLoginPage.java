package com.apress.practicalwo.chap4app;


import com.apress.practicalwo.practicalutilities.WORequestAdditions;
import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WORedirect;
import com.webobjects.eoaccess.EOObjectNotAvailableException;


/**
 * Simple login page that demonstrates Remember Me functionality.  If the 
 * Remember Me checkbox is checked and login succeeds the user will be remembered.  
 * If the box is not checked and login succeeds any remembered user will be 
 * forgotten.  No change will be made if authentication fails.  The result of the 
 * default direct action is shown when login succeeds.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class MemoryLoginPage extends WOComponent 
{


    public String userID;
    public String password;
    public boolean wasLoginInvalid;
    public boolean shouldRememberUser;
    

    /**
     * Initializes the user identity and state of the Remember Me checkbox based 
     * on the rememberedUserID() provided by the session.
     * 
     * @see com.webobjects.appserver.WOComponent#WOComponent(WOContext) 
     */
    public MemoryLoginPage(WOContext context) 
    {
        super(context);
        userID = ((Session)session()).rememberedUserID();
        shouldRememberUser = (userID != null); 
    }
    
    

    /**
      * Attempts to validate the login information provided.  Records the user in 
      * the Session if successful.  Adds or removes remembered user cookie as
      * requested.  Redisplays this page with an error message if not successful.
      * 
      * @return the default direct action if login succeeds, this page otheriwse
      */
     public WOComponent login() 
     {
         WOComponent nextPage = context().page();
         wasLoginInvalid = true;
        
         if ((userID != null) && (password != null))
         {
             try
             {
                 ((Session)session()).authenticateUser(userID, password);
                                                 
                 String insecurePostLoginActionUrl = "http://" +  
                     WORequestAdditions.hostName(context().request()) +
                     context().directActionURLForActionNamed("default", null);

                 if (shouldRememberUser) 
                 {
                     ((Session)session()).rememberUser();
                 }
                 else
                 {
                     ((Session)session()).forgetUser();
                 }

                 nextPage =  pageWithName("WORedirect");
                 ((WORedirect)nextPage).setUrl(insecurePostLoginActionUrl);
             }
             catch (EOObjectNotAvailableException e)
             {
                 // Login was invalid, nothing else to do
             }
         }

         return nextPage;
     }
}