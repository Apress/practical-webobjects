package com.apress.practicalwo.chap4app;

import com.apress.practicalwo.practicalutilities.WORequestAdditions;
import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.foundation.NSLog;


/**
 * Demonstration of how to use WOForm with HTTPS.
 * 
 * @author Charles Hill and Sacha Mallais.
 */
public class SecureForms extends WOComponent 
{
    public String bigSecret;


    public SecureForms(WOContext context) 
    {
        super(context);
    }

    
    
    /**
     * Dummy method to show that the correct WOSubmitButton action gets called.
     */
    public WOComponent saveInformation() 
    {
        NSLog.out.appendln("Saving secret information: " + bigSecret);
        return null;
    }


    /**
     * Dummy method to show that the correct WOSubmitButton action gets called.
     */
    public WOComponent sendInformation() 
    {
        NSLog.out.appendln("Sending secret information: " + bigSecret);
        return null;
    }
    
    

    /**
     * Returns a secure (HTTPS) component action URL.  This is implemented using 
     * private (underscore prefixed methods)WOContext API and so may stop working
     * in the future. 
     * 
     * @return a secure component action URL
     */
    public String secureFormUrlWithPrivateAPI() 
    {
        context()._generateCompleteURLs();
        String secureFormUrl = context()._componentActionURL(true);
        context()._generateRelativeURLs();
        
        return secureFormUrl;
    }



    /**
     * Returns a secure (HTTPS) component action URL. 
     * 
     * @return a secure component action URL
     */
    public String secureFormUrlWithoutPrivateAPI() 
    {
        String secureFormUrl = "https://" +  
            WORequestAdditions.hostName(context().request());
            
        secureFormUrl += context().componentActionURL();
        
        return secureFormUrl;
    }

}