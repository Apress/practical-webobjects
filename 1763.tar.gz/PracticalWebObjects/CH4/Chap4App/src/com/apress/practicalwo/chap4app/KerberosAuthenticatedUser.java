package com.apress.practicalwo.chap4app;

import java.net.InetAddress;

/*
import com.dstc.security.kerberos.KDCOptions;
import com.dstc.security.kerberos.Kerberos;
import com.dstc.security.kerberos.KerberosContext;
import com.dstc.security.kerberos.KerberosException;
import com.dstc.security.kerberos.KerberosPassword;
import com.dstc.security.kerberos.PrincipalName;
*/

import com.webobjects.foundation.NSForwardException;


/**
 * Implementation of AbstractUser that uses Kerberos to authenticate the user.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2003
 */ 
public class KerberosAuthenticatedUser extends _KerberosAuthenticatedUser
{

    public static final String REALM = "PRACTICALWEBOBJECTS.APRESS.COM";
    public static final String KDC_HOST = "kerberos.practicalwebobject.apress.com";


    /**
     * Installs the com.dstc.security.provider.DSTC Cryptography Package Provider.  
     * See the file JRE/lib/security/java.security file for more information and 
     * an alternative installation procedure.
     */
    /*
    protected static void installCryptoProvider()
    {
        java.security.Provider dtsc = new com.dstc.security.provider.DSTC();

        // Make sure it has not already been installed
        if (java.security.Security.getProvider(dtsc.getName()) == null)
        {
            java.security.Security.insertProviderAt(dtsc, 2);
        }

        // Verify that we can get the Cipher that we need
        try
        {
            javax.crypto.Cipher ciph = javax.crypto.Cipher.getInstance("DES/CBC/NoPadding");
        }
        catch (Exception e)
        {
            throw new NSForwardException(e);
        }
    }
    */
    
    
    /**
     * Returns an InetAddress representing the machine that Kerberos is running on.
     * 
     * @param hostName the name of the the machine that Kerberos is running on
     * @return an InetAddress representing the machine that Kerberos is running on
     */
    protected static InetAddress keyDistributionCenter(String hostName)
    {
        /** require [valid_hostname] hostName != null;  **/
        InetAddress keyDistributionCenter;
        
        try
        {
            keyDistributionCenter = InetAddress.getByName(hostName);
        }
        catch (java.net.UnknownHostException e)
        {
            // Nothing we can do about this!
            throw new NSForwardException(e);
        }
        
        return keyDistributionCenter;
        /** ensure [valid_result] Result != null;  **/
    }
        
    
    
    /**
     * Return <code>true</code> if this user can be authenticated with password.
     * This is implemented by attempting Kerberos Authentication with the password. 
     *  
     * @param password the password to attempt to authentication with
     * 
     * @return <code>true</code> if this user can be authenticated with password
     * 
     * @see com.apress.practicalwo.chap4app.AbstractUser#canAuthenticateWithPassword(java.lang.String)
     */
    public boolean canAuthenticateWithPassword(String password)
    {
        /** require [valid_password] password != null;  **/
        boolean canAuthenticateWithPassword = false;
        
        /*
        PrincipalName principal = new PrincipalName(userID().toLowerCase());
        KerberosPassword kerberosPassword = new KerberosPassword(password.getBytes());
             
        // Create a new context based on the Kerberos Principal being 
        // authenticated and get a reference to the server.
        KerberosContext context = new KerberosContext(REALM,
                                                      principal,
                                                      keyDistributionCenter(KDC_HOST));
        Kerberos kerberos = Kerberos.getInstance(context);
            
        try
        {
            kerberos.requestTicketGrantingTicket(kerberosPassword, new KDCOptions(), 
                                                 null, null, null, null);
            canAuthenticateWithPassword = true;
        }
        catch (com.dstc.security.kerberos.CryptoException e)
        {
            // Authentication failed: Password incorrect.
        }
        catch (KerberosException e)
        {
            // Authentication failed: Client not found in Kerberos database
        }
        catch (java.io.IOException e)
        {
            // This probably means that the server could not be reached
                throw new NSForwardException(e, "Failed to authenticate");
        }
        */
        
        return canAuthenticateWithPassword;
    }



    /**
     * Does nothing.  The password is maintained externally by the Kerberos server.
     * 
     * @see com.apress.practicalwo.chap4app.AbstractUser#setPassword(java.lang.String)
     */
    public void setPassword(String password)
    {
    }



}

