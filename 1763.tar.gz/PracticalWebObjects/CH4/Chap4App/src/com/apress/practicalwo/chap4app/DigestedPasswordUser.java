package com.apress.practicalwo.chap4app;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.webobjects.foundation.NSForwardException;

/**
 * Implementation of AbstractUser that used a digest of the password as the 
 * authentication credential.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2003
 */ 
public class DigestedPasswordUser extends _DigestedPasswordUser
{
    
    /**
     * Return <code>true</code> if this user can be authenticated with password.
     * This is implemented by comaparing a digest of the password with the stored 
     * credential. 
     *  
     * @param password the password to attempt authentication with
     * 
     * @return <code>true</code> if this user can be authenticated with password
     *      
     * @see com.apress.practicalwo.chap4app.AbstractUser#canAuthenticateWithPassword(java.lang.String)
     */
    public boolean canAuthenticateWithPassword(String password)
    {
        /** require [valid_password] password != null;  **/
        return digestedString(password).equals(credential());
    }
    
    
    
    /**
     * Produces authentication credential from password.
     * 
     * @param password the text to process into the credential for authentication
     */
    public void setPassword(String password)
    {
        /** require [valid_password] password != null;  **/
        setCredential(digestedString(password));
        /** ensure [credential_set] credential() != null;  
                   [credential_is_digest] credential().equals(
                   digestedString(password)); **/
    }



    /**
     * Processes <code>aString</code> through <code>messageDigest()</code> and
     * returns the result encoded in UTF-8.
     * 
     * @param aString the text to digest
     * @return <code>aString</code> processed by <code>messageDigest()</code> and
     * encoded in UTF-8
     */
    protected String digestedString(String aString)
    {
        /** require [aString_valid] aString != null; **/
        String digestedString;
        
        try
        {
            MessageDigest md = MessageDigest.getInstance("SHA");
            digestedString =  new sun.misc.BASE64Encoder().encode(md.digest(aString.getBytes()));
        }
        catch (NoSuchAlgorithmException e)
        {
            throw new NSForwardException(e);
        }
        
        return digestedString;
        /** ensure [valid_result] Result != null;  **/
    }
    
}

