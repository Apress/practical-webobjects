package com.apress.practicalwo.chap4app;


import com.apress.practicalwo.practicalutilities.WORequestAdditions;
import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WORedirect;
import com.webobjects.appserver.WOResponse;


/**
 * Simple page demonstrating using Component Actions to do Just In Time Login.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2003
 */
public class ArticleDisplayPage2 extends WOComponent 
{


    public ArticleDisplayPage2(WOContext context) 
    {
        super(context);
    }



    /**
     * Overridden to implement Just In Time Login.  Responds with a WORedirect to 
     * current URL in HTTPS if the request was not made in HTTPS.  Responds with 
     * the login page if the request was secure but there is no authenticated user. 
     */
    public void appendToResponse(WOResponse response, WOContext context)
    {
        if ( ! ((Session)session()).isUserAuthenticated())
        {
            if ( ! WORequestAdditions.isSecure(context.request()))
            {
                WORedirect secureRedirect = (WORedirect)pageWithName("WORedirect");
                secureRedirect.setUrl("https://" + 
                                 WORequestAdditions.hostName(context.request()) + 
                                 context.request().uri());
                secureRedirect.appendToResponse(response, context);
            }
            else
            {
                JITLoginPage loginPage = (JITLoginPage)pageWithName("JITLoginPage");
                loginPage.setDestinationUrl(context.request().uri());
                response.setContent(loginPage.generateResponse().content());
            }
        }
        else
        {
            super.appendToResponse(response, context);
        }
    }
}