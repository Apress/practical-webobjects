package com.apress.practicalwo.chap4app;


import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WORedirect;
import com.webobjects.appserver.WOResponse;



/**
 * Simple page demonstrating using Direct Actions to do Just In Time Login. 
 * 
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2003
 */
public class ArticleDisplayPage extends WOComponent 
{

    public ArticleDisplayPage(WOContext context) 
    {
        super(context);
    }



    /**
     * Overridden to implement Just In Time Login.  Responds with a WORedirect to 
     * a HTTPS URL for the login Direct Action if the user has not logged in yet.  
     */
    public void appendToResponse(WOResponse response, WOContext context)
    {
        if ( ! ((Session)session()).isUserAuthenticated())
        {
            WORedirect loginPageRedirect = (WORedirect)pageWithName("WORedirect");
            loginPageRedirect.setUrl(DirectAction.secureLoginUrl(context));
            loginPageRedirect.appendToResponse(response, context);
        }
        else
        {
            super.appendToResponse(response, context);
        }
    }

}