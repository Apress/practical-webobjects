package com.apress.practicalwo.chap4app;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import com.webobjects.foundation.NSForwardException;

/**
 * Implementation of AbstractUser that uses an LDAP server to authenticate the user.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2003
 */ 
public class LDAPAuthenticatedUser extends _LDAPAuthenticatedUser
{
    // These should come from a config file
    public static final String LDAP_URL = "ldap://localhost:389";
    public static final String BASE_DN = ",dc=practicalwebobjects,dc=apress,dc=com";


    /**
     * Return <code>true</code> if this user can be authenticated with password.
     * This is implemented by attempting an LDAP login with the credential. 
     *  
     * @param password the password to attempt to authentication with
     * 
     * @return <code>true</code> if this user can be authenticated with password
     * 
     * @see com.apress.practicalwo.chap4app.AbstractUser#canAuthenticateWithPassword(java.lang.String)
     */
    public boolean canAuthenticateWithPassword(String password)
    {
        /** require [valid_password] password != null;  **/
        boolean canAuthenticateWithPassword = false;
        
        Hashtable ldapEnvironment = ldapEnvironment();
        ldapEnvironment.put(Context.SECURITY_PRINCIPAL, "userid=" + userID() + BASE_DN);
        ldapEnvironment.put(Context.SECURITY_CREDENTIALS, password);

        try
        {
            DirContext ctx = new InitialDirContext(ldapEnvironment);
            canAuthenticateWithPassword = true;
            ctx.close();
        }
        catch (javax.naming.AuthenticationException authException)
        {
            // Nothing to do, they fail.
        }
        catch (NamingException e)
        {
            if (e.getRootCause() instanceof java.net.ConnectException)
            {
                throw new NSForwardException(e, "Failed to contact LDAP server.");
            }
            else
            {
                throw new NSForwardException(e);
            }
        }
    
        return canAuthenticateWithPassword;
    }




    /**
     * Returns <code>Hasttable</code> of LDAP environment settings which are not 
     * user specific: INITIAL_CONTEXT_FACTORY, PROVIDER_URL, and  
     * SECURITY_AUTHENTICATION.
     * 
     * @return <code>Hasttable</code> of LDAP environment settings which are not 
     * user specific
     */
        protected Hashtable ldapEnvironment()
    {
        Hashtable ldapEnvironment = new Hashtable();
        ldapEnvironment.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        ldapEnvironment.put(Context.PROVIDER_URL, LDAP_URL);

         // This is only appropriate when the communications channel is secure.
         // In practice some form of SASL should be used.
        ldapEnvironment.put(Context.SECURITY_AUTHENTICATION, "simple");

        return ldapEnvironment;
        
        /** ensure [valid_result] Result != null;
                   [has_factory] Result.get(Context.INITIAL_CONTEXT_FACTORY) != null;
                   [has_url] Result.get(Context.PROVIDER_URL) != null;
                   [has_auth_method] Result.get(Context.SECURITY_AUTHENTICATION) != null;
         **/
    }



    /**
     * Does nothing.  The password is maintained externally by the LDAP server.
     * 
     * @see com.apress.practicalwo.chap4app.AbstractUser#setPassword(java.lang.String)
     */
    public void setPassword(String password)
    {
    }



}

