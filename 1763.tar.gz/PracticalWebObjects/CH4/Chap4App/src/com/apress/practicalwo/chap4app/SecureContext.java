package com.apress.practicalwo.chap4app;

import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WORequest;


/**
 * A sub-class of WOContext demonstrating one method of dealing with a bug related
 * to secure URL generation.
 * 
 * @author Charles Hill and Sacha Mallais
 */
public class SecureContext extends WOContext
{


    public SecureContext(WORequest request)
    {
        super(request);
    }


    /**
     * Overridden to fix a a defect in WebObjects' URL generation.  When a request 
     * is made via HTTPS and a WOHyperlink in the returned response has a 
     * <code>secure</code> binding of <code>false</code>.  In this situation, the 
     * URL generated is incorrect:<br>
     * <a href="http://www.domain.com:443/cgi-bin/WebObjects/Chap4App.woa/3/wo/etc.">
     * The URL specifies HTTP but uses the standard HTTPS port number 443.  This 
     * method generates a correct URL  
 */
    public String completeURLWithRequestHandlerKey(String requestHandlerKey,
                                                   String requestHandlerPath,
                                                   String queryString,
                                                   boolean isSecure,
                                                   int somePort)
    {
        return super.completeURLWithRequestHandlerKey(requestHandlerKey,
            requestHandlerPath, queryString, isSecure, isSecure ? 443 : 80);
    }
                                                   
                                                   
}
