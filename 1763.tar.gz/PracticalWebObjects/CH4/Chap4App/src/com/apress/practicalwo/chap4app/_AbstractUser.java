package com.apress.practicalwo.chap4app;


import com.webobjects.eocontrol.EOGenericRecord;


/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to AbstractUser.java instead.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2003
 */  
public abstract class _AbstractUser extends EOGenericRecord 
{


    public static final String USERID = "userID";


    public String userID() 
    {
        return (String)storedValueForKey("userID");
    }



    public void setUserID(String aValue) 
    {
        takeStoredValueForKey(aValue, "userID");
    }



}
