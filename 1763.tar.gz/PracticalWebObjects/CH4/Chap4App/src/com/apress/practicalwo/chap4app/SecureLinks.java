package com.apress.practicalwo.chap4app;

import com.apress.practicalwo.practicalutilities.WORequestAdditions;
import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;


/**
 * Demonstration of how to use WOHyperlink to move into and out of HTTPS.
 * 
 * @author Charles Hill and Sacha Mallais.
 */
public class SecureLinks extends WOComponent 
{

    public SecureLinks(WOContext context) 
    {
        super(context);
    }

    
    /**
     * Returns this component so that the page re-displays.
     * 
     * @return this component so that the page re-displays
     */
    public WOComponent redisplayPage() 
    {
        return this;
    }



    /**
     * Return <code>true</code> if the most request being processed was not made
     * securely.  This can be bound to the <code>secure</code> binding of a 
     * <code>WOHyperlink</code> to toggle into and out of https.
     *  
     * @return <code>true</code> if the most request being processed was not made
     * securely
     */
    public boolean isntSecureNow()
    {
        return ! WORequestAdditions.isSecure(context().request());
    }


}