package com.apress.practicalwo.chap4app;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import com.webobjects.foundation.NSForwardException;

/**
 * Implementation of AbstractUser that used an ecrypted password as the 
 * authentication credential.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2003
 */ 
public class EncryptedPasswordUser extends _EncryptedPasswordUser
{
    protected static PBEParameterSpec obfuscator;
    protected static SecretKey secretKey; 
    protected static boolean hasInitializedCipherSupport = false;


    /**
     * Static initializer method to work around parsing bug in Jass that can't handle
     * static initializer blocks.
     */
    protected static void initializeCipherSupport()
    {
        if ( ! hasInitializedCipherSupport)
        {
            try
            {
                // Create parameters for Password Based Encryption.  If someone can 
                // get this information they can decrypt anything we encrypt!
                obfuscator = new PBEParameterSpec(
                    new byte[] { (byte)0xc8, (byte)0xee, (byte)0xc7, (byte)0x73, 
                            (byte)0x7e,  (byte)0x99, (byte)0x21, (byte)0x8c}, 
                    100);
                secretKey = SecretKeyFactory.getInstance("PBEWithMD5AndDES").
                generateSecret(new PBEKeySpec("0ur(v@rys*c.r.tK!~".toCharArray()));
                hasInitializedCipherSupport = true;
            }
            catch (Exception e)
            {
                throw new NSForwardException(e);
            }
        }
    }
    
    
    
    /**
     * Produces authentication credential from password.
     * 
     * @param password the text to process into the credential for authentication
     */
    public void setPassword(String password)
    {
        /** require [valid_password] password != null;  **/
        setCredential(transformString(password, Cipher.ENCRYPT_MODE));
        /** ensure [credential_set] credential() != null;  
                   [credential_is_digest] credential().equals(password); **/
    }
    
    
    
    /**
     * Return <code>true</code> if this user can be authenticated with password.
     * This is implemented by comaparing an encrypted version of the password with 
     * the stored credential. 
     *  
     * @param password the password to attempt to authentication with
     * 
     * @return <code>true</code> if this user can be authenticated with password
     * 
     * @see com.apress.practicalwo.chap4app.AbstractUser#canAuthenticateWithPassword(java.lang.String)
     */
    public boolean canAuthenticateWithPassword(String password)
    {
        /** require [valid_password] password != null;  **/
        return transformString(password, Cipher.ENCRYPT_MODE).equals(credential());
    }
    
    
    
    /**
     * Encrypts or decrypts (determined by mode) inputString.  Results of encryption
     * are encoded in Base64.  Strings to be decrypted are assumed to have been
     * encoded in Base64 and are decoded before being decrypted.
     * 
     * @param inputString the String ot encrypt or decrypt
     * @param mode either Ciper.ENCRYPT_MODE or Cipher.DECRYPT_MODE
     * 
     * @return the transformed String
     */
    public String transformString(String inputString, int mode)
    {
        /** require [valid_input] inputString != null;
                    [valid_mode] (mode == Cipher.ENCRYPT_MODE) || 
                                 (mode == Cipher.DECRYPT_MODE);  **/

        String transformedString;
        initializeCipherSupport();
        
        try
        {
            // Create a Password Based Encryption cipher and initialize with 
            // mode, key, and obfuscator
            Cipher pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
            pbeCipher.init(mode, secretKey, obfuscator);
            
            if (mode == Cipher.ENCRYPT_MODE)
            {
                byte[] processedBytes = pbeCipher.doFinal(inputString.getBytes());
                transformedString = new sun.misc.BASE64Encoder().encode(processedBytes);
            }
            else
            {
                byte[] bytesToProcess = new sun.misc.BASE64Decoder().decodeBuffer(inputString);
                transformedString = new String(pbeCipher.doFinal(bytesToProcess));
            }
        }
        catch (Exception e)
        {
            throw new NSForwardException(e);
        }

        return transformedString;
        
        /** ensure [valid_result] Result != null;  **/
    }
    

}

