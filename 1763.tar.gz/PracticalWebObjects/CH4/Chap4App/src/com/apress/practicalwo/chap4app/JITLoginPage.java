package com.apress.practicalwo.chap4app;


import com.apress.practicalwo.practicalutilities.WORequestAdditions;
import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WORedirect;
import com.webobjects.eoaccess.EOObjectNotAvailableException;


/**
 * Simple login page demonstarting Just In Time Login.  The URL to redirect to
 * after successful login must be set before returning the page to the user.  See 
 * the method setDestinationUrl().
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2003
 */
public class JITLoginPage extends WOComponent 
{
    public String userID;
    public String password;
    public boolean wasLoginInvalid;
    
    private String destinationUrl;
    
    
    public JITLoginPage(WOContext context) 
    {
        super(context);
    }
    
    
    
    /**
     * Attempts to validate the login information provided.  Records the user in 
     * the Session if successful.  Redisplays this page with an error message if
     * not successful.
     * 
     * @return a WORedirect to destinationUrl() if login succeeds, 
     * this page otheriwse
     */
    public WOComponent login() 
    {
        /** require [has_destination_url] destinationUrl() != null;  **/
        
        WOComponent nextPage = context().page();
        wasLoginInvalid = true;
        
        if ((userID != null) && (password != null))
        {
            try
            {
                ((Session)session()).authenticateUser(userID, password);
                                                 
                String insecurePostLoginActionUrl = "http://" +  
                    WORequestAdditions.hostName(context().request()) +
                    destinationUrl();
        
                nextPage =  pageWithName("WORedirect");
                ((WORedirect)nextPage).setUrl(insecurePostLoginActionUrl);
            }
            catch (EOObjectNotAvailableException e)
            {
                // Login was invalid, nothing else to do
            }
        }

        return nextPage;
    }



    /**
     * Returns the URL to redirect to when login succeeds.
     * 
     * @return the URL to redirect to when login succeeds
     */
    public String destinationUrl() 
    {
        return destinationUrl;
    }



    /**
     * Sets the URL to redirect to when login succeeds.
     * 
     * @param newDestinationUrl the URL to redirect to when login succeeds
     */
    public void setDestinationUrl(String newDestinationUrl) 
    {
        destinationUrl = newDestinationUrl;
    }
    
}