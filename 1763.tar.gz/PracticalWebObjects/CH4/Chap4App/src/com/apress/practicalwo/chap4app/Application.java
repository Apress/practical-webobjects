package com.apress.practicalwo.chap4app;

import com.apress.practicalwo.appserver.PWOApplication;
import com.webobjects.appserver.WOApplication;
import com.webobjects.eoaccess.EOObjectNotAvailableException;
import com.webobjects.eocontrol.EOEditingContext;


/**
 * WOApplication sub-class demonstrating use of a sub-class of WOContext and one
 * way of avoiding direct page access.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class Application extends PWOApplication 
{
    
    public static void main(String argv[]) 
    {
        WOApplication.main(argv, Application.class);
    }



    public Application() 
    {
        super();
        createUsers();  // Create example data if needed
    }
    
    
    
    /**
     * Overridden to prevent direct access to pages with URLs like
     * http://localhost/cgi-bin/WebObjects/Chap4App.woa/-1697/wo/SecretPage.wo
     */
    /* Uncomment to enable this.
    public WOComponent pageWithName(String pageName, WOContext context) 
    {
        if ((context.senderID() == null) && 
            (componentRequestHandlerKey().equals(
                 context.request().requestHandlerKey()))) {
            pageName = null;
        }


       return super.pageWithName(pageName, context);
    }
     */

    
    
    /**
     * Returns the complete class name of the WOContext sub-class to use in place
     * of WOContext.
     * 
     * @return the complete class name of the WOContext sub-class to use in place
     * of WOContext
     * @see com.apress.practicalwo.chap4app.SecureContext
     */
    public String contextClassName()
    {
        return "com.apress.practicalwo.chap4app.SecureContext";
    }
    
    
    
    
    /** 
     * Creates an example user for each type of authentication if this has not
     * already been done.
     */
    public void createUsers()
    {
        EOEditingContext ec = new EOEditingContext();
        ec.lock();
        try
        {
            AbstractUser.authenticatedUser(ec, "chuck", "foo");
        }
        catch (EOObjectNotAvailableException e)
        {
            AbstractUser aUser = new SimpleUser();
            ec.insertObject(aUser);
            aUser.setUserID("chuck");
            aUser.setPassword("foo");
            ec.saveChanges();
            
            aUser = new DigestedPasswordUser();
            ec.insertObject(aUser);
            aUser.setUserID("sacha");
            aUser.setPassword("bar");
            ec.saveChanges();
            
            aUser = new EncryptedPasswordUser();
            ec.insertObject(aUser);
            aUser.setUserID("anon");
            aUser.setPassword("emouse");
            ec.saveChanges();
            
            aUser = new LDAPAuthenticatedUser();
            ec.insertObject(aUser);
            aUser.setUserID("bobs");
            aUser.setPassword("yeruncle");
            ec.saveChanges();
            
            aUser = new KerberosAuthenticatedUser();
            ec.insertObject(aUser);
            aUser.setUserID("joe");
            aUser.setPassword("cuppajo");
            ec.saveChanges();            
        }
        finally
        {
            ec.unlock();
        }
    }

    
}