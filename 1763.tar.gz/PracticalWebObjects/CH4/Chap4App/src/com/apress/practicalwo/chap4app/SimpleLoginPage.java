package com.apress.practicalwo.chap4app;

import com.apress.practicalwo.practicalutilities.WORequestAdditions;
import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WORedirect;
import com.webobjects.eoaccess.EOObjectNotAvailableException;

/**
 * Simple login page that just shows the results of the default direct action
 * after log in succeeds.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class SimpleLoginPage extends WOComponent 
{

    public String userID;
    public String password;
    public boolean wasLoginInvalid;


    public SimpleLoginPage(WOContext context) 
    {
        super(context);
    }

    /**
      * Attempts to validate the login information provided.  Records the user in 
      * the Session if successful.  Redisplays this page with an error message if
      * not successful.
      * 
      * @return the default direct action if login succeeds, this page otheriwse
      */
     public WOComponent login() 
     {
         WOComponent nextPage = context().page();
         wasLoginInvalid = true;
        
         if ((userID != null) && (password != null))
         {
             try
             {
                 ((Session)session()).authenticateUser(userID, password);
                                                 
                 String insecurePostLoginActionUrl = "http://" +  
                     WORequestAdditions.hostName(context().request()) +
                     context().directActionURLForActionNamed("default", null);
        
                 nextPage =  pageWithName("WORedirect");
                 ((WORedirect)nextPage).setUrl(insecurePostLoginActionUrl);
             }
             catch (EOObjectNotAvailableException e)
             {
                 // Login was invalid, nothing else to do
             }
         }

         return nextPage;
     }


}