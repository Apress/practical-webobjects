package com.apress.practicalwo.chap4app;




/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to EncryptedPasswordUser.java instead.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2003
 */  
public abstract class _EncryptedPasswordUser extends com.apress.practicalwo.chap4app.AbstractUser 
{


    public static final String USERID = "userID";
    public static final String CREDENTIAL = "credential";


    public String credential() 
    {
        return (String)storedValueForKey("credential");
    }



    public void setCredential(String aValue) 
    {
        takeStoredValueForKey(aValue, "credential");
    }



}
