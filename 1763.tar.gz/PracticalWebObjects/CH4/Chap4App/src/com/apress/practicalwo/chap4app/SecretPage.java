package com.apress.practicalwo.chap4app;


import com.webobjects.appserver.*;

/**
 * Simple place-holder page to demonstrate direct component access.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class SecretPage extends WOComponent 
{

    public SecretPage(WOContext context) 
    {
        super(context);
    }

}