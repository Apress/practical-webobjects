package com.apress.practicalwo.chap4app;




/**
 * Created by eogenerator
 *
 * DO NOT EDIT.  Make changes to LDAPAuthenticatedUser.java instead.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2003
 */  
public abstract class _LDAPAuthenticatedUser extends com.apress.practicalwo.chap4app.AbstractUser 
{


    public static final String USERID = "userID";

}
