package com.apress.practicalwo.chap4app;


/**
 * Implementation of AbstractUser that used an plain text password as the 
 * authentication credential.
 *
 * @author Charles Hill and Sacha Mallais  Copyright (c) 2003
 */ 
public class SimpleUser extends _SimpleUser
{
    
    /**
     * Produces authentication credential from password.
     * 
     * @param password the text to process into the credential for authentication
     */
    public void setPassword(String password)
    {
        /** require [valid_password] password != null;  **/
        setCredential(password);
        /** ensure [credential_set] credential() != null;  
                   [credential_equals_digest] credential().equals(password); **/
    }



    /**
     * Return <code>true</code> if this user can be authenticated with password.
     * This is implemented by comparing the given password with the stored 
     * credential. 
     *  
     * @param password the password to attempt authentication with
     * 
     * @return <code>true</code> if this user can be authenticated with password
     */
    public boolean canAuthenticateWithPassword(String password)
    {
        /** require [valid_password] password != null;  **/
        return password.equals(credential());
    }
}

