package com.apress.practicalwo.chap4app;

import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WORedirect;
import com.webobjects.foundation.NSDictionary;


/**
 * Main page of application with links to various tests and examples.
 *
 * @author Charles Hill and Sacha Mallais
 */
public class Main extends WOComponent 
{
    public static final NSDictionary noWOSID = new NSDictionary(Boolean.FALSE, "wosid");
    
    
    public Main(WOContext context) 
    {
        super(context);
    }



    /**
     * Simple logout action that leaves the user on the page returned by the default
     * Direct Action.
     * @return <code>WORedirect</code> to default Direct Action
     */
    public WOComponent logout() 
    {
        session().terminate();
        WORedirect mainPage = (WORedirect) pageWithName("WORedirect");
        mainPage.setUrl(context().directActionURLForActionNamed("default", noWOSID));
        
        return mainPage;
    }


}